#include "TestClient.h"
extern "C"
{
    #include "ChnsysRTSP.h"
};
#include <stdio.h>
#include <string.h>

#ifdef WIN32
#else
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#endif//

//////////////////////////////////////////////////////////////////////////
RTSP_CLIENT_HANDLE  g_hRTSPClient = NULL;

CHNSYS_BOOL g_bPlaySuccess = FALSE;

FILE *g_hH264File = NULL;
CHNSYS_INT g_nH264StreamNo = 0;

FILE *g_hAACFile = NULL;
CHNSYS_INT g_nAACStreamNo = 1;
//////////////////////////////////////////////////////////////////////////

RTSP_SERVER_HANDLE  g_hRTSPServer = NULL;


int MyRawDataCallBack(RTSP_CLIENT_RAWDATACBDATA rdcbd)
{
    if (g_bPlaySuccess)
    {
        if (rdcbd.nStreamNo == g_nH264StreamNo)
        {
            //printf("[MyRawDataCallBack] h264 seconds %d useconds %d\r\n", rdcbd.nTimestampSecond, rdcbd.nTimestampUSecond);
            if (g_hH264File != NULL)
            {
                fwrite(rdcbd.sData, 1, rdcbd.nData, g_hH264File);
                fflush(g_hH264File);
            }
        }
        else if (rdcbd.nStreamNo == g_nAACStreamNo)
        {
            //printf("[MyRawDataCallBack] aac seconds %d useconds %d\r\n", rdcbd.nTimestampSecond, rdcbd.nTimestampUSecond);
            if (g_hAACFile != NULL)
            {
                fwrite(rdcbd.sData, 1, rdcbd.nData, g_hAACFile);
                fflush(g_hAACFile);
            }
        }
    }

    return 0;
}

int MyRtpDataCallBack(RTSP_CLIENT_RTPCBDATA rtpcbd)
{
    if (g_bPlaySuccess)
    {
        if (rtpcbd.nStreamNo == g_nH264StreamNo)
        {
            //printf("[MyRtpDataCallBack] h264 rtp packet size = %d\r\n", rtpcbd.nData);
        }
        else if (rtpcbd.nStreamNo == g_nAACStreamNo)
        {
            //printf("[MyRtpDataCallBack] aac rtp packet size = %d\r\n", rtpcbd.nData);
        }
        if (g_hRTSPServer != NULL)
        {
            RTSP_SERVER_PushRTPData(g_hRTSPServer, rtpcbd.nStreamNo, rtpcbd.sData, rtpcbd.nData);
        }
    }

    return 0;
}

int MyStatusCallBack(RTSP_CLIENT_STATUSCBDATA scbd)
{
    printf("[MyStatusCallBack] nStatusType %d, nStatusValue %d\r\n", scbd.nStatusType, scbd.nStatusValue);

    return 0;
}

int SetAudioVideoStreamNo()
{
    int nTotalStreamCount;
    int i = 0;
    int nType;

    nTotalStreamCount = RTSP_CLIENT_GetStreamCount(g_hRTSPClient);
    for (i = 0; i < nTotalStreamCount; i ++)
    {
        nType = RTSP_CLIENT_GetStreamType(g_hRTSPClient, i);
        if (nType == 100)
        {
            g_nH264StreamNo = i;
        }
        else if (
            (nType == 200)
            || (nType == 201)
            )
        {
            g_nAACStreamNo = i;
        }
    }

    return 0;
}

int TestGetSDP()
{
    if (g_hRTSPClient != NULL)
    {
        printf("[TestGetSDP] %s\r\n", RTSP_CLIENT_GetSDP(g_hRTSPClient));
    }

    return 0;
}

int TestGetProperty()
{
    RTSP_RTSP_VIDEOPROPERTY     videoProperty;
    RTSP_RTSP_AUDIOPROPERTY     audioProperty;

    if (g_hRTSPClient != NULL)
    {
        if (RTSP_CLIENT_GetVideoProperty(g_hRTSPClient, g_nH264StreamNo, &videoProperty) == 0)
        {
            printf("[TestGetProperty] get video property ok\n");
            RTSP_RTSP_FreeVideoProperty(&videoProperty);
        }

        if (RTSP_CLIENT_GetAudioProperty(g_hRTSPClient, g_nAACStreamNo, &audioProperty) == 0)
        {
            printf("[TestGetProperty] get audio property ok\n");
        }
    }

    return 0;
}

int DoRTSPClientTest()
{
#ifdef WIN32
    RTSP_RTSP_Init("C:\\chnsys\\RTSPLib", 20);
#else

    struct	sigaction	act;
    struct	rlimit		rl;

    act.sa_flags	= 0;
    act.sa_handler	= SIG_IGN;

    (void)::sigaction(SIGPIPE,	&act,	NULL);
    (void)::sigaction(SIGHUP,	&act,	NULL);
    (void)::sigaction(SIGINT,	&act,	NULL);
    (void)::sigaction(SIGTERM,	&act,	NULL);
    (void)::sigaction(SIGQUIT,	&act,	NULL);
    (void)::sigaction(SIGALRM,	&act,	NULL);

    rl.rlim_cur	= 10240;
    rl.rlim_max	= 10240;
    setrlimit(RLIMIT_NOFILE,&rl);

    rl.rlim_cur	= RLIM_INFINITY;
    rl.rlim_max	= RLIM_INFINITY;
    setrlimit(RLIMIT_CORE,&rl);


    RTSP_RTSP_Init("/home/chnsys/RTSPLib", 20);
#endif

    g_hRTSPClient = RTSP_CLIENT_CreateInstance();
    if (g_hRTSPClient != NULL)
    {
#ifdef WIN32
        g_hH264File = fopen("C:\\rtsp.h264", "w+b");
        g_hAACFile = fopen("C:\\rtsp.aac", "w+b");
#else
        //g_hH264File = fopen("/home/rtsp.h264", "w+b");
        g_hH264File = fopen("/mnt/hgfs/hisi/rtsp.h264", "w+b");
        //g_hAACFile = fopen("/home/rtsp.aac", "w+b");
        g_hAACFile = fopen("/mnt/hgfs/hisi/rtsp.aac", "w+b");
#endif

        RTSP_CLIENT_CONFIG cfg;
        //strcpy(cfg.sUrl, "rtsp://10.1.2.183/1");
        strcpy(cfg.sUrl, "rtsp://10.14.1.13/1");
        //strcpy(cfg.sUrl, "rtsp://admin:12345@10.14.1.76/");
        //strcpy(cfg.sUrl, "rtsp://10.1.15.228/1");
        cfg.nTransportType = 1;
        //cfg.nTransportType = 2;
        cfg.bSynchronizationMode = TRUE;
        cfg.nWaitSecond = 10;
        cfg.bReconnect = TRUE;
        cfg.nReconnectTryTimes = 0x7FFFFFFF;
        cfg.nReconnectInterval = 10;
        cfg.nRRPacketTimeInterval = 3;
        cfg.bAACRawDataOutputWithAdtsHeader = TRUE;

        RTSP_CLIENT_SetConfig(g_hRTSPClient, cfg);
        RTSP_CLIENT_SetRawDataCallBack(g_hRTSPClient, MyRawDataCallBack, NULL);
        RTSP_CLIENT_SetRtpDataCallBack(g_hRTSPClient, MyRtpDataCallBack, NULL);
        RTSP_CLIENT_SetStatusCallBack(g_hRTSPClient, MyStatusCallBack, NULL);
        if (RTSP_CLIENT_Play(g_hRTSPClient) == 0)
        {
            g_bPlaySuccess = TRUE;
            SetAudioVideoStreamNo();
            TestGetSDP();
            TestGetProperty();
        }

        DoRTSPServerTest();

        //getchar();
        RTSP_CLIENT_Stop(g_hRTSPClient);
        RTSP_CLIENT_DestroyInstance(g_hRTSPClient);
    }

    RTSP_RTSP_Uninit();

    return 0;
}

//////////////////////////////////////////////////////////////////////////

int MyServerStatusCallBack(RTSP_SERVER_STATUSCBDATA scbd)
{
    return 0;
}

int MyRequestCallBack(RTSP_SERVER_REQUESTCBDATA rcbd)
{
    if (g_hRTSPServer != NULL)
    {
        printf("[MyRequestCallBack] request url %s\r\n", rcbd.sRequestURL);
        *rcbd.phRTSPServer = g_hRTSPServer;
    }

    return 0;
}

int DoRTSPServerTest()
{
    //RTSP_RTSP_Init();

#if 1
    g_hRTSPServer = RTSP_SERVER_CreateInstance();
    if (g_hRTSPServer != NULL)
    {
        RTSP_SERVER_SetStatusCallBack(g_hRTSPServer, MyServerStatusCallBack, NULL);
        RTSP_SERVER_SetRequestCallBack(MyRequestCallBack, NULL);
        RTSP_SERVER_SetSDP(g_hRTSPServer, RTSP_CLIENT_GetSDP(g_hRTSPClient), strlen(RTSP_CLIENT_GetSDP(g_hRTSPClient)));
        RTSP_SERVER_Start(g_hRTSPServer);
        
        getchar();

        RTSP_SERVER_Stop(g_hRTSPServer);
        RTSP_SERVER_DestroyInstance(g_hRTSPServer);
    }
#endif

    //RTSP_RTSP_Uninit();

    return 0;
}
