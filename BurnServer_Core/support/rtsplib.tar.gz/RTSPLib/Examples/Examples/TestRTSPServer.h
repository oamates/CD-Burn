#ifndef _TESTRTSPSERVER_H_
#define _TESTRTSPSERVER_H_

int DoRTSPServerTest();

#endif //_TESTRTSPSERVER_H_
