#include <stdio.h>
#include "TestClient.h"

int main ()
{
    DoRTSPClientTest();

    return 0;
}
