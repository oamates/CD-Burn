#ifndef _TESTCLIENT_H_
#define _TESTCLIENT_H_

int DoRTSPClientTest();
int DoRTSPServerTest();

#endif //_TESTCLIENT_H_
