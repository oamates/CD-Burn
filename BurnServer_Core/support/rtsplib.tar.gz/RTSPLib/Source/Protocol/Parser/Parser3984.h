#ifndef _PARSER3984_H_
#define _PARSER3984_H_

#include "RTPParser.h"

class Parser3984
    : public RTPParser
{
protected:
    virtual int ProcessMarker(int nMarkerPos);
    virtual int GetFrequence();
protected:
    bool CheckSliceIsComplete(int nMarkerPos);
public:
    Parser3984();
    virtual ~Parser3984();
protected:
    BOOL     m_bFirstFrame;
};

#endif //_PARSER3984_H_
