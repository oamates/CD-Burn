#include "RTPParser.h"
#include "ZOSMutex.h"
#include "ZRTCPPacket.h"
#ifdef _WIN32_
#include <Winsock2.h>
#else
#endif


#define PROCESS_SPLICE_MAX_DURATION     (30)
#define PROCESS_SPLICE_MIN_DURATION     (10)

RTPParserListener::RTPParserListener()
{

}

RTPParserListener::~RTPParserListener()
{

}

BOOL RTPParserListener::ParserOnData(int nFlag, void*pData, int nData, long nTimestampSecond, long nTimestampUSecond)
{
    return TRUE;
}

RTPParser::RTPParser()
:ZTask("RTPParser")
,m_mutexRTPPacketPool("MutexRTPPacketPool")
,m_poolRTPPacket(0)
,m_mutexRTPPacketArray("MutexRTPPacketArray")
,m_arrayRTPPacket(100)
,m_nLastPacketSeq(-1)
,m_nSpliceThreshold(0)
,m_nParserFlag(0)
,m_nNetBufferMilliSecond(200)
,m_nTotalPacketCount(0)
,m_nLostPacketCount(0)
,m_pFrameBuffer(NULL)
,m_nCurFrameTimeStamp(0)
,m_nSyncTimestamp(0)
,m_nSyncNTPSecond(0)
,m_nSyncNTPUSecond(0)
,m_pParserListener(NULL)
,m_dLastCalcBitrateSecond(0)
,m_nPhaseBitCount(0)
,m_nBitrate(0)
,m_dLastCalcFrameRateSecond(0)
,m_nPhaseFrameCount(0)
,m_nFrameRate(0)
{
    //
}

RTPParser::~RTPParser()
{
    SAFE_DELETE_ARRAY(m_pFrameBuffer);
}

void RTPParser::SetPoolCount(int nCount)
{
    m_poolRTPPacket.SetSize(nCount);
}

void RTPParser::SetSpliceThreshold(int nCount)
{
    m_nSpliceThreshold = nCount;
}

int RTPParser::GetSpliceThreshold()
{
    return m_nSpliceThreshold;
}

void RTPParser::SetParserFlag(int nFlag)
{
    m_nParserFlag = nFlag;
}

int RTPParser::GetParserFlag()
{
    return m_nParserFlag;
}

BOOL RTPParser::SetUpperPin(ZDataOut *pDataUpper)
{
    return SetDataPin(pDataUpper);
}

UINT64 RTPParser::GetTotalPacketCount()
{
    return m_nTotalPacketCount;
}

UINT64 RTPParser::GetLostPacketCount()
{
    return m_nLostPacketCount;
}

int RTPParser::GetBitrate()
{
    return m_nBitrate;
}

int RTPParser::GetFrameRate()
{
    return m_nFrameRate;
}

void RTPParser::SetParserListener(RTPParserListener *pListener)
{
    m_pParserListener = pListener;
}

void RTPParser::SetNetBufferMilliSecond(int nMilliSecond)
{
    m_nNetBufferMilliSecond = nMilliSecond;
}

BOOL RTPParser::Start()
{
    ZTask::Create();
    ZTask::AddEvent(TASK_START_EVENT);
    
    return TRUE;
}

BOOL RTPParser::Stop()
{
    ZTask::Close();

    return TRUE;
}

BOOL RTPParser::OnCommand(int nCommand)
{
    ZDataInOut::OnCommand(nCommand);

    return TRUE;
}

BOOL RTPParser::OnHeader(int nFlag,void* pHeader,int nHeader)
{
    return TRUE;
}

BOOL RTPParser::OnData(int nFlag,void* pData,int nData)
{
    ReceivePacket((char *)pData, nData);
    m_nTotalPacketCount ++;

    return TRUE;
}

BOOL RTPParser::OnUserData(int nFlag,void* pData)
{
    if (nFlag == 1)
    {
        if (pData != NULL)
        {
            ZRTCPSRPacket   *pPacket = (ZRTCPSRPacket*)pData;
            if (
                (pPacket->GetRTPTimestamp() != 0)
                &&(pPacket->GetNTPTimestampMSW() != 0)
                )
            {
                m_nSyncTimestamp = pPacket->GetRTPTimestamp();
                //m_nSyncNTPSecond = pPacket->GetNTPTimestampMSW();
                //m_nSyncNTPUSecond = pPacket->GetNTPTimestampLSW();

                m_nSyncNTPSecond = pPacket->GetNTPTimestampMSW() - 0x83AA7E80; // 1/1/1900 -> 1/1/1970
                m_nSyncNTPUSecond = (unsigned)((pPacket->GetNTPTimestampLSW()*15625.0)/0x04000000+0.5);//// 10^6/2^32
            }
        }
    }
    return TRUE;
}
//
int RTPParser::Run(int nEvent)
{
    int		nTaskTime	= 0;
    UINT	nLocalEvent	= 0;

    nLocalEvent	= GetEvent(nEvent);
    ZTask::Run(nLocalEvent);

    if (nLocalEvent&TASK_UPDATE_EVENT)
    {
        nTaskTime = ProcessPacket();
    }

    return nTaskTime;
}

ZRTPPacket* RTPParser::ConstructPacket(char *pData, int nData)
{
    ZRTPPacket * pPacket = NULL;
    ZOSMutexLocker locker(&m_mutexRTPPacketPool);

    pPacket = (ZRTPPacket*)m_poolRTPPacket.GetFree();
    if (pPacket != NULL)
    {
        pPacket->SetPacketData(pData, nData);
        m_poolRTPPacket.SetUsed(pPacket);
    }

    return pPacket;
}

/**
 * insert packet pointer to array and ensure seq no in order
 */
BOOL RTPParser::AddPacketToArray(ZRTPPacket *pRTPPacket)
{
    int nCount = 0;
    DWORD nInputSeqNo = 0;
    int nCheckPos = 0;
    ZOSMutexLocker  locker(&m_mutexRTPPacketArray);

    if (pRTPPacket != NULL)
    {
        nInputSeqNo = pRTPPacket->GetSequence();
        nCount = m_arrayRTPPacket.Count();
        if (nCount > 0)
        {
            nCheckPos = nCount-1;
            while (nCheckPos >= 0)
            {
                if (
                    (m_arrayRTPPacket[nCheckPos]->GetSequence() < nInputSeqNo)
                    || (
                        (m_arrayRTPPacket[nCheckPos]->GetSequence()>nInputSeqNo)
                        && (m_arrayRTPPacket[nCheckPos]->GetSequence()-nInputSeqNo>0xF000)
                        )
                    )
                {
                    m_arrayRTPPacket.Insert(nCheckPos+1, pRTPPacket);
                    break;
                }
                else if (m_arrayRTPPacket[nCheckPos]->GetSequence() == nInputSeqNo)
                {
                    break;
                }
                else
                {
                    nCheckPos --;
                }
            }
            if (nCheckPos < 0)
            {// insert to begin
                m_arrayRTPPacket.Insert(0, pRTPPacket);
            }
        }
        else
        {
            m_arrayRTPPacket.Add(pRTPPacket);
        }
        return TRUE;
    }

    return FALSE;
}

BOOL RTPParser::ReceivePacket(char *pData, int nData)
{
    ZRTPPacket *pRTPPacket = NULL;
    BOOL        bNeedTriger = FALSE;

    do 
    {
        ProcessNetBufferOverflow();

        pRTPPacket = ConstructPacket(pData, nData);
        if (pRTPPacket != NULL)
        {
            AddPacketToArray(pRTPPacket);
            if (pRTPPacket->GetMarker() > 0)
            {// to triger splice process immediately
                bNeedTriger = TRUE;
            }
            break;
        }
        else
        {
            LOG_ERROR(("[RTPParser::ReceivePacket] pool is full\r\n"));
            ProcessMissingPacket();
            bNeedTriger = TRUE;
        }
    } while (pRTPPacket == NULL);

    if (bNeedTriger)
    {
        ZTask::AddEvent(ZTask::TASK_UPDATE_EVENT);
    }

    return TRUE;
}


int RTPParser::ProcessPacket()
{
    BOOL bProcessSplice = FALSE;
    int nMaxProcessCount = 20;

    while (
        ProcessSplice()
        && (nMaxProcessCount>0)
        )
    {
        bProcessSplice = TRUE;
        nMaxProcessCount --;
    }

    if (bProcessSplice)
    {
        return PROCESS_SPLICE_MAX_DURATION;
    }
    else
    {
        return PROCESS_SPLICE_MIN_DURATION;
    }
}

/**
 * 1 packet seq in order and increase by one. 
 * 2 until marker or pcmu pcma
 */
BOOL RTPParser::ProcessSplice()
{
    int nCurPos = 0;
    int nLastPacketSeq = m_nLastPacketSeq;
    int nCurPacketSeq = 0;
    BOOL bProcessSplice = FALSE;
    int nIndex = 0;
    ZOSMutexLocker  locker(&m_mutexRTPPacketArray);
    ZOSMutexLocker  lockerPool(&m_mutexRTPPacketPool);

    if (m_arrayRTPPacket.Count() > m_nSpliceThreshold)
    {
        while (nCurPos < m_arrayRTPPacket.Count())
        {
            if (m_arrayRTPPacket[nCurPos] != NULL)
            {
                nCurPacketSeq = m_arrayRTPPacket[nCurPos]->GetSequence();
                if (nLastPacketSeq == -1)
                {//process received first packet
                    nLastPacketSeq = nCurPacketSeq;
                }
                else
                {
                    if (
                        (//curseq-lastseq==1
                        (nCurPacketSeq > nLastPacketSeq)
                        && (nCurPacketSeq - nLastPacketSeq == 1)
                        )
                        || 
                        (//seq reverse
                        (nCurPacketSeq < nLastPacketSeq)
                        && (nLastPacketSeq - nCurPacketSeq > 0xF000)
                        )
                        )
                    {
                        nLastPacketSeq = nCurPacketSeq;
                    }
                    else
                    {// missing packet
                        break;
                    }
                }
                if (
                    (m_arrayRTPPacket[nCurPos]->GetMarker() != 0)
                    || (m_arrayRTPPacket[nCurPos]->GetPayload() == 0)
                    || (m_arrayRTPPacket[nCurPos]->GetPayload() == 8)
                    )
                {// marker is true, can splice one frame.or pcmu, pcma
                    bProcessSplice = TRUE;
                    ProcessRawRTP(nCurPos);
                    ProcessMarker(nCurPos);
                    m_nLastPacketSeq = nLastPacketSeq;
                    // release packet in pool
                    for (nIndex = 0; nIndex <= nCurPos; nIndex ++)
                    {
                        m_poolRTPPacket.SetFree(m_arrayRTPPacket[nIndex]);
                    }                   

                    // clear packet pointer form array
                    m_arrayRTPPacket.RemoveBefore(nCurPos);
                    break;
                }
            }

            nCurPos ++;
        }
    }

    return bProcessSplice;
}

int RTPParser::ProcessMissingPacket()
{
    int nCurPos = 0;
    int nLastPacketSeq = m_nLastPacketSeq;
    int nCurPacketSeq = 0;
    BOOL bProcessSplice = FALSE;
    int nIndex = 0;
    ZOSMutexLocker  locker(&m_mutexRTPPacketArray);
    ZOSMutexLocker  lockerPool(&m_mutexRTPPacketPool);

    //LOG_ERROR(("[RTPParser::ProcessMissingPacket] lose packet\r\n"));
    while (nCurPos < m_arrayRTPPacket.Count())
    {
        if (m_arrayRTPPacket[nCurPos] != NULL)
        {
            nCurPacketSeq = m_arrayRTPPacket[nCurPos]->GetSequence();
            if (nLastPacketSeq == -1)
            {//process first packet in the array
                nLastPacketSeq = nCurPacketSeq;
            }
            else
            {
                if (
                    (//curseq-lastseq==1
                    (nCurPacketSeq > nLastPacketSeq)
                    && (nCurPacketSeq - nLastPacketSeq == 1)
                    )
                    || 
                    (//seq reverse
                    (nCurPacketSeq < nLastPacketSeq)
                    && (nLastPacketSeq - nCurPacketSeq > 0xF000)
                    )
                    )
                {
                    nLastPacketSeq = nCurPacketSeq;
                }
                else
                {// missing packet
                    m_nLostPacketCount += (nCurPacketSeq-nLastPacketSeq);
                    m_nLastPacketSeq = nLastPacketSeq = nCurPacketSeq;
                }
            }
            if (m_arrayRTPPacket[nCurPos]->GetMarker() != 0)
            {// marker is true, can splice one frame
                bProcessSplice = TRUE;
                ProcessRawRTP(nCurPos);
                ProcessMarker(nCurPos);
                m_nLastPacketSeq = nLastPacketSeq;

                // release packet in pool
                for (nIndex = 0; nIndex <= nCurPos; nIndex ++)
                {
                    m_poolRTPPacket.SetFree(m_arrayRTPPacket[nIndex]);
                }                   

                // clear packet pointer form array
                m_arrayRTPPacket.RemoveBefore(nCurPos);
                break;
            }
        }

        nCurPos ++;
    }

    return bProcessSplice;
}

int RTPParser::ProcessNetBufferOverflow()
{
    int nTimeDurationOverflow = GetFrequence()*m_nNetBufferMilliSecond/1000;
    if (nTimeDurationOverflow > 0)
    {
        ZOSMutexLocker  locker(&m_mutexRTPPacketArray);
        if (m_arrayRTPPacket.Size() > 2)
        {
             int nCurTimeDuration = (int)(m_arrayRTPPacket[m_arrayRTPPacket.Size()-1]->GetTimeStamp() - m_arrayRTPPacket[0]->GetTimeStamp());
             if (nCurTimeDuration > nTimeDurationOverflow)
             {
                 LOG_DEBUG(("[RTPParser::ProcessNetBufferOverflow] %d %d\r\n", nCurTimeDuration, nTimeDurationOverflow));
                 //check if have marker.
                 for (int i = 0; i < m_arrayRTPPacket.Size(); i ++)
                 {
                     if (m_arrayRTPPacket[i]->GetMarker() != 0)
                     {//have marker
                         locker.Unlock();
                         ProcessMissingPacket();
                     }
                 }
             }
        }
    }

    return 0;
}

int RTPParser::ProcessRawRTP(int nMarkerPos)
{
    int nIndex = 0;
    char *pRTPPacket = NULL;
    int nRTPPacketLen = 0;

    while (nIndex <= nMarkerPos)
    {
        if (m_arrayRTPPacket[nIndex] != NULL)
        {
            pRTPPacket = m_arrayRTPPacket[nIndex]->GetPacketPointer();
            nRTPPacketLen = m_arrayRTPPacket[nIndex]->GetPacketLength();
            if (
                (pRTPPacket != NULL)
                && (nRTPPacketLen > 0)
                )
            {
                if (m_pParserListener != NULL)
                {
                    m_pParserListener->ParserOnData((100+m_nParserFlag), pRTPPacket, nRTPPacketLen, m_arrayRTPPacket[nIndex]->GetTimeStamp(), 0);
                }
            }
        }
        nIndex ++;
    }

    return 0;
}

int RTPParser::ProcessMarker(int nMarkerPos)
{
    return 0;
}

int RTPParser::GetFrequence()
{
    return 0;
}

int RTPParser::GetFrameTimestamp(int nFrequence, UINT nCurTimestamp, long *nNTPSecond, long *nNTPUSecond)
{
    struct timeval timeNow;
    ZOS::gettimeofdaycross(&timeNow, NULL);
    if (
        (m_nSyncNTPSecond == 0)
        && (m_nSyncNTPUSecond == 0)
        )
    {
        m_nSyncTimestamp = nCurTimestamp;
        m_nSyncNTPSecond = timeNow.tv_sec;
        m_nSyncNTPUSecond = timeNow.tv_usec;
    }

    int nDiffTimestamp = nCurTimestamp-m_nSyncTimestamp;
    double dDiffTime = nDiffTimestamp/(double)nFrequence;
    unsigned long nMillion = 1000000;
    unsigned long nSeconds;
    unsigned long nUSeconds;

    if (dDiffTime >= 0.0)
    {
        nSeconds = m_nSyncNTPSecond + (unsigned)(dDiffTime);
        nUSeconds = m_nSyncNTPUSecond + (unsigned)((dDiffTime-(unsigned)dDiffTime)*nMillion);
        if (nUSeconds >= nMillion)
        {
            nUSeconds -= nMillion;
            ++ nSeconds;
        }
    }
    else
    {
        dDiffTime = -dDiffTime;
        nSeconds = m_nSyncNTPSecond - (unsigned)dDiffTime;
        nUSeconds = m_nSyncNTPUSecond - (unsigned)((dDiffTime-(unsigned)dDiffTime)*nMillion);
        if ((int)nUSeconds < 0)
        {
            nUSeconds += nMillion;
            -- nSeconds;
        }
    }

    m_nSyncTimestamp = nCurTimestamp;
    *nNTPSecond = m_nSyncNTPSecond = nSeconds;
    *nNTPUSecond = m_nSyncNTPUSecond = nUSeconds;

    return 0;
}

void RTPParser::CalculateFrameRate(double dCurrentFrameSecond)
{
    if (m_dLastCalcFrameRateSecond == 0)
    {
        m_dLastCalcFrameRateSecond = dCurrentFrameSecond;
    }

    m_nPhaseFrameCount ++;

    if ((dCurrentFrameSecond - m_dLastCalcFrameRateSecond)>1)
    {
        m_nFrameRate = (int)((double)m_nPhaseFrameCount/(dCurrentFrameSecond-m_dLastCalcFrameRateSecond));
        m_nPhaseFrameCount = 0;
        m_dLastCalcFrameRateSecond = dCurrentFrameSecond;
    }
}

void RTPParser::CalculateBitrate(double dCurrentFrameSecond, int nCurrentFrameBitCount)
{
    if (m_dLastCalcBitrateSecond == 0)
    {
        m_dLastCalcBitrateSecond = dCurrentFrameSecond;
    }

    m_nPhaseBitCount += nCurrentFrameBitCount;

    if ((dCurrentFrameSecond - m_dLastCalcBitrateSecond) > 1)
    {
        m_nBitrate = (int)((double)m_nPhaseBitCount/(dCurrentFrameSecond-m_dLastCalcBitrateSecond));
        m_nPhaseBitCount = 0;
        m_dLastCalcBitrateSecond = dCurrentFrameSecond;
    }
}

