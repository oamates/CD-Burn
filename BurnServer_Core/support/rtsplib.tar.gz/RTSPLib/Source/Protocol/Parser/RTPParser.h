#ifndef _RTPPARSER_H_
#define _RTPPARSER_H_

#include "Common.h"
#include "ZOSPool.h"
#include "ZDataPin.h"
#include "ZTask.h"
#include "ZRTPPacket.h"
#include "ZOSArray.h"

#define AACFRAME_MAX_SIZE   (1024)
#define H264NAL_MAX_SIZE    (1920*540)
#define G711FRAME_MAX_SIZE  (1024*10)

class RTPParserListener
{
public:
    virtual BOOL ParserOnData(int nFlag, void*pData, int nData, 
        long nTimestampSecond, long nTimestampUSecond);
public:
    RTPParserListener();
    virtual ~RTPParserListener();
};

class RTPParser
    : public ZDataInOut
    , public ZTask
{
public:
    void SetPoolCount(int nCount);
    void SetSpliceThreshold(int nCount);
    int GetSpliceThreshold();
    void SetParserFlag(int nFlag);
    int GetParserFlag();
    BOOL SetUpperPin(ZDataOut *pDataUpper);
    UINT64 GetTotalPacketCount();
    UINT64 GetLostPacketCount();
    int GetBitrate();
    int GetFrameRate();
    void SetParserListener(RTPParserListener *pListener);
    void SetNetBufferMilliSecond(int nMilliSecond);
    BOOL Start();
    BOOL Stop();
public:
    // override ZDataInOut function
    virtual	BOOL OnCommand(int nCommand);
    virtual	BOOL OnHeader(int nFlag,void* pHeader,int nHeader);
    virtual	BOOL OnData(int nFlag,void* pData,int nData);
    virtual BOOL OnUserData(int nFlag,void* pData);
public:
    // override ZTask function
    virtual	int Run(int nEvent = 0);
protected:
    ZRTPPacket* ConstructPacket(char *pData, int nData);
    BOOL AddPacketToArray(ZRTPPacket *pRTPPacket);
    BOOL ReceivePacket(char *pData, int nData);

    int ProcessPacket();
    BOOL ProcessSplice();
    int ProcessMissingPacket();

    int ProcessNetBufferOverflow();

    virtual int ProcessRawRTP(int nMarkerPos);
    virtual int ProcessMarker(int nMarkerPos);
    virtual int GetFrequence();

    int GetFrameTimestamp(int nFrequence, UINT nCurTimestamp, long *nNTPSecond, long *nNTPUSecond);
    void CalculateFrameRate(double dCurrentFrameSecond);
    void CalculateBitrate(double dCurrentFrameSecond, int nCurrentFrameBitCount);
public:
    RTPParser();
    virtual ~RTPParser();
protected:
    ZOSMutex                m_mutexRTPPacketPool;
    ZOSPool<ZRTPPacket>     m_poolRTPPacket;
    ZOSMutex                m_mutexRTPPacketArray;
    ZOSArray<ZRTPPacket *>  m_arrayRTPPacket;

    int                     m_nLastPacketSeq;

    // less than this value will not do splice process.
    // will be usefull in audio rtp packet when marker bit is true,
    // but seq no is not in order.
    int                     m_nSpliceThreshold;
    int                     m_nParserFlag;

    int                     m_nNetBufferMilliSecond;

    UINT64                  m_nTotalPacketCount;
    UINT64                  m_nLostPacketCount;

    CHAR                    *m_pFrameBuffer;
    UINT                    m_nCurFrameTimeStamp;

    UINT                    m_nSyncTimestamp;
    long                    m_nSyncNTPSecond;
    long                    m_nSyncNTPUSecond;

    RTPParserListener       *m_pParserListener;

    double                  m_dLastCalcBitrateSecond;
    int                     m_nPhaseBitCount;
    int                     m_nBitrate;

    double                  m_dLastCalcFrameRateSecond;
    int                     m_nPhaseFrameCount;
    int                     m_nFrameRate;
};

#endif //_RTPPARSER_H_
