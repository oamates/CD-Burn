#include "Parser3984.h"

Parser3984::Parser3984()
: RTPParser()
{
    m_pFrameBuffer = NEW char[H264NAL_MAX_SIZE];
    m_bFirstFrame = TRUE;
    SetPoolCount(800);
}

Parser3984::~Parser3984()
{
    //
}

int Parser3984::ProcessMarker(int nMarkerPos)
{
    int nIndex = 0;
    int nCurSize = 0;
    char *pRTPPacket = NULL;
    int nRTPPacketPayloadLen = 0;
    BOOL bAbandon = FALSE;
    long nNTPSecond;
    long nNTPUSecond;
    int nCurrentFrameBitCount = 0;

    if (!CheckSliceIsComplete(nMarkerPos))
    {
        bAbandon = TRUE;
    }

    if (m_pFrameBuffer != NULL)
    {
        int nSeqNo = -1;
        //LOG_DEBUG(("[Parser3984::ProcessMarker] nMarkerPos = %d\r\n", nMarkerPos));
        while (nIndex <= nMarkerPos)
        {
            if (m_arrayRTPPacket[nIndex] != NULL)
            {
                pRTPPacket = m_arrayRTPPacket[nIndex]->GetPacketPointer();
                nRTPPacketPayloadLen = m_arrayRTPPacket[nIndex]->GetPacketPayloadLength();

                if (nSeqNo == -1)
                {
                    nSeqNo = m_arrayRTPPacket[nIndex]->GetSequence();
                }
                if (nSeqNo == 0xFFFF)
                {
                    nSeqNo = m_arrayRTPPacket[nIndex]->GetSequence();
                }
                if (nSeqNo != m_arrayRTPPacket[nIndex]->GetSequence())
                {
                    if (m_arrayRTPPacket[nIndex]->GetSequence() != nSeqNo + 1)
                    {
                        LOG_ERROR(("[Parser3984::ProcessMarker] seq in a nal is wrong. last seq %d, current seq %d\r\n",
                            nSeqNo, m_arrayRTPPacket[nIndex]->GetSequence()));
                    }
                }
                nSeqNo = m_arrayRTPPacket[nIndex]->GetSequence();

                if (
                    (pRTPPacket != NULL)
                    && (nRTPPacketPayloadLen > 0)
                    )
                {
                    if ((*(pRTPPacket+12)&0x1F) == 28)
                    {
                        //LOG_DEBUG(("[Parser3984::ProcessMarker] seqno = %d\r\n", m_arrayRTPPacket[nIndex]->GetSequence()));
                        TMASSERT((nMarkerPos>=0));
                        
                        if (
                            m_bFirstFrame
                            &&((pRTPPacket[13]&0x80)==0)
                            )
                        {// receive first nal is not complete, abandon it.
                            bAbandon = TRUE;
                        }

                        if ((pRTPPacket[13]&0x80)==0x80)
                        {// process start bit.
                            m_pFrameBuffer[0] = 0x00;
                            m_pFrameBuffer[1] = 0x00;
                            m_pFrameBuffer[2] = 0x00;
                            m_pFrameBuffer[3] = 0x01;
                            nCurSize += 4;
                            m_pFrameBuffer[nCurSize] = (pRTPPacket[12]&0xE0)|(pRTPPacket[13]&0x1F);
                            nCurSize ++;
                            nCurrentFrameBitCount += 8;
                        }
                        memcpy(m_pFrameBuffer+nCurSize, pRTPPacket+14, nRTPPacketPayloadLen-14);
                        nCurSize += (nRTPPacketPayloadLen-14);
                        nCurrentFrameBitCount += ((nRTPPacketPayloadLen-14)*8);
                    }
                    else
                    {
                        m_pFrameBuffer[nCurSize] = 0x00;
                        m_pFrameBuffer[nCurSize+1] = 0x00;
                        m_pFrameBuffer[nCurSize+2] = 0x00;
                        m_pFrameBuffer[nCurSize+3] = 0x01;
                        nCurSize += 4;
                        memcpy(m_pFrameBuffer+nCurSize, pRTPPacket+12, nRTPPacketPayloadLen-12);
                        nCurSize += (nRTPPacketPayloadLen-12);
                        nCurrentFrameBitCount += ((nRTPPacketPayloadLen-12)*8);
                        if (
                            ((*(pRTPPacket+12)&0x1F) == 7)
                            || ((*(pRTPPacket+12)&0x1F) == 8)
                            || ((*(pRTPPacket+12)&0x1F) == 6)
                            )
                        {// if sps, pps, sei, do callback immediately.
                            if (!bAbandon)
                            {
                                if (m_pParserListener != NULL)
                                {
                                    GetFrameTimestamp(90000, m_arrayRTPPacket[0]->GetTimeStamp(), &nNTPSecond, &nNTPUSecond);
                                    UINT64 nTimeStart = ZOS::milliseconds();
                                    m_pParserListener->ParserOnData(m_nParserFlag, m_pFrameBuffer, nCurSize, nNTPSecond, nNTPUSecond);
                                    int nTimeUsed = (int)(ZOS::milliseconds() - nTimeStart);
                                    if (nTimeUsed > 100)
                                    {
                                        LOG_ERROR(("[Parser3984::ProcessMarker] callback use over 100 millisecond %d\r\n", nTimeUsed));
                                    }
                                }
                            }
                            nCurSize = 0;
                        }
                    }
                }
            }
            nIndex ++;
        }

        if (!bAbandon)
        {
            if (m_pParserListener != NULL)
            {
                GetFrameTimestamp(90000, m_arrayRTPPacket[0]->GetTimeStamp(), &nNTPSecond, &nNTPUSecond);
                m_pParserListener->ParserOnData(m_nParserFlag, m_pFrameBuffer, nCurSize, nNTPSecond, nNTPUSecond);
            }
        }

        CalculateBitrate(nNTPSecond+(double)nNTPUSecond/1000000.0, nCurrentFrameBitCount);
        CalculateFrameRate(nNTPSecond+(double)nNTPUSecond/1000000.0);
    }
    m_bFirstFrame = FALSE;

    return 0;
}

int Parser3984::GetFrequence()
{
    return 90000;
}

bool Parser3984::CheckSliceIsComplete(int nMarkerPos)
{
    bool bIsComplete = true;
    int  nSeqNo = 0;

    if (nMarkerPos > 1)
    {
        if (
            (m_arrayRTPPacket[nMarkerPos] != NULL)
            && (m_arrayRTPPacket[0] != NULL)
            && (m_arrayRTPPacket[nMarkerPos]->GetSequence() > m_arrayRTPPacket[0]->GetSequence())
            )
        {//no seq reverse
            if (m_arrayRTPPacket[nMarkerPos]->GetSequence() - m_arrayRTPPacket[0]->GetSequence() > nMarkerPos)
            {//lose packet
                bIsComplete = false;
            }
        }
        else
        {//seq reverse
            int nLastPacketSeq = 0;
            int nCurPacketSeq;
            int nIndex = 0;
            if (m_arrayRTPPacket[0] != NULL)
            {
                nLastPacketSeq = m_arrayRTPPacket[0]->GetSequence();
            }

            nIndex = 1;
            while (nIndex <= nMarkerPos)
            {
                if (m_arrayRTPPacket[nIndex] != NULL)
                {
                    nCurPacketSeq = m_arrayRTPPacket[nIndex]->GetSequence();
                    if (nCurPacketSeq > nLastPacketSeq)
                    {
                        if (nCurPacketSeq - nLastPacketSeq == 1)
                        {
                            nLastPacketSeq = nCurPacketSeq;
                            //ok
                        }
                        else
                        {
                            //lose packet
                            bIsComplete = false;
                            break;
                        }
                    }
                    else
                    {
                        nLastPacketSeq = nCurPacketSeq;
                    }
                }
                nIndex ++;
            }
        }
    }

    return bIsComplete;
}

