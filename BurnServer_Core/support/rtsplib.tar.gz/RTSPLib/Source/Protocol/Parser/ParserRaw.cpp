#include "ParserRaw.h"

ParserRaw::ParserRaw()
: RTPParser()
{
    //
}

ParserRaw::~ParserRaw()
{
    //
}

int ParserRaw::ProcessPacket()
{
    return 10;
}
