#include "Parser3640.h"
#include "AACUtil.h"

Parser3640::Parser3640()
: RTPParser()
{
    m_pFrameBuffer = NEW char [AACFRAME_MAX_SIZE];
    SetSpliceThreshold(6);
    SetPoolCount(200);

    m_nObjType = 1;
    m_nSampleRate = 0;
    m_nChannel = 2;
    m_bWithAdtsHeader = FALSE;
}

Parser3640::~Parser3640()
{
    //
}

void Parser3640::SetAdtsHeaderParameter(int nObjectType, int nSampleRate, int nChannels, BOOL bWithAdtsHeader)
{
    m_nObjType = nObjectType;
    m_nSampleRate = nSampleRate;
    m_nChannel = nChannels;
    m_bWithAdtsHeader = bWithAdtsHeader;
}

int Parser3640::ProcessMarker(int nMarkerPos)
{
    char *pRTPPacket = NULL;
    int nRTPPacketPayloadLen = 0;
    unsigned char sAdtsHeader[7];
    long nNTPSecond;
    long nNTPUSecond;
    int nCurrentFrameBitCount = 0;

    TMASSERT((nMarkerPos == 0));
    if (m_pFrameBuffer != NULL)
    {
        if (m_arrayRTPPacket[0] != NULL)
        {
            nCurrentFrameBitCount = (nRTPPacketPayloadLen-12-4)*8;
            pRTPPacket = m_arrayRTPPacket[0]->GetPacketPointer();
            nRTPPacketPayloadLen = m_arrayRTPPacket[0]->GetPacketPayloadLength();
            if (m_bWithAdtsHeader)
            {
                memset(sAdtsHeader, 0, 7);
                FormatADTSHeader(1, nRTPPacketPayloadLen-12-4, m_nSampleRate, m_nChannel, sAdtsHeader);
                memcpy(m_pFrameBuffer, sAdtsHeader, 7);
                //
                memcpy(m_pFrameBuffer+7, pRTPPacket+12+4, nRTPPacketPayloadLen-12-4);

                if (m_pParserListener != NULL)
                {
                    GetFrameTimestamp(m_nSampleRate, m_arrayRTPPacket[0]->GetTimeStamp(), &nNTPSecond, &nNTPUSecond);
                    m_pParserListener->ParserOnData(m_nParserFlag, m_pFrameBuffer, nRTPPacketPayloadLen-12-4+7, nNTPSecond, nNTPUSecond);
                }
            }
            else
            {
                memcpy(m_pFrameBuffer, pRTPPacket+12+4, nRTPPacketPayloadLen-12-4);

                if (m_pParserListener != NULL)
                {
                    GetFrameTimestamp(m_nSampleRate, m_arrayRTPPacket[0]->GetTimeStamp(), &nNTPSecond, &nNTPUSecond);
                    m_pParserListener->ParserOnData(m_nParserFlag, m_pFrameBuffer, nRTPPacketPayloadLen-12-4, nNTPSecond, nNTPUSecond);
                }
            }

            CalculateBitrate(nNTPSecond+(double)nNTPUSecond/1000000.0, nCurrentFrameBitCount);
            CalculateFrameRate(nNTPSecond+(double)nNTPUSecond/1000000.0);
        }
    }

    return 0;
}

int Parser3640::GetFrequence()
{
    return m_nSampleRate;
}
