#include "RTSPServerListenerManager.h"
#include "RemoteRTSPClient.h"

RTSPServerListenerManager * RTSPServerListenerManager::m_pInstance = NULL;

RTSPServerListenerManager::RTSPServerListenerManager()
: m_arrayRemoteRTSPClient(100)
, m_mutexRemoteRTSPClientArray("Mutex_RemoteRTSPClientArray")
, m_Listener()
, m_RequestCallBackFunc(NULL)
, m_prcbfContext(NULL)
{
    m_Listener.Create(0, 554);
    m_Listener.SetListenerEvent(this);
}

RTSPServerListenerManager::~RTSPServerListenerManager()
{
    m_Listener.Close();
}

RTSPServerListenerManager* RTSPServerListenerManager::GetInstance()
{
    if (m_pInstance == NULL)
    {
        m_pInstance = NEW RTSPServerListenerManager;
    }

    return m_pInstance;
}

void RTSPServerListenerManager::Initialize()
{
    RTSPServerListenerManager::GetInstance();
}

void RTSPServerListenerManager::Uninitialize()
{
    SAFE_DELETE(m_pInstance);
}

void RTSPServerListenerManager::SetRequestCallBack(RTSP_SERVER_RequestCallBackFunc rcbf, void *pContext)
{
    m_RequestCallBackFunc = rcbf;
    m_prcbfContext = pContext;
}

BOOL RTSPServerListenerManager::OnFirstCommand(ZRTSPSession *pRTSPSession, CHAR *sRequestUrl)
{
    RTSP_SERVER_REQUESTCBDATA rcbd;
    RTSP_SERVER_HANDLE hRTSPServer = NULL;
    RTSPServerSource *pServerSource = NULL;
    ZOSMutexLocker  locker(&m_mutexRemoteRTSPClientArray);

    if (m_RequestCallBackFunc != NULL)
    {
        strncpy(rcbd.sRequestURL, sRequestUrl, 1024);
        rcbd.sRequestURL[1023] = '\0';
        rcbd.phRTSPServer = &hRTSPServer;
        m_RequestCallBackFunc(rcbd);

        // know this ZRTSPSession is bind with which RTSPServerSource
        if (hRTSPServer != NULL)
        {
            pServerSource = (RTSPServerSource *)hRTSPServer;
            pRTSPSession->SetRTSPServerListener(pServerSource);
            pServerSource->AddRemoteRTSPClient(GetRemoteRTSPClient(pRTSPSession));
            DeleteRemoteRTSPClient(pRTSPSession);
        }
    }

    return TRUE;
}

RemoteRTSPClient *RTSPServerListenerManager::GetRemoteRTSPClient(ZRTSPSession *pRTSPSession)
{
    int i = 0;
    ZOSMutexLocker  locker(&m_mutexRemoteRTSPClientArray);

    for (i = 0; i < m_arrayRemoteRTSPClient.Count(); i ++)
    {
        if (
            (m_arrayRemoteRTSPClient[i] != NULL)
            && m_arrayRemoteRTSPClient[i]->IsMe(pRTSPSession)
            )
        {
            return m_arrayRemoteRTSPClient[i];
        }
    }

    return NULL;
}

BOOL RTSPServerListenerManager::DeleteRemoteRTSPClient(ZRTSPSession *pRTSPSession)
{
    int i = 0;
    BOOL bReturn = FALSE;
    ZOSMutexLocker  locker(&m_mutexRemoteRTSPClientArray);

    for (i = 0; i < m_arrayRemoteRTSPClient.Count(); i ++)
    {
        if (
            (m_arrayRemoteRTSPClient[i] != NULL)
            && m_arrayRemoteRTSPClient[i]->IsMe(pRTSPSession)
            )
        {
            m_arrayRemoteRTSPClient.Remove(i);
            bReturn = TRUE;
        }
    }

    return bReturn;
}

BOOL RTSPServerListenerManager::OnListenerEvent(const int hAccept,const struct sockaddr_in* pLocalAddr,const struct sockaddr_in* pRemoteAddr)
{
    RemoteRTSPClient *pClient = NULL;
    ZOSMutexLocker  locker(&m_mutexRemoteRTSPClientArray);

    if (hAccept > 0)
    {
        pClient = NEW RemoteRTSPClient;
        if (pClient != NULL)
        {
            if (pClient->Create(hAccept, pRemoteAddr))
            {
                pClient->SetRTSPProtocolListener(this);
                m_arrayRemoteRTSPClient.Add(pClient);
                return TRUE;
            }
        }        
    }

    return FALSE;
}
