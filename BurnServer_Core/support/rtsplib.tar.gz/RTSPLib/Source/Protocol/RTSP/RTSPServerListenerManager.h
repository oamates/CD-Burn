#ifndef _RTSPSERVERLISTENERMANAGER_H_
#define _RTSPSERVERLISTENERMANAGER_H_

#include "ZOSArray.h"
#include "ZSocket.h"
#include "RTSPServerListener.h"
#include "RTSPServerSource.h"
#include "ZTCPListenerSocket.h"
#include "RemoteRTSPClient.h"

typedef ZOSArray<RemoteRTSPClient*>     RemoteRTSPClientArray;

class RTSPServerListenerManager
    : public RTSPServerListener
    , public ZTCPListenerEvent
{
public:
    void SetRequestCallBack(RTSP_SERVER_RequestCallBackFunc rcbf, void *pContext);
public:
    virtual BOOL OnFirstCommand(ZRTSPSession *pRTSPSession, CHAR *sRequestUrl);
//////////////////////////////////////////////////////////////////////////
protected:
    RemoteRTSPClient * GetRemoteRTSPClient(ZRTSPSession *pRTSPSession);
    BOOL DeleteRemoteRTSPClient(ZRTSPSession *pRTSPSession);
//////////////////////////////////////////////////////////////////////////
public:
    virtual	BOOL OnListenerEvent(const int hAccept,const struct sockaddr_in* pLocalAddr,const struct sockaddr_in* pRemoteAddr);
public:
    static RTSPServerListenerManager* GetInstance();
    static void Initialize();
    static void Uninitialize();
public:
    RTSPServerListenerManager();
    virtual ~RTSPServerListenerManager();
private:
    static RTSPServerListenerManager    *m_pInstance;
private:
    RemoteRTSPClientArray           m_arrayRemoteRTSPClient;
    ZOSMutex                        m_mutexRemoteRTSPClientArray;
    ZTCPListenerSocket              m_Listener;

private:
    RTSP_SERVER_RequestCallBackFunc     m_RequestCallBackFunc;
    void                                *m_prcbfContext;
};

#endif //_RTSPSERVERLISTENERMANAGER_H_
