#include "RTSPClientSource.h"
#include "SDPUtil.h"
#include "ZTCPSocket.h"
#include "Parser3984.h"
#include "Parser3640.h"
#include "Parser3016.h"
#include "ParserG711.h"
#include "NalUtil.h"

#define DEFAULT_CHECK_RTSPSTATE_TIME		(1000)

RTSPClientSource::RTSPClientSource()
: ZIdleTask("RTSPClientSource")
, m_arrayParser(8)
, m_pSocket(NULL)
, m_pRTSPSession(NULL)
, m_bSessionTimeout(FALSE)
, m_nAlreadyReconnectTimes(0)
, m_nSessionStartTime(0)
, m_nSessionStopTime(0)
, m_bIsPlaying(FALSE)
, m_nNetBufferMilliSecond(200)
, m_StatusCallBackFunc(NULL)
, m_pscbfContext(NULL)
, m_RtpCallBackFunc(NULL)
, m_prcbfContext(NULL)
, m_RawDataCallBackFunc(NULL)
, m_prdcbfContext(NULL)
{
    memset(m_Config.sUrl, 0, 1024);
    m_Config.nTransportType = 1;
    m_Config.bSynchronizationMode = TRUE;
    m_Config.nWaitSecond = 10;
    m_Config.bReconnect = TRUE;
    m_Config.nReconnectTryTimes = 0x7FFFFFFF;
    m_Config.nReconnectInterval = 10;
    m_Config.nRRPacketTimeInterval = 3;
    m_Config.bAACRawDataOutputWithAdtsHeader = FALSE;
}

RTSPClientSource::~RTSPClientSource()
{
    DoStop();
}

void RTSPClientSource::SetStatusCallBack(RTSP_CLIENT_StatusCallBackFunc scbf, void* pContext)
{
    m_StatusCallBackFunc = scbf;
    m_pscbfContext = pContext;
}

void RTSPClientSource::SetRtpDataCallBack(RTSP_CLIENT_RtpCallBackFunc rtpcbf, void* pContext)
{
    m_RtpCallBackFunc = rtpcbf;
    m_prcbfContext = pContext;
}

void RTSPClientSource::SetRawDataCallBack(RTSP_CLIENT_RawDataCallBackFunc rdcbf, VOID* pContext)
{
    m_RawDataCallBackFunc = rdcbf;
    m_prdcbfContext = pContext;
}

void RTSPClientSource::GetStatistics(int nStreamNo, RTSP_CLIENT_STATISTICSDATA *pStatistics)
{

    if (pStatistics != NULL)
    {
        if (m_nSessionStopTime == 0)
        {
            pStatistics->nSessionDuration = (UINT)((ZOS::milliseconds()-m_nSessionStartTime)/1000);
        }
        else
        {
            pStatistics->nSessionDuration = (UINT)((m_nSessionStopTime-m_nSessionStartTime)/1000);
        }

        if (nStreamNo < m_arrayParser.Size())
        {
            pStatistics->nTotalPacketCount = m_arrayParser[nStreamNo]->GetTotalPacketCount();
            pStatistics->nTotalLostPacketCount = m_arrayParser[nStreamNo]->GetLostPacketCount();
        }
    }
}

char* RTSPClientSource::GetSDP()
{
    if (m_pRTSPSession != NULL)
    {
        return m_pRTSPSession->GetContent();
    }
    return NULL;
}

int RTSPClientSource::GetStreamCount()
{
    if (m_pRTSPSession != NULL)
    {
        return m_pRTSPSession->GetDataStreamCount();
    }
    else
    {
        return 0;
    }
}

int RTSPClientSource::GetStreamType(int nStreamNo)
{
    if (m_pRTSPSession != NULL)
    {
        return SDP_GetStreamType(m_pRTSPSession->GetContent(), 
            m_pRTSPSession->GetContentLength(), nStreamNo);
    }

    return -1;
}

int RTSPClientSource::GetVideoProperty(int nStreamNo, RTSP_RTSP_VIDEOPROPERTY *pVideoProperty)
{
    int nStreamType;

    if (
        (pVideoProperty != NULL)
        && (nStreamNo < m_arrayParser.Size())
        )
    {
        nStreamType = SDP_GetStreamType(m_pRTSPSession->GetContent(), 
            m_pRTSPSession->GetContentLength(), nStreamNo);
        if (nStreamType == 100)
        {
            pVideoProperty->nEncodeType = 1;
        }
        pVideoProperty->pSPS = NEW char[4096];
        pVideoProperty->nSPS = 4096;
        pVideoProperty->pPPS = NEW char[4096];
        pVideoProperty->nPPS = 4096;
        SDP_GetSpsPps(m_pRTSPSession->GetContent(), m_pRTSPSession->GetContentLength(), nStreamNo,
            pVideoProperty->pSPS, &pVideoProperty->nSPS, pVideoProperty->pPPS, &pVideoProperty->nPPS);
        pVideoProperty->nTimeBase = 90000;
        NALUTIL_ParseSPS(pVideoProperty->pSPS, pVideoProperty->nSPS, 
            &pVideoProperty->nProfile, &pVideoProperty->nLevel,
            &pVideoProperty->nWidth, &pVideoProperty->nHeight);
        pVideoProperty->nBitrate = m_arrayParser[nStreamNo]->GetBitrate();
        pVideoProperty->nFrameRate = m_arrayParser[nStreamNo]->GetFrameRate();

        return 0;
    }

    return -1;
}

int RTSPClientSource::GetAudioProperty(int nStreamNo, RTSP_RTSP_AUDIOPROPERTY *pAudioProperty)
{
    int nStreamType;

    if (pAudioProperty != NULL)
    {
        nStreamType = SDP_GetStreamType(m_pRTSPSession->GetContent(), m_pRTSPSession->GetContentLength(),
            nStreamNo);
        if (nStreamType == 200)
        {
            pAudioProperty->nEncodeType = 1;
            pAudioProperty->nPayloadFormatType = 1;
            SDP_GetAACAudioProperty(m_pRTSPSession->GetContent(), m_pRTSPSession->GetContentLength(), 
                nStreamNo, &pAudioProperty->nSampleRate, &pAudioProperty->nChannelNo);
            pAudioProperty->nTimeBase = pAudioProperty->nSampleRate;
        }
        else if (nStreamType == 201)
        {
            pAudioProperty->nEncodeType = 1;
            pAudioProperty->nPayloadFormatType = 2;
            SDP_GetAACAudioProperty(m_pRTSPSession->GetContent(), m_pRTSPSession->GetContentLength(), 
                nStreamNo, &pAudioProperty->nSampleRate, &pAudioProperty->nChannelNo);
            pAudioProperty->nTimeBase = pAudioProperty->nSampleRate;
        }
        else if (nStreamType == 300)
        {
            pAudioProperty->nEncodeType = 2;
            pAudioProperty->nPayloadFormatType = 0;
            pAudioProperty->nTimeBase = 8000;
            pAudioProperty->nSampleRate = 8000;
            pAudioProperty->nChannelNo = 1;
        }
        else if (nStreamType == 301)
        {
            pAudioProperty->nEncodeType = 3;
            pAudioProperty->nPayloadFormatType = 0;
            pAudioProperty->nTimeBase = 8000;
            pAudioProperty->nSampleRate = 8000;
            pAudioProperty->nChannelNo = 1;
        }
        pAudioProperty->nBitrate = m_arrayParser[nStreamNo]->GetBitrate();
    }

    return 0;
}

char* RTSPClientSource::GetMediaFromSDP(int nStreamNo, char *sMedia, int *pMediaSize)
{
    if (m_pRTSPSession != NULL)
    {
        SDP_GetMedia(m_pRTSPSession->GetContent(), m_pRTSPSession->GetContentLength(), nStreamNo, sMedia);
        if (pMediaSize != NULL)
        {
            *pMediaSize = strlen(sMedia);
        }
        return sMedia;
    }

    return NULL;
}

void RTSPClientSource::GetConfig(RTSP_CLIENT_CONFIG *pConfig)
{
    if (pConfig != NULL)
    {
        strncpy(pConfig->sUrl, m_Config.sUrl, 1024);
        pConfig->sUrl[1023] = '\0';
        pConfig->nTransportType = m_Config.nTransportType;
        pConfig->bSynchronizationMode = m_Config.bSynchronizationMode;
        pConfig->nWaitSecond = m_Config.nWaitSecond;
        pConfig->bReconnect = m_Config.bReconnect;
        pConfig->nReconnectTryTimes = m_Config.nReconnectTryTimes;
        pConfig->nReconnectInterval = m_Config.nReconnectInterval;
        pConfig->nRRPacketTimeInterval = m_Config.nRRPacketTimeInterval;
        pConfig->bAACRawDataOutputWithAdtsHeader = m_Config.bAACRawDataOutputWithAdtsHeader;
    }
}

int RTSPClientSource::SetConfig(RTSP_CLIENT_CONFIG config)
{
    strncpy(m_Config.sUrl, config.sUrl, 1024);
    m_Config.sUrl[1023] = '\0';
    m_Config.nTransportType = config.nTransportType;
    m_Config.bSynchronizationMode = config.bSynchronizationMode;
    if (config.nWaitSecond <= 0)
    {
        config.nWaitSecond = 10;
    }
    m_Config.nWaitSecond = config.nWaitSecond;
    m_Config.bReconnect = config.bReconnect;
    m_Config.nReconnectTryTimes = config.nReconnectTryTimes;
    m_Config.nReconnectInterval = config.nReconnectInterval;
    m_Config.nRRPacketTimeInterval = config.nRRPacketTimeInterval;
    m_Config.bAACRawDataOutputWithAdtsHeader = config.bAACRawDataOutputWithAdtsHeader;

    return 0;
}

int RTSPClientSource::GetNetBufferMilliSecond()
{
    return m_nNetBufferMilliSecond;
}

void RTSPClientSource::SetNetBufferMilliSecond(int nMilliSecond)
{
    if (nMilliSecond > 1000)
    {
        nMilliSecond = 1000;
    }

    if (nMilliSecond < 100)
    {
        nMilliSecond = 100;
    }

    m_nNetBufferMilliSecond = nMilliSecond;
    for (int i = 0; i < m_arrayParser.Count(); i ++)
    {
        if (m_arrayParser[i] != NULL)
        {
            m_arrayParser[i]->SetNetBufferMilliSecond(nMilliSecond);
        }
    }
}

int RTSPClientSource::RTSPPlay()
{
    if (!m_bIsPlaying)
    {
        return DoPlay();
    }
    else
    {
        LOG_DEBUG(("[RTSPClientSource::RTSPPlay] is already playing\r\n"));
        return -1;
    }
}

int RTSPClientSource::RTSPPause()
{
    return 0;
}

int RTSPClientSource::RTSPSeek()
{
    return 0;
}

int RTSPClientSource::RTSPStop()
{
    return DoStop();
}

//////////////////////////////////////////////////////////////////////////
BOOL RTSPClientSource::ParserOnData(int nFlag, void*pData, int nData, long nTimestampSecond, long nTimestampUSecond)
{
    RTSP_CLIENT_RAWDATACBDATA   rdcbd;
    RTSP_CLIENT_RTPCBDATA       rtpcbd;

    if (nFlag >= 100)
    {//rtp packet
        if (m_RtpCallBackFunc != NULL)
        {
            rtpcbd.hRTSPClient = this;
            rtpcbd.nStreamNo = nFlag%100;
            rtpcbd.sData = (char *)pData;
            rtpcbd.nData = nData;
            rtpcbd.pContext = m_prcbfContext;
            m_RtpCallBackFunc(rtpcbd);
        }
    }
    else
    {//raw data packet,h264 or aac
        if (
            (m_RawDataCallBackFunc != NULL)
            && (m_arrayParser[nFlag] != NULL)
            )
        {
            rdcbd.hRTSPClient = this;
            rdcbd.nStreamNo = nFlag;
            rdcbd.nTimestampSecond = nTimestampSecond;
            rdcbd.nTimestampUSecond = nTimestampUSecond;
            rdcbd.sData = (char *)pData;
            rdcbd.nData = nData;
            rdcbd.pContext = m_prdcbfContext;
            m_RawDataCallBackFunc(rdcbd);
        }
    }

    return TRUE;
}

int RTSPClientSource::Run(int nEvent)
{
    int		nTaskTime	= 0;
    UINT	nLocalEvent	= 0;

    nLocalEvent	= GetEvent(nEvent);

    ZTask::Run(nLocalEvent);

    if (nLocalEvent&TASK_UPDATE_EVENT)
    {
        nTaskTime = OnUpdate();
    }
    if (nLocalEvent&TASK_IDLE_EVENT)
    {
        nTaskTime = OnIdle();
    }

    return nTaskTime;
}

BOOL RTSPClientSource::OnReceiveResponse_OPTION(int nState)
{
    RTSP_CLIENT_STATUSCBDATA    scbd;

    if (m_StatusCallBackFunc != NULL)
    {
        scbd.hRTSPClient = this;
        scbd.nStatusType = 1;
        scbd.nStatusValue = nState;
        scbd.pContext = m_pscbfContext;
        m_StatusCallBackFunc(scbd);
    }

    return TRUE;
}

BOOL RTSPClientSource::OnReceiveResponse_DESCRIBE(int nState, CHAR *sSDP, int nSDP)
{
    RTSP_CLIENT_STATUSCBDATA    scbd;

    DestroyParser();
    CreateParser(sSDP, nSDP);

    if (m_StatusCallBackFunc != NULL)
    {
        scbd.hRTSPClient = this;
        scbd.nStatusType = 2;
        scbd.nStatusValue = nState;
        scbd.pContext = m_pscbfContext;
        m_StatusCallBackFunc(scbd);
    }

    return TRUE;
}

BOOL RTSPClientSource::OnReceiveResponse_SETUP(int nState, int nStreamNo)
{
    RTSP_CLIENT_STATUSCBDATA    scbd;

    if (m_StatusCallBackFunc != NULL)
    {
        scbd.hRTSPClient = this;
        scbd.nStatusType = 3;
        scbd.nStatusValue = nState;
        scbd.pContext = m_pscbfContext;
        m_StatusCallBackFunc(scbd);
    }

    return TRUE;
}

BOOL RTSPClientSource::OnReceiveResponse_PLAY(int nState)
{
    RTSP_CLIENT_STATUSCBDATA    scbd;
    int i = 0;
    int nStreamNo = 0;

    if (nState == 0)
    {
        for (i = 0; i < m_arrayParser.Count(); i ++)
        {
            if (m_arrayParser[i] != NULL)
            {
                 nStreamNo = m_arrayParser[i]->GetParserFlag();
                 m_arrayParser[i]->SetUpperPin((ZDataOut*)m_pRTSPSession->GetDataPin(nStreamNo));
            }
        }
    }

    if (m_StatusCallBackFunc != NULL)
    {
        scbd.hRTSPClient = this;
        scbd.nStatusType = 4;
        scbd.nStatusValue = nState;
        scbd.pContext = m_pscbfContext;
        m_StatusCallBackFunc(scbd);
    }

    return TRUE;
}

BOOL RTSPClientSource::DisconnectWithServer()
{
    RTSP_CLIENT_STATUSCBDATA    scbd;

    if (m_StatusCallBackFunc != NULL)
    {
        scbd.hRTSPClient = this;
        scbd.nStatusType = 101;
        scbd.nStatusValue = 0;
        scbd.pContext = m_pscbfContext;
        m_StatusCallBackFunc(scbd);
    }

    return TRUE;
}

BOOL RTSPClientSource::BeforeReconnect()
{
    RTSP_CLIENT_STATUSCBDATA    scbd;

    if (m_StatusCallBackFunc != NULL)
    {
        scbd.hRTSPClient = this;
        scbd.nStatusType = 102;
        scbd.nStatusValue = 0;
        scbd.pContext = m_pscbfContext;
        m_StatusCallBackFunc(scbd);
    }

    return TRUE;
}

BOOL RTSPClientSource::AfterReconnect(BOOL bReconnectOK)
{
    RTSP_CLIENT_STATUSCBDATA    scbd;

    if (m_StatusCallBackFunc != NULL)
    {
        scbd.hRTSPClient = this;
        if (bReconnectOK)
        {
            scbd.nStatusType = 104;
        }
        else
        {
            scbd.nStatusType = 103;
        }
        scbd.nStatusValue = 0;
        scbd.pContext = m_pscbfContext;
        m_StatusCallBackFunc(scbd);
    }

    return TRUE;
}

BOOL RTSPClientSource::GiveupReconnect()
{
    RTSP_CLIENT_STATUSCBDATA    scbd;

    if (m_StatusCallBackFunc != NULL)
    {
        scbd.hRTSPClient = this;
        scbd.nStatusType = 105;
        scbd.nStatusValue = 0;
        scbd.pContext = m_pscbfContext;
        m_StatusCallBackFunc(scbd);
    }

    return TRUE;
}

BOOL RTSPClientSource::DetectPacketLost(int nLostCount)
{
    RTSP_CLIENT_STATUSCBDATA    scbd;

    if (m_StatusCallBackFunc != NULL)
    {
        scbd.hRTSPClient = this;
        scbd.nStatusType = 201;
        scbd.nStatusValue = nLostCount;
        scbd.pContext = m_pscbfContext;
        m_StatusCallBackFunc(scbd);
    }

    return TRUE;
}

int	RTSPClientSource::OnUpdate()
{
    m_bSessionTimeout = FALSE;
    if (m_pRTSPSession != NULL)
    {
        if (m_pRTSPSession->GetSessionState() == SESSION_STATE_TIMEOUT)
        {
            m_bSessionTimeout = TRUE;
            if(m_pSocket != NULL)
            {
                m_pSocket->SetTask(NULL);
            }
            if(m_pRTSPSession != NULL)
            {
                m_pRTSPSession->Close();
            }
            if(m_pSocket != NULL)
            {
                m_pSocket->Close();
            }
        }
    }
    else
    {
        m_bSessionTimeout = TRUE;
    }

    if (m_bSessionTimeout)
    {
        if (m_Config.bReconnect)
        {
            ZIdleTask::AddIdleTask(DEFAULT_CHECK_RTSPSTATE_TIME);
        }
        return 0;
    }
    else
    {
        return DEFAULT_CHECK_RTSPSTATE_TIME;
    }
}

int RTSPClientSource::OnIdle()
{
    if (m_bSessionTimeout)
    {
        if (m_nAlreadyReconnectTimes < m_Config.nReconnectTryTimes)
        {
            if (RTSPClientSource::DoReconnect())
            {
                m_nAlreadyReconnectTimes = 0;
                return DEFAULT_CHECK_RTSPSTATE_TIME;
            }
            else
            {
                m_nAlreadyReconnectTimes ++;
                ZIdleTask::AddIdleTask(DEFAULT_CHECK_RTSPSTATE_TIME*m_Config.nReconnectInterval);
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
    else
    {
        return DEFAULT_CHECK_RTSPSTATE_TIME;
    }
}

int RTSPClientSource::DoPlay()
{
    BOOL				bReturn		= FALSE;
    char*				sProtocol	= NULL;
    char*				sHost		= NULL;
    char*				sPort		= NULL;
    char*				sUser		= NULL;
    char*				sPass		= NULL;
    char*				sPath		= NULL;
    int					nAddr		= 0;
    int					nPort		= 554;
    char                sLocalUrl[1024];
    char                sUrlNoUser[1024];
    RTSP_PROTOCOL_TRANSPORT eProtocolTransport = RTSP_PROTOCOL_TRANSPORT_UDP;
    UINT64              nStartTimeStamp = 0;

    do{

        ZIdleTask::Create();

        // url process
        strncpy(sLocalUrl,m_Config.sUrl,1024);
        sLocalUrl[1023] = '\0';
        if(!ZOS::DecodeURL(sLocalUrl,&sProtocol,&sHost,&sPort,&sUser,&sPass,&sPath))
        {
            break;
        }
        if(
            (sProtocol == NULL)
            || (sHost == NULL)
            || (strcasecmp(sProtocol,"RTSP")!=0)
            )
        {
            break;
        }

        // tcp socket process
        nAddr = ZSocket::ConvertAddr(sHost);
        if(sPort != NULL)
        {
            nPort = atoi(sPort);
        }
        m_pSocket	= NEW ZTCPSocket();
        if(m_pSocket == NULL)
        {
            break;
        }
        if(!m_pSocket->Create())
        {
            break;
        }
        m_pSocket->SetNonBlocking(TRUE);
        if(!m_pSocket->Connect(nAddr,nPort))
        {
        }
        if (m_Config.bSynchronizationMode)
        {
            if(!m_pSocket->ConnectAble(m_Config.nWaitSecond*1000*1000))
            {
                break;
            }
        }
        else
        {
            if(!m_pSocket->ConnectAble(10*1000*1000))
            {
                break;
            }
        }
        m_pSocket->SetRecvBufferSize(DEFAULT_TCP_RECV_BUFFER_SIZE);
        m_pSocket->SetTimeOut(DEFAULT_TCP_SEND_TIMEOUT,DEFAULT_TCP_RECV_TIMEOUT*10);

        // rtspsession process
        if (m_Config.nTransportType == 1)
        {
            eProtocolTransport = RTSP_PROTOCOL_TRANSPORT_UDP;
        }
        else if (m_Config.nTransportType == 2)
        {
            eProtocolTransport = RTSP_PROTOCOL_TRANSPORT_TCP;
        }
        ZOS::URLUserClear(m_Config.sUrl, sUrlNoUser, 1024);
        m_pRTSPSession	= (ZRTSPSession *)ZRTSPSession::CreateSession(SESSION_TYPE_CLIENT,m_pSocket,
            (char*)sUrlNoUser,eProtocolTransport,sUser,sPass);
        if(m_pRTSPSession == NULL)
        {
            break;
        }
        m_pRTSPSession->SetRTSPClientListener(this);

        // wait for rtsp session success.
        if (m_Config.bSynchronizationMode)
        {
            nStartTimeStamp = ZOS::milliseconds();
            while(ZOS::milliseconds()-nStartTimeStamp<(UINT64)(m_Config.nWaitSecond*1000))
            {
                if(m_pRTSPSession->GetSessionState() == SESSION_STATE_PLAY)
                {
                    bReturn	= TRUE;
                    break;
                }
                if(m_pRTSPSession->GetSessionState() == SESSION_STATE_ERROR)
                {
                    bReturn	= FALSE;
                    break;
                }
                if(m_pRTSPSession->GetSessionState() == SESSION_STATE_TIMEOUT)
                {
                    bReturn	= FALSE;
                    break;
                }
                ZOSThread::Sleep(30);
            }
            if (bReturn)
            {
                ZIdleTask::AddEvent(ZTask::TASK_UPDATE_EVENT);
            }
        }
        else
        {
            bReturn = TRUE;
        }
    }while(FALSE);

    if (!bReturn)
    {
        if(m_pSocket != NULL)
        {
            m_pSocket->SetTask(NULL);
        }

        if (m_pRTSPSession != NULL)
        {
            m_pRTSPSession->Close();
            SAFE_DELETE(m_pRTSPSession);
        }

        if (m_pSocket != NULL)
        {
            m_pSocket->Close();
            SAFE_DELETE(m_pSocket);
        }

        m_bIsPlaying = FALSE;
        return -1;
    }
    else
    {
        m_bIsPlaying = TRUE;
        return 0;
    }
}

int RTSPClientSource::DoStop()
{
    if (m_bIsPlaying)
    {
        ZIdleTask::Close();

        if (m_pSocket != NULL)
        {
            m_pSocket->SetTask(NULL);
        }
        if (m_pRTSPSession != NULL)
        {
            m_pRTSPSession->Close();
        }
        SAFE_DELETE(m_pRTSPSession);

        if (m_pSocket != NULL)
        {
            m_pSocket->Close();
        }
        SAFE_DELETE(m_pSocket);

        DestroyParser();

        m_bSessionTimeout = FALSE;

        m_bIsPlaying = FALSE;
    }

    return 0;
}

BOOL RTSPClientSource::DoReconnect()
{
    BOOL				bReturn		= FALSE;
    char*				sProtocol	= NULL;
    char*				sHost		= NULL;
    char*				sPort		= NULL;
    char*				sUser		= NULL;
    char*				sPass		= NULL;
    char*				sPath		= NULL;
    int					nAddr		= 0;
    int					nPort		= 554;
    char				sLocalSource[1024];
    char                sUrlNoUser[1024];
    RTSP_PROTOCOL_TRANSPORT eProtocolTransport = RTSP_PROTOCOL_TRANSPORT_UDP;

    do 
    {
        strncpy(sLocalSource,m_Config.sUrl,1024);
        if(!ZOS::DecodeURL(sLocalSource,&sProtocol,&sHost,&sPort,&sUser,&sPass,&sPath))
        {
            break;
        }
        if(
            (sProtocol == NULL)
            || (sHost == NULL)
            || (strcasecmp(sProtocol,"RTSP")!=0)
            )
        {
            break;
        }
        nAddr	= ZSocket::ConvertAddr(sHost);
        if(sPort != NULL)
        {
            nPort = atoi(sPort);
        }

        if(
            (m_pSocket == NULL)
            || (m_pRTSPSession == NULL)
            )
        {
            break;
        }
        if (m_pSocket->IsConnected())
        {
            bReturn = TRUE;
            break;
        }
        if(!m_pSocket->Create())
        {
            break;
        }
        m_pSocket->SetNonBlocking(TRUE);
        if(!m_pSocket->Connect(nAddr,nPort))
        {
        }
        if(!m_pSocket->ConnectAble(10*1000*1000))
        {
            m_pSocket->Close();
            break;
        }
        m_pSocket->SetRecvBufferSize(DEFAULT_TCP_RECV_BUFFER_SIZE);
        m_pSocket->SetTimeOut(DEFAULT_TCP_SEND_TIMEOUT,DEFAULT_TCP_RECV_TIMEOUT*10);

        // rtspsession process
        if (m_Config.nTransportType == 2)
        {
            eProtocolTransport = RTSP_PROTOCOL_TRANSPORT_TCP;
        }
        ZOS::URLUserClear(m_Config.sUrl, sUrlNoUser, 1024);
        m_pSocket->SetTask(m_pRTSPSession);
        m_pRTSPSession->SetSessionStream(m_pSocket);
        m_pRTSPSession->SetSessionURI(sUrlNoUser);
        m_pRTSPSession->SetProtocolTransportType(eProtocolTransport);
        m_pRTSPSession->SetSessionUserPassword(sUser,sPass);
        if(!m_pRTSPSession->Create())
        {
            m_pSocket->Close();
            break;
        }
        bReturn = TRUE;

    } while (FALSE);

    if (bReturn)
    {
        m_bSessionTimeout = FALSE;
    }
    else
    {
        m_bSessionTimeout = TRUE;
    }

    return bReturn;
}

BOOL RTSPClientSource::CreateParser(CHAR *sSDP, int nSDP)
{
    int i = 0;
    int nStreamCount = 0;
    int nStreamType;
    RTPParser *pParser = NULL;
    int nSampleRate = 0;
    int nChannel = 0;

    if (
        (sSDP != NULL)
        && (strlen(sSDP) > 0)
        )
    {
        nStreamCount = SDP_GetStreamCount(sSDP, nSDP);
        for (i = 0; i < nStreamCount; i ++)
        {
            pParser = NULL;
            nStreamType = SDP_GetStreamType(sSDP, nSDP, i);
            if (nStreamType == 100)
            {//h264
                pParser = NEW Parser3984;
            }
            else if (nStreamType == 200)
            {//aac-generic
                SDP_GetAACAudioProperty(sSDP, nSDP, i, &nSampleRate, &nChannel);
                pParser = NEW Parser3640;
                ((Parser3640*)pParser)->SetAdtsHeaderParameter(1, nSampleRate, nChannel, m_Config.bAACRawDataOutputWithAdtsHeader);
            }
            else if (nStreamType == 201)
            {//aac-latm
                SDP_GetAACAudioProperty(sSDP, nSDP, i, &nSampleRate, &nChannel);
                pParser =  NEW Parser3016;
                ((Parser3016*)pParser)->SetAdtsHeaderParameter(1, nSampleRate, nChannel, m_Config.bAACRawDataOutputWithAdtsHeader);
            }
            else if (nStreamType == 300)
            {//g711u
                pParser = NEW ParserG711;
            }
            else if (nStreamType == 301)
            {//g711a
                pParser = NEW ParserG711;
            }
            if (pParser != NULL)
            {
                pParser->SetParserListener(this);
                pParser->SetParserFlag(i);
                pParser->Start();
                m_arrayParser.Add(pParser);
            }
        }
        if (m_arrayParser.Count() > 0)
        {
            return TRUE;
        }
    }

    return FALSE;
}

BOOL RTSPClientSource::DestroyParser()
{
    int i = 0;
    RTPParser *pParser = NULL;

    for (i = 0; i < m_arrayParser.Count(); i ++)
    {
        if (m_arrayParser[i] != NULL)
        {
            pParser = m_arrayParser[i];
            pParser->Stop();
            SAFE_DELETE(pParser);
        }
    }
    m_arrayParser.RemoveAll();

    return TRUE;
}
