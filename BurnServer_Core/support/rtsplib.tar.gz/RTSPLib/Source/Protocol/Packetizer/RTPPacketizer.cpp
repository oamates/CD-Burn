#include "RTPPacketizer.h"

RTPPacketizer::RTPPacketizer()
: m_nPacketizerFlag(0)
, m_nPayloadType(0)
, m_nSSRC(0)
, m_nCurTimeStamp(0)
, m_nSeqNo(0)
{

}

RTPPacketizer::~RTPPacketizer()
{

}

void RTPPacketizer::SetPacketizerFlag(int nFlag)
{
    m_nPacketizerFlag = nFlag;
}

int RTPPacketizer::GetPacketizerFlag()
{
    return m_nPacketizerFlag;
}

void RTPPacketizer::SetPayloadType(int nPayloadType)
{
    m_nPayloadType = nPayloadType;
}

int RTPPacketizer::GetPayloadType()
{
    return m_nPayloadType;
}

void RTPPacketizer::SetSSRC(UINT nSSRC)
{
    m_nSSRC = nSSRC;
}

UINT RTPPacketizer::GetSSRC()
{
    return m_nSSRC;
}

void RTPPacketizer::SetFrameTimestamp(int nTimeStamp)
{
    m_nCurTimeStamp = nTimeStamp;
}

UINT RTPPacketizer::GetFrameTimestamp()
{
    return m_nCurTimeStamp;
}

int RTPPacketizer::GetSeqNo()
{
    return m_nSeqNo;
}

void RTPPacketizer::IncreaseSeqNo()
{
    m_nSeqNo ++;
    if (m_nSeqNo == 0xFFFF)
    {
        m_nSeqNo = 0;
    }
}

int RTPPacketizer::ReceiveFrameData(int nFlag, void *pData, int nData)
{
    return ProcessFrame((char*)pData, nData);
}

//////////////////////////////////////////////////////////////////////////
//BOOL RTPPacketizer::OnCommand(int nCommand)
//{
//    return TRUE;
//}
//
//BOOL RTPPacketizer::OnHeader(int nFlag,void* pHeader,int nHeader)
//{
//    return TRUE;
//}
//
//BOOL RTPPacketizer::OnData(int nFlag,void* pData,int nData)
//{
//    return TRUE;
//}

int RTPPacketizer::ProcessFrame(char *pData, int nData)
{
    SendData(1, pData, nData);

    return 0;
}

