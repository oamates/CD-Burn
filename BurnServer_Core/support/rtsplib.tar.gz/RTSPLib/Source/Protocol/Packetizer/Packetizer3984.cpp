#include "Packetizer3984.h"
#include "ZUDPSocket.h"
#include "ZRTPPacket.h"
#include "NalUtil.h"

Packetizer3984::Packetizer3984()
{
    //
}

Packetizer3984::~Packetizer3984()
{
    //
}

int Packetizer3984::ProcessSingle(char *sNalData, int nNalData)
{
    unsigned char sRTPPacket[DEFAULT_UDP_BUFFER_USED];
    int nCurSeqNo;


    nCurSeqNo = GetSeqNo();
    IncreaseSeqNo();
    memset(sRTPPacket, 0, DEFAULT_UDP_BUFFER_USED);
    sRTPPacket[0] = 0x80;
    sRTPPacket[1] = GetPayloadType()&0x7F;
    //marker=true
    sRTPPacket[1] = sRTPPacket[1]|0x80;
    sRTPPacket[2] = (nCurSeqNo&0xFF00)>>8;
    sRTPPacket[3] = nCurSeqNo&0xFF;
    sRTPPacket[4] = (GetFrameTimestamp()&0xFF000000)>>24;
    sRTPPacket[5] = (GetFrameTimestamp()&0xFF0000)>>16;
    sRTPPacket[6] = (GetFrameTimestamp()&0xFF00)>>8;
    sRTPPacket[7] = (GetFrameTimestamp()&0xFF);
    sRTPPacket[8] = (GetSSRC()&0xFF000000)>>24;
    sRTPPacket[9] = (GetSSRC()&0xFF0000)>>16;
    sRTPPacket[10] = (GetSSRC()&0xFF00)>>8;
    sRTPPacket[11] = (GetSSRC()&0xFF);

    memcpy(sRTPPacket+12, sNalData+4, nNalData-4);
    SendData(1, sRTPPacket, 12+nNalData-4);

    return 0;
}

int Packetizer3984::ProcessFU(char *sData, int nData)
{
    unsigned char sRTPPacket[DEFAULT_UDP_BUFFER_USED];
    int nCurSeqNo;
    int nLeftSize = nData;
    int nEachProcessSize = DEFAULT_RTP_BUFFER_USED-2;
    bool bStartPakcet = true;
    bool bEndPacket = false;
    int nCurPos = 5;


    while (nLeftSize > 0)
    {
        nCurSeqNo = GetSeqNo();
        IncreaseSeqNo();
        memset(sRTPPacket, 0, DEFAULT_UDP_BUFFER_USED);
        sRTPPacket[0] = 0x80;
        sRTPPacket[1] = GetPayloadType()&0x7F;
        // marker = false
        sRTPPacket[1] = sRTPPacket[1]&0x7F;
        sRTPPacket[2] = (nCurSeqNo&0xFF00)>>8;
        sRTPPacket[3] = nCurSeqNo&0xFF;
        sRTPPacket[4] = (GetFrameTimestamp()&0xFF000000)>>24;
        sRTPPacket[5] = (GetFrameTimestamp()&0xFF0000)>>16;
        sRTPPacket[6] = (GetFrameTimestamp()&0xFF00)>>8;
        sRTPPacket[7] = (GetFrameTimestamp()&0xFF);
        sRTPPacket[8] = (GetSSRC()&0xFF000000)>>24;
        sRTPPacket[9] = (GetSSRC()&0xFF0000)>>16;
        sRTPPacket[10] = (GetSSRC()&0xFF00)>>8;
        sRTPPacket[11] = (GetSSRC()&0xFF);
        //3bit
        sRTPPacket[12] = (sData[4]&0xE0);
        //5bit
        sRTPPacket[12] = (sRTPPacket[12]|28);

        if (nLeftSize < nEachProcessSize)
        {
            bEndPacket = true;
        }

        if (bStartPakcet)
        {
            //3bit
            sRTPPacket[13] = 0x80;
            bStartPakcet = false;
            //5bit
            sRTPPacket[13] = (sRTPPacket[13]|(sData[4]&0x1F));
            memcpy(sRTPPacket+14, sData+nCurPos, nEachProcessSize);
            SendData(1, sRTPPacket, 14+nEachProcessSize);
            nCurPos += nEachProcessSize;
            nLeftSize -= nEachProcessSize;
        }
        else if (bEndPacket)
        {
            //3bit
            sRTPPacket[13] = 0x40;
            //5bit
            sRTPPacket[13] = (sRTPPacket[13]|(sData[4]&0x1F));
            //marker=true
            sRTPPacket[1] = sRTPPacket[1]|0x80;
            memcpy(sRTPPacket+14, sData+nCurPos, nLeftSize);
            SendData(1, sRTPPacket, 14+nLeftSize);
            nCurPos += nLeftSize;
            nLeftSize = 0;
        }
        else
        {
            //3bit
            sRTPPacket[13] = 0x00;
            //5bit
            sRTPPacket[13] = (sRTPPacket[13]|(sData[4]&0x1F));
            memcpy(sRTPPacket+14, sData+nCurPos, nEachProcessSize);
            SendData(1, sRTPPacket, 14+nEachProcessSize);
            nCurPos += nEachProcessSize;
            nLeftSize -= nEachProcessSize;
        }

    }

    return 0;
}

int Packetizer3984::ProcessFrame(char *pData, int nData)
{
    int nCurDataPos = 0;
    int nLeftDataSize = nData;
    int nRelativePos = 0;
    int nNalSize = nData;

    while (NALUTIL_GetNal(pData+nCurDataPos, nLeftDataSize, &nRelativePos, &nNalSize) != NULL)
    {
        if ((nNalSize-4) > DEFAULT_RTP_BUFFER_USED)
        {
            ProcessFU(pData+nCurDataPos+nRelativePos, nNalSize);
        }
        else
        {
            ProcessSingle(pData+nCurDataPos+nRelativePos, nNalSize);
        }

        nLeftDataSize-=nNalSize;
        nCurDataPos+=nNalSize;
    }

    return 0;
}
