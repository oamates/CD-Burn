#include "ChnsysLog.h"
#include "ZLog.h"
#include "ZOSMemory.h"

CHNSYS_INT OS_LOG_Init()
{
    pLog = NEW ZLog;
    return 0;
}

CHNSYS_INT OS_LOG_UnInit()
{
    if(pLog != NULL)
    {
        SAFE_DELETE(pLog);
    }
    return 0;
}
