#ifndef _NCXXMLNODE_H_
#define _NCXXMLNODE_H_

#include "TaskModel.h"

/*
NCXXMLNode	*pNodeTVW = new NCXXMLNode();
pNodeTVW->FromString("<tvw><cmd><retvalue>200</retvalue></cmd><cmd><retvalue>100</retvalue></cmd></tvw>", 0);
printf("%s\n", pNodeTVW->GetNodeName());
for (NCXXMLNode *pNodeCMD = pNodeTVW->GetFirstChildNode();
	 pNodeCMD != NULL;
	 pNodeCMD = pNodeTVW->GetNextChildNode(pNodeCMD))
{
	printf("%s\n", pNodeCMD->GetNodeName());
	NCXXMLNode *pNodeRetVal = pNodeCMD->GetChildNode("retvalue");
	if (pNodeRetVal != NULL)
	{
		printf("%s %s\n", pNodeRetVal->GetNodeName(), pNodeRetVal->GetNodeValue());
	}
}
*/

/*
NCXXMLNode *pNodeTVW = new NCXXMLNode;
pNodeTVW->SetNodeName("tvw");

//
NCXXMLNode *pNodeCMD = new NCXXMLNode;
pNodeCMD->SetNodeName("cmd");
NCXXMLNode *pNodeRetValue = new NCXXMLNode;
pNodeRetValue->SetNodeName("retvalue");
pNodeRetValue->SetNodeValue("200");
pNodeCMD->AddChildNode(pNodeRetValue);
pNodeTVW->AddChildNode(pNodeCMD);

//
pNodeCMD = new NCXXMLNode;
pNodeCMD->SetNodeName("cmd");
pNodeRetValue = new NCXXMLNode;
pNodeRetValue->SetNodeName("retvalue");
pNodeRetValue->SetNodeValue("100");
pNodeCMD->AddChildNode(pNodeRetValue);
pNodeTVW->AddChildNode(pNodeCMD);

int nTVWStringLength = pNodeTVW->GetNodeStringLength();
char *sTVW = new char [nTVWStringLength+1];
memset(sTVW, 0, nTVWStringLength+1);
pNodeTVW->ToString(sTVW, &nTVWStringLength);

printf("%s\n", sTVW);
*/

class NCXXMLNode;

typedef ZOSArray<NCXXMLNode*>	NCXXMLNodeArray;

class NCXXMLNode
{
public:
	NCXXMLNode();
	~NCXXMLNode();
public:
	void SetNodeName(char *sNodeName);
	void SetNodeValue(char *sNodeValue);
	void AddChildNode(NCXXMLNode *pNode);
	int GetNodeStringLength();
	char *ToString(char *sString, int *nStringLength);

	//////////////////////////////////////////////////////////////////////////
	// NCXXMLNode is so tiny and esay, so the string should be caution.
	// can not have node not have value. like substring "<retvalue></retvalue>"
	//////////////////////////////////////////////////////////////////////////
	int FromString(char *sString, int nPos=0);
	NCXXMLNode* GetChildNode(char *sNodeName);
	NCXXMLNode* GetFirstChildNode();
	NCXXMLNode* GetNextChildNode(NCXXMLNode *pNode);
	char *GetNodeName();
	char *GetNodeValue();
protected:
	// pPos point to the Node Name's first character
	int GetNodeNameLength(char *pPos);

	// pPos point to the Node Value's first character
	int GetNodeValueLength(char *pPos);

	// until '>'
	void SkipTagEnd(char *pPos, int *nPos);

private:
	char				*m_sNodeName;
	char				*m_sNodeValue;
	NCXXMLNodeArray		m_childNodes;
};

#endif //_NCXXMLNODE_H_
//////////////////////////////////////////////////////////////////////////
