#ifndef _NCXCLIENT_H_
#define _NCXCLIENT_H_

#include "TaskModel.h"
#include "ClientProcessor.h"

class NCXClient
	: public ZTask
{
public:
	NCXClient();
	~NCXClient();
public:
	virtual	BOOL	Create();
	virtual	BOOL	Close();
	void SetOuterMostTagName(CONST CHAR *sTagName);
	BOOL ConnectServer(CONST CHAR* sServerIP, int nServerPort, int nWaitSecond);
	int Communicate(CONST CHAR* sProtocol, int nProtocol, int nWaitSecond);
	CHAR * GetRespondProtocol();
protected:
	virtual	int		Run(int nEvent = 0);
	void			ProcessReceive();
	int				CheckRecvBuffer();
private:
	ZTCPSocket		m_tcpClient;

	CHAR			*m_sRecvBuffer;
	int				m_nRecvBufferSize;
	int				m_nCurReceivedBytes;

	CHAR			m_sOuterMostTagName[MAX_TAGNAME_LENGTH];

	bool			m_bRespondRecvComplete;
	bool			m_bServerClose;
};

#endif //_NCXCLIENT_H_
//////////////////////////////////////////////////////////////////////////
