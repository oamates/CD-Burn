#include "NCXXMLNode.h"

NCXXMLNode::NCXXMLNode()
: m_sNodeName(NULL)
, m_sNodeValue(NULL)
, m_childNodes(3) 
{
	//
}

NCXXMLNode::~NCXXMLNode()
{
	int i = 0;

	SAFE_DELETE_ARRAY(m_sNodeName);
	SAFE_DELETE_ARRAY(m_sNodeValue);

	for (i = 0; i < m_childNodes.Count(); i ++)
	{
		if (m_childNodes[i] != NULL)
		{
			DEL m_childNodes[i];
		}
	}
	m_childNodes.RemoveAll();

}

void NCXXMLNode::SetNodeName(char *sNodeName)
{
	ASSERT((sNodeName != NULL));

	if (sNodeName != NULL)
	{
		SAFE_DELETE_ARRAY(m_sNodeName);
		m_sNodeName = NEW char [strlen(sNodeName)+1];
		strcpy(m_sNodeName, sNodeName);
	}
}

void NCXXMLNode::SetNodeValue(char *sNodeValue)
{
	ASSERT((sNodeValue != NULL));

	if (sNodeValue != NULL)
	{
		SAFE_DELETE_ARRAY(m_sNodeValue);
		m_sNodeValue = NEW char [strlen(sNodeValue)+1];
		strcpy(m_sNodeValue, sNodeValue);
	}
}

void NCXXMLNode::AddChildNode(NCXXMLNode *pNode)
{
	ASSERT((pNode != NULL));

	if (pNode != NULL)
	{
		m_childNodes.Add(pNode);
	}
}

char * NCXXMLNode::ToString(char *sString, int *nStringLength)
{
	int i;
	int nChildStringLength;
	char *sChildString;

	ASSERT((sString != NULL));
	ASSERT((nStringLength != NULL));
	ASSERT((m_sNodeName!=NULL));

	*nStringLength = GetNodeStringLength();

	if (m_childNodes.Count() > 0)
	{
		strcat(sString, "<");
		strcat(sString, m_sNodeName);
		strcat(sString, ">");

		for (i = 0; i < m_childNodes.Count(); i ++)
		{
			if (m_childNodes[i] != NULL)
			{
				nChildStringLength = m_childNodes[i]->GetNodeStringLength();
				sChildString = NEW char [nChildStringLength+1];
				if (sChildString != NULL)
				{
					memset(sChildString, 0, nChildStringLength+1);
					m_childNodes[i]->ToString(sChildString, &nChildStringLength);
					strcat(sString, sChildString);
					SAFE_DELETE_ARRAY(sChildString);
				}
			}
		}
		
		strcat(sString, "</");
		strcat(sString, m_sNodeName);
		strcat(sString, ">");
	}
	else
	{
		sprintf(sString, "<%s>%s</%s>", m_sNodeName, m_sNodeValue, m_sNodeName);
	}

	return sString;
}

int NCXXMLNode::FromString(char *sString, int nPos)
{
	ASSERT((sString != NULL));

	if (*(sString+nPos) == '<' && *(sString+nPos+1) != '/')
	{
		nPos ++;
		SAFE_DELETE_ARRAY(m_sNodeName);
		int nLength = GetNodeNameLength(sString+nPos);
		m_sNodeName = NEW char [nLength+1];
		memcpy(m_sNodeName, sString+nPos, nLength);
		m_sNodeName[nLength] = '\0';
		nPos = nPos + nLength + 1;

		if (*(sString+nPos) == '<')
		{
			do 
			{
				if (nPos >= (int)strlen(sString))
				{
					break;
				}

				if (*(sString+nPos) == '<' && *(sString+nPos+1) != '/')
				{
					NCXXMLNode *pNode = NEW NCXXMLNode;
					nPos = pNode->FromString(sString, nPos);
					m_childNodes.Add(pNode);
				}
				else if (*(sString+nPos) == '<' && *(sString+nPos+1) == '/')
				{
					break;
				}
			} while (true);
			SkipTagEnd(sString, &nPos);
		}
		else
		{
			SAFE_DELETE_ARRAY(m_sNodeValue);
			int nLength = GetNodeValueLength(sString+nPos);
			m_sNodeValue = NEW char [nLength+1];
			memcpy(m_sNodeValue, sString+nPos, nLength);
			m_sNodeValue[nLength] = '\0';
			SkipTagEnd(sString, &nPos);
		}
	}

	return nPos;
}

NCXXMLNode* NCXXMLNode::GetChildNode(char *sNodeName)
{
	ASSERT((sNodeName != NULL));
	int i;

	for (i = 0; i < m_childNodes.Count(); i ++)
	{
		if (
			(m_childNodes[i] != NULL) 
			&& (strcmp(m_childNodes[i]->GetNodeName(), sNodeName)==0)
			)
		{
			return m_childNodes[i];
		}
	}

	return NULL;
}

NCXXMLNode* NCXXMLNode::GetFirstChildNode()
{
	if (m_childNodes.Count() > 0)
	{
		return m_childNodes[0];
	}
	else
	{
		return NULL;
	}
}

NCXXMLNode* NCXXMLNode::GetNextChildNode(NCXXMLNode *pNode)
{
	ASSERT((pNode != NULL));
	int i;

	for (i = 0; i < m_childNodes.Count(); i ++)
	{
		if (
			(m_childNodes[i] != NULL)
			&& (m_childNodes[i] == pNode)
			)
		{
			if (i+1 < m_childNodes.Count())
			{
				return m_childNodes[i+1];
			}
			else
			{
				return NULL;
			}
		}
	}

	return NULL;
}

char * NCXXMLNode::GetNodeName()
{
	return m_sNodeName;
}

char * NCXXMLNode::GetNodeValue()
{
	return m_sNodeValue;
}

int NCXXMLNode::GetNodeStringLength()
{
	int nLength = 0;
	int i = 0;

	// '<' '>' '<' '/' '>'
	nLength += 5;
	nLength += 2*strlen(m_sNodeName);
	if (m_childNodes.Count() > 0)
	{
		for (i = 0; i < m_childNodes.Count(); i ++)
		{
			if (m_childNodes[i] != NULL)
			{
				nLength += m_childNodes[i]->GetNodeStringLength();
			}
		}
	}
	else
	{
		nLength += strlen(m_sNodeValue);
	}

	return nLength;
}

int NCXXMLNode::GetNodeNameLength(char *pPos)
{
	int nLength = 0;
	while (*pPos != '>')
	{
		pPos ++;
		nLength ++;
	}
	
	return nLength;
}

int NCXXMLNode::GetNodeValueLength(char *pPos)
{
	int nLength = 0;
	while (*pPos != '<')
	{
		pPos ++;
		nLength ++;
	}

	return nLength;
}

void NCXXMLNode::SkipTagEnd(char *pPos, int *nPos)
{
	while (pPos[*nPos] != '>')
	{
		*nPos = *nPos + 1;
	}
	*nPos = *nPos + 1;
}

//////////////////////////////////////////////////////////////////////////
