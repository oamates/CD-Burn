#include "ClientProcessor.h"

//////////////////////////////////////////////////////////////////////////
#define DEFAULT_CLIENT_COMMUNICATE_TIMEOUT	(20*1000)

//////////////////////////////////////////////////////////////////////////

ClientProcessorListener::ClientProcessorListener()
{
	//
}

ClientProcessorListener::~ClientProcessorListener()
{
	//
}

BOOL ClientProcessorListener::OnReceiveCompleteProtocol(ClientProcessor *pClientProcessor, CONST CHAR *sProtocol, int nProtocolLength)
{


	return TRUE;
}
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
ClientProcessor::ClientProcessor()
: ZTimeoutTask("ClientProcessor")
, m_mutexServerSocket("Mutex_ClientProcessor_ServerSocket")
{
	m_bCanRecycle	= FALSE;
	
	m_pServerSocket = NULL;
	
	m_sRecvBuffer		= NULL;
	m_nRecvBufferSize	= 0;
	m_nCurReceivedBytes	= 0;
	
	memset(m_sOuterMostTagName, 0, MAX_TAGNAME_LENGTH);

	m_pClientProcessorListener	= NULL;
}

ClientProcessor::~ClientProcessor()
{
	//
}

BOOL ClientProcessor::Create()
{
	ZTimeoutTask::Create();
	ZTimeoutTask::SetTimeout(DEFAULT_CLIENT_COMMUNICATE_TIMEOUT);
	return TRUE;
}

BOOL ClientProcessor::Close()
{
	ZTimeoutTask::Close();
	CloseSession();
	SAFE_DELETE_ARRAY(m_sRecvBuffer);
	return TRUE;
}

void ClientProcessor::SetListener(ClientProcessorListener *pListener)
{
	m_pClientProcessorListener = pListener;
}

void ClientProcessor::SetOuterMostTagName(CONST CHAR *sTagName)
{
	strncpy(m_sOuterMostTagName, sTagName, MAX_TAGNAME_LENGTH);
}

BOOL ClientProcessor::AttachClient(CONST int hAcceptSocket, CONST struct sockaddr_in* pRemoteAddr)
{
	BOOL bReturn = FALSE;

	do 
	{
		if (m_pServerSocket != NULL)
		{
			LOG_ERROR(("[ClientProcessor::AttachClient] m_pServerSocket is not NULL\r\n"));
			break;
		}
		m_pServerSocket = NEW ZTCPSocket;
		if (m_pServerSocket == NULL)
		{
			LOG_ERROR(("[ClientProcessor::AttachClient] NEW ZTCPSocket failed\r\n"));
			break;
		}

		m_sRecvBuffer = NEW CHAR[INIT_RECEIVE_BUFFER_SIZE];
		if (m_sRecvBuffer == NULL)
		{
			LOG_ERROR(("[ClientProcessor::AttachClient] NEW RecvBuffer failed\r\n"));
			break;
		}
		m_bCanRecycle = FALSE;
		m_nRecvBufferSize = INIT_RECEIVE_BUFFER_SIZE;
		m_nCurReceivedBytes = 0;

		m_pServerSocket->Attach(hAcceptSocket, pRemoteAddr);
		m_pServerSocket->StreamCreate();
		m_pServerSocket->SetRecvBufferSize(DEFAULT_TCP_RECV_BUFFER_SIZE);
		m_pServerSocket->SetNonBlocking();
		m_pServerSocket->SetTask(this);
		m_pServerSocket->RequestEvent(ZEvent::EVENT_READ);

		bReturn = TRUE;

	} while (false);

	if (!bReturn)
	{
		if (m_pServerSocket != NULL)
		{
			m_pServerSocket->Close();
			m_pServerSocket->StreamClose();
			SAFE_DELETE(m_pServerSocket);
		}

		SAFE_DELETE_ARRAY(m_sRecvBuffer);
	}

	return bReturn;
}

BOOL ClientProcessor::IsRecyclable()
{
	return m_bCanRecycle;
}

int ClientProcessor::SendRespond(CONST CHAR *sProtocol, int nProtocolLength)
{
	if (m_pServerSocket != NULL)
	{
		ZOSMutexLocker	locker(&m_mutexServerSocket);
		return m_pServerSocket->StreamWrite(sProtocol, nProtocolLength);
	}
	else
	{
		LOG_WARNING(("[ClientProcessor::SendRespond] m_pServerSocket == NULL\r\n"));
		return -1;
	}
}

CHAR* ClientProcessor::GetRemoteIP()
{
	UINT	nAddr,nPort;
	if (m_pServerSocket != NULL)
	{
		m_pServerSocket->GetRemoteAddr(&nAddr,&nPort);
		return ZSocket::ConvertAddr(nAddr);
	}
	else
	{
		return NULL;
	}
}

int	ClientProcessor::Run(int nEvent)
{
	int				nTaskTime	= 0;
	UINT			nLocalEvent	= 0;

	nLocalEvent	= GetEvent(nEvent);

	ZTimeoutTask::Run(nLocalEvent);

	if(nLocalEvent&TASK_KILL_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_TIMEOUT_EVENT)
	{
		LOG_DEBUG(("[ClientProcessor::Run] TIMEOUT EVENT\r\n"));
		CloseSession();
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_READ_EVENT)
	{
		LOG_DEBUG(("[ClientProcessor::Run] READ EVENT\r\n"));
		ProcessReceive();
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_UPDATE_EVENT)
	{
		nTaskTime	= 0;
	}

	return nTaskTime;
}

void ClientProcessor::ProcessReceive()
{
	int nData;
	int nRead;
	int nProtocolStartPos;
	int nProtocolLength;

	if (m_pServerSocket != NULL)
	{
		{
			ZOSMutexLocker locker(&m_mutexServerSocket);
			for (;;)
			{
				CheckRecvBuffer();
				nData = EACH_TIME_RECEIVE_SIZE;
				nRead = m_pServerSocket->StreamRead(m_sRecvBuffer+m_nCurReceivedBytes, nData);
				if (nRead > 0)
				{
					m_nCurReceivedBytes += nRead;
					m_pServerSocket->RequestEvent(ZEvent::EVENT_READ);
				}
				else
				{
					break;
				}
			}
		}

		if (nRead <= 0)
		{
			if (nRead == ZSOCKET_TIMEOUT)
			{
				if (TagUtillity::IsProtocolComplete(m_sRecvBuffer, m_sOuterMostTagName, &nProtocolStartPos, &nProtocolLength))
				{// get complete format string
					// call upper caller callback
					if (m_pClientProcessorListener != NULL)
					{
						m_pClientProcessorListener->OnReceiveCompleteProtocol(this, m_sRecvBuffer+nProtocolStartPos, nProtocolLength);
					}
				}
				else
				{
					m_pServerSocket->RequestEvent(ZEvent::EVENT_READ);
				}
			}
			else
			{
				CloseSession();
			}
		}

	}
}

int ClientProcessor::CheckRecvBuffer()
{
	int nReturn = -1;
	CHAR *pTemp = NULL;
	
	if (m_nCurReceivedBytes+EACH_TIME_RECEIVE_SIZE >= m_nRecvBufferSize)
	{
		pTemp = NEW CHAR[m_nRecvBufferSize*RECEIVE_BUFFER_INCREASE_TIMES];
		if (pTemp != NULL)
		{
			memmove(pTemp, m_sRecvBuffer, m_nRecvBufferSize);
			SAFE_DELETE_ARRAY(m_sRecvBuffer);
			m_sRecvBuffer = pTemp;
			m_nRecvBufferSize = m_nRecvBufferSize*RECEIVE_BUFFER_INCREASE_TIMES;
			nReturn = 0;
		}
		else
		{
			LOG_ERROR(("[ClientProcessor::CheckRecvBuffer] can not NEW enough memory\r\n"));
		}
	}
	else
	{
		nReturn = 0;
	}

	return nReturn;
}

void ClientProcessor::CloseSession()
{
	if (m_pServerSocket != NULL)
	{
		ZOSMutexLocker	locker(&m_mutexServerSocket);

		m_pServerSocket->StreamClose();
		m_pServerSocket->SetTask(NULL);
		m_pServerSocket->RemoveEvent(ZEvent::EVENT_READ);
		m_pServerSocket->Close();
		m_bCanRecycle = TRUE;

		SAFE_DELETE(m_pServerSocket);
	}
}

//////////////////////////////////////////////////////////////////////////
