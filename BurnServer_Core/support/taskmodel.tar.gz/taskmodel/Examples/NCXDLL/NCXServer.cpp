#include "NCXServer.h"

#define DEFAULT_CHECK_RECYCLE_TIME	(1000)

//////////////////////////////////////////////////////////////////////////
NCXServer::NCXServer()
: ZTask("NCXServer")
, m_mutexClientProcessorArray("Mutex_NCXServer_ClientProcessorArray")
, m_ClientProcessorArray(100)
, m_mutexRecvProtocol("Mutex_NCXServer_RecvProtocol")
{
	m_nListenPort			= 0;
	m_pTCPListenerSocket	= NULL;

	memset(m_sOuterMostTagName, 0, MAX_TAGNAME_LENGTH);

	m_EventCallBack			= NULL;
	m_pContext				= NULL;
}

NCXServer::~NCXServer()
{
	NCXServer::Close();
}

void NCXServer::SetListenPort(int nPort)
{
	m_nListenPort = nPort;
}

void NCXServer::SetOuterMostTagName(CONST CHAR *sTagName)
{
	strncpy(m_sOuterMostTagName, sTagName, MAX_TAGNAME_LENGTH);
}

int NCXServer::SetCallBack(NCXEventCallBack ncxEventCallBack, void *pContext)
{
	m_EventCallBack = ncxEventCallBack;
	m_pContext = pContext;
	return 0;
}

BOOL NCXServer::Create()
{
	BOOL bReturn = FALSE;

	do 
	{
		if (m_nListenPort == 0)
		{
			LOG_ERROR(("[NCXServer::Create] listen port is not set\r\n"));
			break;
		}

		if (ZTask::Create() != 0)
		{
			LOG_ERROR(("[NCXServer::Create] task create failed\r\n"));
			break;
		}

		m_pTCPListenerSocket = NEW ZTCPListenerSocket;
		if (m_pTCPListenerSocket == NULL)
		{
			LOG_ERROR(("[NCXServer::Create] NEW ZTCPListenerEvent failed\r\n"));
			break;
		}

		if (!m_pTCPListenerSocket->Create(0, m_nListenPort))
		{
			LOG_ERROR(("[NCXServer::Create] ZTCPListenerEvent Create failed\r\n"));
			break;
		}

		m_pTCPListenerSocket->SetListenerEvent(this);
		ZTask::AddEvent(TASK_UPDATE_EVENT);

		bReturn = TRUE;

	} while (false);


	if (!bReturn)
	{
		if (m_pTCPListenerSocket != NULL)
		{
			m_pTCPListenerSocket->Close();
			SAFE_DELETE(m_pTCPListenerSocket);
		}
	}

	return bReturn;
}

BOOL NCXServer::Close()
{
	int i = 0;
	
	if (m_pTCPListenerSocket != NULL)
	{
		m_pTCPListenerSocket->Close();
		SAFE_DELETE(m_pTCPListenerSocket);
	}

	{
		ZOSMutexLocker	locker(&m_mutexClientProcessorArray);
		for (i = 0; i < m_ClientProcessorArray.Count(); i ++)
		{
			if (m_ClientProcessorArray[i] != NULL)
			{
				m_ClientProcessorArray[i]->Close();
				DEL m_ClientProcessorArray[i];
			}
		}
		m_ClientProcessorArray.RemoveAll();
	}

	ZTask::Close();
	return TRUE;
}

int NCXServer::SendProtocolResponse(NCXServerCBParam ncxServerCBParam, const char *sResponse, int nResponseLength)
{
	int i = 0;

	{
		ZOSMutexLocker	locker(&m_mutexClientProcessorArray);
		for (i = 0; i < m_ClientProcessorArray.Count(); i ++)
		{
			if (
				(m_ClientProcessorArray[i] != NULL)
				&& m_ClientProcessorArray[i] == ncxServerCBParam.pClientProcessor
				)
			{
				return m_ClientProcessorArray[i]->SendRespond(sResponse, nResponseLength);
			}
		}
	}

	return -1;
}

int	NCXServer::Run(int nEvent)
{
	int				nTaskTime	= 0;
	UINT			nLocalEvent	= 0;

	nLocalEvent	= GetEvent(nEvent);

	ZTask::Run(nLocalEvent);

	if(nLocalEvent&TASK_KILL_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_TIMEOUT_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_READ_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_UPDATE_EVENT)
	{
		nTaskTime	= ProcessRecycle();
	}

	return nTaskTime;
}

int NCXServer::ProcessRecycle()
{
	BOOL bRemove = FALSE;
	int i = 0;
	ZOSMutexLocker locker(&m_mutexClientProcessorArray);
	for (i = 0; i < m_ClientProcessorArray.Count(); i ++)
	{
		if (
			(m_ClientProcessorArray[i] != NULL)
			&& (m_ClientProcessorArray[i]->IsRecyclable())
			)
		{
			m_ClientProcessorArray[i]->Close();
			DEL m_ClientProcessorArray[i];
			m_ClientProcessorArray.Remove(i);
			bRemove = TRUE;
			break;
		}
	}

	if (bRemove)
	{
		return (DEFAULT_CHECK_RECYCLE_TIME/10)+1;
	}
	else
	{
		return DEFAULT_CHECK_RECYCLE_TIME;
	}

}

BOOL NCXServer::OnListenerEvent(CONST int hAccept,CONST struct sockaddr_in* pLocalAddr,
								CONST struct sockaddr_in* pRemoteAddr)
{
	BOOL bReturn = FALSE;
	ClientProcessor *pClientProcessor = NULL;

	do 
	{
		pClientProcessor = NEW ClientProcessor;
		if (pClientProcessor == NULL)
		{
			LOG_ERROR(("[NCXServer::OnListenerEvent] can not NEW ClientProcessor\r\n"));
			break;
		}
		
		if (!pClientProcessor->Create())
		{
			LOG_ERROR(("[NCXServer::OnListenerEvent] ClientProcessor Create failed\r\n"));
			break;
		}

		pClientProcessor->SetListener(this);
		ASSERT((strlen(m_sOuterMostTagName)>0));
		pClientProcessor->SetOuterMostTagName(m_sOuterMostTagName);

		if (!pClientProcessor->AttachClient(hAccept, pRemoteAddr))
		{
			pClientProcessor->Close();
			LOG_ERROR(("[NCXServer::OnListenerEvent] ClientProcessor AttachClient failed\r\n"));
			break;
		}

		{
			ZOSMutexLocker	locker(&m_mutexClientProcessorArray);
			m_ClientProcessorArray.Add(pClientProcessor);
		}

		bReturn = TRUE;

	} while (false);

	if (!bReturn)
	{
		SAFE_DELETE(pClientProcessor);
	}

	return bReturn;
}

BOOL NCXServer::OnReceiveCompleteProtocol(ClientProcessor *pClientProcessor, 
									   CONST CHAR *sProtocol, int nProtocolLength)
{
	ZOSMutexLocker locker(&m_mutexRecvProtocol);

	if (m_EventCallBack != NULL)
	{
		NCXServerCBParam param;
		param.pClientProcessor = pClientProcessor;
		strncpy(param.szRemoteIP, pClientProcessor->GetRemoteIP(), MAX_IP_LENGTH);
		param.sProtocolContent = (CHAR*)sProtocol;
		param.nProtocolLength = nProtocolLength;
		m_EventCallBack(1, &param, m_pContext);
	}

	return TRUE;
}

//////////////////////////////////////////////////////////////////////////
