#include "NCX.h"
#include "NCXServer.h"
#include "NCXClient.h"
#include "NCXXMLNode.h"

static bool g_bEnvironmentInit = false;
static ZLog g_log;

void ncxInitNCXEnvironment()
{
	if (!g_bEnvironmentInit)
	{
		InitTaskModel();
		g_bEnvironmentInit = true;
	}
}

void ncxUnInitNCXEnvironment()
{
	if (g_bEnvironmentInit)
	{
		UninitTaskModel();
	}
}

void ncxSetLogDir(const char * sLogDir)
{
	LOG_SET_PATH(sLogDir);
}

NCXSERVERHANDLE ncxCreateNCXServer()
{
	NCXServer *pNCXServer = NEW NCXServer;
	NCXSERVERHANDLE hNcxServer = (NCXSERVERHANDLE)pNCXServer;
	return hNcxServer;
}

void ncxDestroyNCXServer(NCXSERVERHANDLE hNcxServer)
{
	NCXServer *pNCXServer = (NCXServer*)hNcxServer;
	if (pNCXServer != NULL)
	{
		DEL pNCXServer;
		pNCXServer = NULL;
	}
}

int ncxSetNCXServerPort(NCXSERVERHANDLE hNcxServer, int nListenPort)
{
	NCXServer *pNCXServer = (NCXServer*)hNcxServer;
	if (pNCXServer != NULL)
	{
		pNCXServer->SetListenPort(nListenPort);
	}

	return 0;
}

int ncxSetNCXServerOuterMostTagName(NCXSERVERHANDLE hNcxServer, char * sTagName)
{
	NCXServer *pNCXServer = (NCXServer*)hNcxServer;
	if (pNCXServer != NULL)
	{
		pNCXServer->SetOuterMostTagName(sTagName);
	}

	return 0;
}

int ncxSetNCXServerCallBack(NCXSERVERHANDLE hNcxServer, NCXEventCallBack ncxServerCallBack, void *pContext)
{
	NCXServer *pNCXServer = (NCXServer*)hNcxServer;
	if (pNCXServer != NULL)
	{
		pNCXServer->SetCallBack(ncxServerCallBack, pContext);
	}

	return 0;
}

int ncxSendProtocolResponse(NCXSERVERHANDLE hNcxServer, NCXServerCBParam ncxServerCBParam, const char *sResponse, int nResponseLength)
{
	NCXServer *pNCXServer = (NCXServer*)hNcxServer;
	if (pNCXServer != NULL)
	{
		pNCXServer->SendProtocolResponse(ncxServerCBParam, sResponse, nResponseLength);
	}

	return 0;
}

int ncxNCXServerStart(NCXSERVERHANDLE hNcxServer)
{
	NCXServer *pNCXServer = (NCXServer*)hNcxServer;
	if (pNCXServer != NULL)
	{
		pNCXServer->Create();
	}

	return 0;
}

int ncxNCXServerStop(NCXSERVERHANDLE hNcxServer)
{
	NCXServer *pNCXServer = (NCXServer*)hNcxServer;
	if (pNCXServer != NULL)
	{
		pNCXServer->Close();
	}

	return 0;
}

NCXCLIENTHANDLE ncxCreateNCXClient()
{
	NCXClient *pNcxClient = NEW NCXClient;
	NCXCLIENTHANDLE hNcxClient = (NCXCLIENTHANDLE)pNcxClient;
	if (pNcxClient != NULL)
	{
		pNcxClient->Create();
	}

	return hNcxClient;
}

void ncxDestroyNCXClient(NCXCLIENTHANDLE hNcxClient)
{
	NCXClient *pNcxClient = (NCXClient*)hNcxClient;

	if (pNcxClient != NULL)
	{
		pNcxClient->Close();
		SAFE_DELETE(pNcxClient);
	}
}

int ncxSetNCXClientOuterMostTagName(NCXCLIENTHANDLE hNcxClient, char* sTagName)
{
	NCXClient *pNcxClient = (NCXClient *)hNcxClient;

	if (pNcxClient != NULL)
	{
		pNcxClient->SetOuterMostTagName(sTagName);
	}

	return 0;
}

bool ncxConnectServer(NCXCLIENTHANDLE hNcxClient, const char* sServerIP, 
					  int nServerPort, int nWaitSecond)
{
	NCXClient *pNcxClient = (NCXClient *)hNcxClient;

	if (pNcxClient != NULL)
	{
		if (pNcxClient->ConnectServer(sServerIP, nServerPort, nWaitSecond))
		{
			return true;
		}
	}

	return false;
}

int ncxCommunicateWithServer(NCXCLIENTHANDLE hNcxClient, const char* sProtocol,
							 int nProtocol, int nWaitSecond)
{
	NCXClient *pNcxClient = (NCXClient *)hNcxClient;

	if (pNcxClient != NULL)
	{
		return pNcxClient->Communicate(sProtocol, nProtocol, nWaitSecond);
	}

	return -11;
}

char * ncxGetRespondProtocol(NCXCLIENTHANDLE hNcxClient)
{
	NCXClient *pNcxClient = (NCXClient *)hNcxClient;

	if (pNcxClient != NULL)
	{
		return pNcxClient->GetRespondProtocol();
	}

	return NULL;
}

NCXXMLNODEHANDLE ncxCreateXMLNode()
{
	NCXXMLNODEHANDLE	hXMLNode;
	NCXXMLNode			*pNcxXMLNode;

	pNcxXMLNode = NEW NCXXMLNode;
	hXMLNode = (NCXXMLNODEHANDLE)pNcxXMLNode;

	return hXMLNode;
}

void ncxDestroyXMLNode(NCXXMLNODEHANDLE hXMLNode)
{
	NCXXMLNode			*pNcxXMLNode;
	pNcxXMLNode = (NCXXMLNode *)hXMLNode;

	if (pNcxXMLNode != NULL)
	{
		DEL pNcxXMLNode;
	}
}

void ncxXMLSetNodeName(NCXXMLNODEHANDLE hXMLNode, char *sNodeName)
{
	NCXXMLNode			*pNcxXMLNode;
	pNcxXMLNode = (NCXXMLNode *)hXMLNode;

	if (pNcxXMLNode != NULL)
	{
		pNcxXMLNode->SetNodeName(sNodeName);
	}
}

void ncxXMLSetNodeValue(NCXXMLNODEHANDLE hXMLNode, char *sNodeValue)
{
	NCXXMLNode			*pNcxXMLNode;
	pNcxXMLNode = (NCXXMLNode *)hXMLNode;

	if (pNcxXMLNode != NULL)
	{
		pNcxXMLNode->SetNodeValue(sNodeValue);
	}
}

void ncxXMLAddChildNode(NCXXMLNODEHANDLE hXMLNode, NCXXMLNODEHANDLE hXMLChildNode)
{
	NCXXMLNode			*pNcxXMLNode;
	pNcxXMLNode = (NCXXMLNode *)hXMLNode;

	if (pNcxXMLNode != NULL)
	{
		pNcxXMLNode->AddChildNode((NCXXMLNode*)hXMLChildNode);
	}
}

int ncxXMLGetStringLength(NCXXMLNODEHANDLE hXMLNode)
{
	NCXXMLNode			*pNcxXMLNode;
	pNcxXMLNode = (NCXXMLNode *)hXMLNode;

	if (pNcxXMLNode != NULL)
	{
		return pNcxXMLNode->GetNodeStringLength();
	}

	return 0;
}

char *ncxXMLToString(NCXXMLNODEHANDLE hXMLNode, char *sString, int *nStringLength)
{
	NCXXMLNode			*pNcxXMLNode;
	pNcxXMLNode = (NCXXMLNode *)hXMLNode;

	if (pNcxXMLNode != NULL)
	{
		return pNcxXMLNode->ToString(sString, nStringLength);
	}

	return NULL;
}

int ncxXMLFromString(NCXXMLNODEHANDLE hXMLNode, char *sString)
{
	NCXXMLNode			*pNcxXMLNode;
	pNcxXMLNode = (NCXXMLNode *)hXMLNode;

	if (pNcxXMLNode != NULL)
	{
		return pNcxXMLNode->FromString(sString, 0);
	}

	return -1;
}

NCXXMLNODEHANDLE ncxXMLGetChildNode(NCXXMLNODEHANDLE hXMLNode, char *sNodeName)
{
	NCXXMLNode			*pNcxXMLNode;
	pNcxXMLNode = (NCXXMLNode *)hXMLNode;

	if (pNcxXMLNode != NULL)
	{
		return pNcxXMLNode->GetChildNode(sNodeName);
	}

	return NULL;
}

NCXXMLNODEHANDLE ncxXMLGetFirstChildNode(NCXXMLNODEHANDLE hXMLNode)
{
	NCXXMLNode			*pNcxXMLNode;
	pNcxXMLNode = (NCXXMLNode *)hXMLNode;

	if (pNcxXMLNode != NULL)
	{
		return pNcxXMLNode->GetFirstChildNode();
	}

	return NULL;
}

NCXXMLNODEHANDLE ncxXMLGetNextChildNode(NCXXMLNODEHANDLE hXMLNode, NCXXMLNODEHANDLE hXMLChildNode)
{
	NCXXMLNode			*pNcxXMLNode;
	pNcxXMLNode = (NCXXMLNode *)hXMLNode;

	if (pNcxXMLNode != NULL)
	{
		return pNcxXMLNode->GetNextChildNode((NCXXMLNode*)hXMLChildNode);
	}

	return NULL;
}

char *ncxXMLGetNodeName(NCXXMLNODEHANDLE hXMLNode)
{
	NCXXMLNode			*pNcxXMLNode;
	pNcxXMLNode = (NCXXMLNode *)hXMLNode;

	if (pNcxXMLNode != NULL)
	{
		return pNcxXMLNode->GetNodeName();
	}

	return NULL;
}

char *ncxXMLGetNodeValue(NCXXMLNODEHANDLE hXMLNode)
{
	NCXXMLNode			*pNcxXMLNode;
	pNcxXMLNode = (NCXXMLNode *)hXMLNode;

	if (pNcxXMLNode != NULL)
	{
		return pNcxXMLNode->GetNodeValue();
	}

	return NULL;
}


//////////////////////////////////////////////////////////////////////////
