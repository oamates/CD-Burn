#ifndef _NCXSERVER_H_
#define _NCXSERVER_H_

#include "TaskModel.h"
#include "ClientProcessor.h"
#include "TagUtillity.h"
#include "NCX.h"

typedef ZOSArray<ClientProcessor*> ClientProcessorArray;

class NCXServer 
	: public ZTask
	, public ZTCPListenerEvent
	, public ClientProcessorListener
{
public:
	NCXServer();
	~NCXServer();
public:
	// should be called before Create
	void SetListenPort(int nPort);
	// should be called before Create
	void SetOuterMostTagName(CONST CHAR *sTagName);
	
	int SetCallBack(NCXEventCallBack ncxEventCallBack, void *pContext);

	virtual	BOOL	Create();
	virtual	BOOL	Close();

	int SendProtocolResponse(NCXServerCBParam ncxServerCBParam, const char *sResponse, int nResponseLength);
protected:
	virtual	int		Run(int nEvent = 0);
	int ProcessRecycle();
public:
	virtual	BOOL	OnListenerEvent(CONST int hAccept,CONST struct sockaddr_in* pLocalAddr,
		CONST struct sockaddr_in* pRemoteAddr);
public:
	virtual BOOL OnReceiveCompleteProtocol(ClientProcessor *pClientProcessor, 
		CONST CHAR *sProtocol, int nProtocolLength);
private:
	int						m_nListenPort;
	ZTCPListenerSocket		*m_pTCPListenerSocket;

	// used to mutex m_ClientProcessorArray's oprerate; 
	ZOSMutex				m_mutexClientProcessorArray;
	ClientProcessorArray	m_ClientProcessorArray;

	// used to mutex ClientProcessor's protocol listener.
	// make sure each protocol is given to upper caller one by one.
	// so this required the upper caller must not be blocked when receive a protocol.
	ZOSMutex				m_mutexRecvProtocol;

	CHAR					m_sOuterMostTagName[MAX_TAGNAME_LENGTH];

	NCXEventCallBack		m_EventCallBack;
	void					*m_pContext;
};


#endif //_NCXSERVER_H_
//////////////////////////////////////////////////////////////////////////
