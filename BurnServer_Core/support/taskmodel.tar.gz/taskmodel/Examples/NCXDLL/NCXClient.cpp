#include "NCXClient.h"

NCXClient::NCXClient()
: ZTask("NCXClient")
{
	m_tcpClient.Create();
	m_tcpClient.StreamCreate();
	m_tcpClient.SetNonBlocking(TRUE);

	m_sRecvBuffer		= NULL;
	m_nRecvBufferSize	= 0;
	m_nCurReceivedBytes	= 0;

	memset(m_sOuterMostTagName, 0, MAX_TAGNAME_LENGTH);

	m_bRespondRecvComplete	= false;
	m_bServerClose			= false;
}

NCXClient::~NCXClient()
{
	m_tcpClient.StreamClose();
	m_tcpClient.Close();
	Close();
}

BOOL NCXClient::Create()
{
	ZTask::Create();
	return TRUE;
}

BOOL NCXClient::Close()
{
	SAFE_DELETE_ARRAY(m_sRecvBuffer);

	ZTask::Close();

	return TRUE;
}

void NCXClient::SetOuterMostTagName(CONST CHAR *sTagName)
{
	strncpy(m_sOuterMostTagName, sTagName, MAX_TAGNAME_LENGTH);
}

BOOL NCXClient::ConnectServer(CONST CHAR* sServerIP, int nServerPort, int nWaitSecond)
{
	if (!m_tcpClient.Connect(ZSocket::ConvertAddr(sServerIP), nServerPort))
	{
		LOG_DEBUG(("[NCXClient::ConnectServer] first connect failed\r\n"));
	}

	if (m_tcpClient.ConnectAble(nWaitSecond*1000*1000))
	{
		m_tcpClient.SetRecvBufferSize(DEFAULT_TCP_RECV_BUFFER_SIZE);
		m_tcpClient.SetTask(this);
		m_tcpClient.RequestEvent(ZEvent::EVENT_READ);
		return TRUE;
	}
	else
	{
		LOG_DEBUG(("[NCXClient::ConnectServer] connect failed\r\n"));
		return FALSE;
	}
}

int NCXClient::Communicate(CONST CHAR* sProtocol, int nProtocol, int nWaitSecond)
{
	int nReturn = -1;
	UINT64 nTime = ZOS::milliseconds() + nWaitSecond*1000;

	do 
	{
		m_sRecvBuffer = NEW CHAR[INIT_RECEIVE_BUFFER_SIZE];
		if (m_sRecvBuffer == NULL)
		{
			LOG_ERROR(("[NCXClient::Communicate] NEW RecvBuffer failed\r\n"));
			break;
		}
		m_nRecvBufferSize = INIT_RECEIVE_BUFFER_SIZE;
		m_nCurReceivedBytes = 0;

		if (m_tcpClient.StreamWrite(sProtocol, nProtocol) != nProtocol)
		{
			LOG_ERROR(("[NCXClient::Communicate] StreamWrite ERROR\r\n"));
			break;
		}

		nReturn = 0;
		
	} while (false);

	if (nReturn == -1)
	{
		// send error
		SAFE_DELETE_ARRAY(m_sRecvBuffer);
	}
	else
	{
		nReturn = -2;// default timeout
		while (ZOS::milliseconds() < nTime)
		{
			if (m_bRespondRecvComplete)
			{
				nReturn = 0;
				break;
			}

			if (m_bServerClose)
			{
				nReturn = -3; //server close to fast, client does not recv respond
				break;
			}

			ZOSThread::Sleep(10);
		}
	}

	return nReturn;
}

CHAR * NCXClient::GetRespondProtocol()
{
	return m_sRecvBuffer;
}

int NCXClient::Run(int nEvent)
{
	int				nTaskTime	= 0;
	UINT			nLocalEvent	= 0;

	nLocalEvent	= GetEvent(nEvent);

	ZTask::Run(nLocalEvent);

	if(nLocalEvent&TASK_KILL_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_TIMEOUT_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_READ_EVENT)
	{
		LOG_DEBUG(("[NCXClient::Run] READ EVENT\r\n"));
		ProcessReceive();
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_UPDATE_EVENT)
	{
		nTaskTime	= 0;
	}

	return nTaskTime;
}

void NCXClient::ProcessReceive()
{
	int nData;
	int nRead;
	int nProtocolStartPos;
	int nProtocolLength;


	for (;;)
	{
		CheckRecvBuffer();
		nData = EACH_TIME_RECEIVE_SIZE;
		nRead = m_tcpClient.StreamRead(m_sRecvBuffer+m_nCurReceivedBytes, nData);
		if (nRead > 0)
		{
			m_nCurReceivedBytes += nRead;
			m_tcpClient.RequestEvent(ZEvent::EVENT_READ);
		}
		else
		{
			break;
		}
	}

	if (nRead <= 0)
	{
		if (nRead == ZSOCKET_TIMEOUT)
		{
			if (TagUtillity::IsProtocolComplete(m_sRecvBuffer, m_sOuterMostTagName, &nProtocolStartPos, &nProtocolLength))
			{// get complete format string
				m_bRespondRecvComplete = true;
				ASSERT((nProtocolStartPos == 0));
			}
			else
			{
				m_tcpClient.RequestEvent(ZEvent::EVENT_READ);
			}
		}
		else
		{
			m_bServerClose = true;
		}
	}
}

int NCXClient::CheckRecvBuffer()
{
	int nReturn = -1;
	CHAR *pTemp = NULL;

	if (m_nCurReceivedBytes+EACH_TIME_RECEIVE_SIZE >= m_nRecvBufferSize)
	{
		pTemp = NEW CHAR[m_nRecvBufferSize*RECEIVE_BUFFER_INCREASE_TIMES];
		if (pTemp != NULL)
		{
			memmove(pTemp, m_sRecvBuffer, m_nRecvBufferSize);
			SAFE_DELETE_ARRAY(m_sRecvBuffer);
			m_sRecvBuffer = pTemp;
			m_nRecvBufferSize = m_nRecvBufferSize*RECEIVE_BUFFER_INCREASE_TIMES;
			nReturn = 0;
		}
		else
		{
			LOG_ERROR(("[NCXClient::CheckRecvBuffer] can not NEW enough memory\r\n"));
		}
	}
	else
	{
		nReturn = 0;
	}

	return nReturn;
}

//////////////////////////////////////////////////////////////////////////
