#ifndef _CLIENTPROCESSOR_H_
#define _CLIENTPROCESSOR_H_

#include "TaskModel.h"
#include "TagUtillity.h"

class ClientProcessor;

//////////////////////////////////////////////////////////////////////////
class ClientProcessorListener
{
public:
	virtual BOOL OnReceiveCompleteProtocol(ClientProcessor *pClientProcessor, CONST CHAR *sProtocol, int nProtocolLength);
public:
	ClientProcessorListener();
	virtual ~ClientProcessorListener();
};
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
#define INIT_RECEIVE_BUFFER_SIZE			(1024*10)
#define RECEIVE_BUFFER_INCREASE_TIMES		(3)
#define EACH_TIME_RECEIVE_SIZE				(1024)

//////////////////////////////////////////////////////////////////////////
class ClientProcessor
	: public ZTimeoutTask
{
public:
	ClientProcessor();
	~ClientProcessor();
public:
	virtual	BOOL	Create();
	virtual	BOOL	Close();
	void			SetListener(ClientProcessorListener *pListener);
	void			SetOuterMostTagName(CONST CHAR *sTagName);
	BOOL			AttachClient(CONST int hAcceptSocket, CONST struct sockaddr_in* pRemoteAddr);
	BOOL			IsRecyclable();
	int				SendRespond(CONST CHAR *sProtocol, int nProtocolLength);
	CHAR*			GetRemoteIP();
protected:
	virtual	int		Run(int nEvent = 0);
	void			ProcessReceive();
	int				CheckRecvBuffer();
	void			CloseSession();
protected:
	BOOL			m_bCanRecycle;

	ZOSMutex		m_mutexServerSocket; // used to mutex the use of m_pServerSocket
	ZTCPSocket		*m_pServerSocket;
	
	CHAR			*m_sRecvBuffer;
	int				m_nRecvBufferSize;
	int				m_nCurReceivedBytes;

	CHAR			m_sOuterMostTagName[MAX_TAGNAME_LENGTH];

	ClientProcessorListener		*m_pClientProcessorListener;
};

#endif //_CLIENTPROCESSOR_H_
//////////////////////////////////////////////////////////////////////////
