#include "GetValueThread.h"
#include "ShareDataManager.h"

GetValueThread::GetValueThread()
{
	//
}

GetValueThread::~GetValueThread()
{
	//
}

BOOL GetValueThread::OnThreadStart()
{
	return TRUE;
}

BOOL GetValueThread::OnThreadEntry()
{
	ZOSThread::Sleep(1000);
	int nValue = ShareDataManager::GetInstance()->GetValue();
	LOG_INFO(("[GetValueThread::OnThreadEntry] get value %d\r\n", nValue));
	return TRUE;
}
BOOL GetValueThread::OnThreadStop()
{
	return TRUE;
}
