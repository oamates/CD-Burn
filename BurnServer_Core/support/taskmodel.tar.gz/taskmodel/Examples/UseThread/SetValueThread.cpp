#include "SetValueThread.h"
#include "ShareDataManager.h"

SetValueThread::SetValueThread()
{
	//
}

SetValueThread::~SetValueThread()
{
	//
}

BOOL SetValueThread::OnThreadStart()
{
	return TRUE;
}

BOOL SetValueThread::OnThreadEntry()
{
	ZOSThread::Sleep(1000);
	ShareDataManager::GetInstance()->SetValue(rand());
	return TRUE;
}

BOOL SetValueThread::OnThreadStop()
{
	return TRUE;
}
