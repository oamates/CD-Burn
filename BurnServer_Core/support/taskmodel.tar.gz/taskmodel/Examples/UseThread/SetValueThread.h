#ifndef _SETVALUETHREAD_H_
#define _SETVALUETHREAD_H_

#include "TaskModel.h"

class SetValueThread : public ZOSThread
{
public:
	SetValueThread();
	~SetValueThread();
protected:
	virtual BOOL	OnThreadStart();
	virtual BOOL	OnThreadEntry();
	virtual BOOL	OnThreadStop();
};

#endif //_SETVALUETHREAD_H_
