#ifndef _SHAREDATAMANAGER_H_
#define _SHAREDATAMANAGER_H_

#include "TaskModel.h"

class ShareDataManager
{
public:
	void SetValue(int nValue);
	int GetValue();
public:
	static ShareDataManager* GetInstance();
	static void Initialize();
	static void Uninitialize();
public:
	ShareDataManager();
	~ShareDataManager();
private:
	static ShareDataManager *m_pInstance;
	int				m_nShareData;
	ZOSMutex		m_ShareDataMutex;

};

#endif //_SETVALUETHREAD_H_
