#include "TaskModel.h"
#include "GetValueThread.h"
#include "SetValueThread.h"
#include "ShareDataManager.h"

int main()
{
	static	ZLog log;
	InitTaskModel();

	LOG_SET_LEVEL(ZLog::LOG_DEBUG);

	{
		GetValueThread	*pGetValueThread = new GetValueThread;
		pGetValueThread->Start();

		SetValueThread	*pSetValueThread = new SetValueThread;
		pSetValueThread->Start();

		getchar();

		pSetValueThread->Stop();
		SAFE_DELETE(pSetValueThread);
		pGetValueThread->Stop();
		SAFE_DELETE(pGetValueThread);
	}

	UninitTaskModel();

	return 0;
}
