#include "ShareDataManager.h"

ShareDataManager * ShareDataManager::m_pInstance = NULL;

ShareDataManager::ShareDataManager()
: m_ShareDataMutex("Mutex_ShareData")
{
	m_nShareData = 0;
}

ShareDataManager::~ShareDataManager()
{
	//
}

ShareDataManager* ShareDataManager::GetInstance()
{
	if (m_pInstance == NULL)
	{
		m_pInstance = NEW ShareDataManager();
	}
	return m_pInstance;
}

void ShareDataManager::Initialize()
{
	ShareDataManager::GetInstance();
}

void ShareDataManager::Uninitialize()
{
	SAFE_DELETE(m_pInstance);
}

void ShareDataManager::SetValue(int nValue)
{
	ZOSMutexLocker		locker(&m_ShareDataMutex);
	m_nShareData = nValue;
}

int ShareDataManager::GetValue()
{
	ZOSMutexLocker		locker(&m_ShareDataMutex);

	return m_nShareData;
}
