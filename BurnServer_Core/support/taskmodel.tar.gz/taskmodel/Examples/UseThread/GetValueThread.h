#ifndef _GETVALUETHREAD_H_
#define _GETVALUETHREAD_H_

#include "TaskModel.h"

class GetValueThread : public ZOSThread
{
public:
	GetValueThread();
	~GetValueThread();
protected:
	virtual BOOL	OnThreadStart();
	virtual BOOL	OnThreadEntry();
	virtual BOOL	OnThreadStop();
};

#endif //_GETVALUETHREAD_H_
