#include "UseQueue.h"

MyData::MyData()
{
	m_nValue = 0;
	m_OSQueueElement.SetObject(this);
}

MyData::~MyData()
{
	m_OSQueueElement.SetObject(NULL);
}

void MyData::SetValue(int nValue)
{
	m_nValue = nValue;
}

int MyData::GetValue()
{
	return m_nValue;
}

ZOSQueueElement * MyData::GetQueueElement()
{
	return &m_OSQueueElement;
}

UseQueue::UseQueue()
: m_Queue("MyQueueForTest")
{
	//
}

UseQueue::~UseQueue()
{
	//
}

bool UseQueue::Push(MyData *pMyData)
{
	if (pMyData != NULL)
	{
		if (m_Queue.Push(pMyData->GetQueueElement()) != NULL)
		{
			return true;
		}
	}

	return false;
}

MyData* UseQueue::Pop()
{
	return (MyData*)m_Queue.Pop()->GetObject();
}

void UseQueue::PrintAllData()
{
	ZOSQueue::ELEMENT_FIND_HANDLE	hFindHandle;
	ZOSQueueElement *pQueueElement = NULL;

	LOG_INFO(("[UseQueue::PrintAllData] current state:\r\n"));
	pQueueElement = m_Queue.GetFirst(&hFindHandle);
	while (pQueueElement != NULL)
	{
		MyData *pMyData = (MyData *) pQueueElement->GetObject();
		if (pMyData != NULL)
		{
			LOG_INFO(("[UseQueue::PrintAllData] data value %d\r\n", pMyData->GetValue()));
		}
		pQueueElement = m_Queue.GetNext(&hFindHandle);
	}
	LOG_INFO(("\r\n"));
	LOG_INFO(("\r\n"));
}

void UseQueue::Test()
{
	MyData *pData_0 = NEW MyData;
	MyData *pData_1 = NEW MyData;
	MyData *pData_2 = NEW MyData;
	MyData *pDataTemp = NULL;

	pData_0->SetValue(100);
	pData_1->SetValue(101);
	pData_2->SetValue(102);

	Push(pData_0);
	Push(pData_1);
	Push(pData_2);

	PrintAllData();

	// first time pop
	pDataTemp = Pop();
	if (pDataTemp != NULL)
	{
		LOG_INFO(("[UseQueue::Test] pop value %d\r\n", pDataTemp->GetValue()));
	}
	PrintAllData();

	// second time pop
	pDataTemp = Pop();
	if (pDataTemp != NULL)
	{
		LOG_INFO(("[UseQueue::Test] pop value %d\r\n", pDataTemp->GetValue()));
	}
	PrintAllData();

	// third time pop
	pDataTemp = Pop();
	if (pDataTemp != NULL)
	{
		LOG_INFO(("[UseQueue::Test] pop value %d\r\n", pDataTemp->GetValue()));
	}
	PrintAllData();

	SAFE_DELETE(pData_0);
	SAFE_DELETE(pData_1);
	SAFE_DELETE(pData_2);
}

//////////////////////////////////////////////////////////////////////////



