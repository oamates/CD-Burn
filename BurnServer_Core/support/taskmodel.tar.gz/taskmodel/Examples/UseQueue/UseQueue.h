#ifndef _USEQUEUE_H_
#define _USEQUEUE_H_

#include "TaskModel.h"

class MyData
{
public:
	void SetValue(int nValue);
	int GetValue();
	ZOSQueueElement * GetQueueElement();

public:
	MyData();
	~MyData();
private:
	int					m_nValue;
	ZOSQueueElement		m_OSQueueElement;
};

class UseQueue
{
public:
	bool Push(MyData *pMyData);
	MyData *Pop();
	void PrintAllData();
	void Test();
public:
	UseQueue();
	~UseQueue();
public:
	ZOSQueue			m_Queue;
};


#endif //_USEQUEUE_H_
