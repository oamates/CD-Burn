#include "TaskModel.h"
#include "UseQueue.h"

int main()
{
	static	ZLog log;
	InitTaskModel();

	LOG_SET_LEVEL(ZLog::LOG_DEBUG);

	{
		UseQueue	useQueue;
		useQueue.Test();
	}

	UninitTaskModel();

	return 0;
}

