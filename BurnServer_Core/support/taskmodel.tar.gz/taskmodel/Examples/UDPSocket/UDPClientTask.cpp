#include "UDPClientTask.h"

UDPClientTask::UDPClientTask()
: ZTask("UDPClientTask")
{
	//
}

UDPClientTask::~UDPClientTask()
{
	//
}
//////////////////////////////////////////////////////////////////////////
BOOL UDPClientTask::Create()
{
	ZTask::Create();
	m_udpClientSocket.Create();
	
	return TRUE;
}

BOOL UDPClientTask::Close()
{
	m_udpClientSocket.Close();
	ZTask::Close();
	return TRUE;
}
//////////////////////////////////////////////////////////////////////////
int UDPClientTask::Run(int nEvent)
{
	int				nTaskTime	= 0;
	UINT			nLocalEvent	= 0;

	nLocalEvent	= GetEvent(nEvent);

	ZTask::Run(nLocalEvent);

	if(nLocalEvent&TASK_KILL_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_TIMEOUT_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_READ_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_UPDATE_EVENT)
	{
		nTaskTime	= 0;
	}

	return nTaskTime;
}
//////////////////////////////////////////////////////////////////////////
void UDPClientTask::SendString(CHAR *sIP, int nPort, CHAR *sData, int nData)
{
	if (m_udpClientSocket.GetSocket() != INVALID_FILE_HANDLE)
	{
		m_udpClientSocket.SendTo(sData, nData, ZSocket::ConvertAddr(sIP), nPort);
	}
}
//////////////////////////////////////////////////////////////////////////
