//////////////////////////////////////////////////////////////////////////

#include "TaskModel.h"

#include "UDPServerTask.h"
#include "UDPClientTask.h"
#include <stdio.h>

#define DEFAULT_SEND_IP		"127.0.0.1"


int main()
{
	static	ZLog log;
	InitTaskModel();

	{
		UDPServerTask	udpServerTask;
		udpServerTask.Create();

		UDPClientTask	udpClientTask;
		udpClientTask.Create();

		char sInput[DEFAULT_UDP_COMMUNICATE_LEN];
		while (1)
		{
			gets(sInput);
			if (strlen(sInput)==1 && sInput[0]== 'q')
			{
				break;
			}
			udpClientTask.SendString(DEFAULT_SEND_IP, DEFAULT_UDP_BIND_PORT, sInput, strlen(sInput));
		}

		udpClientTask.Close();
		udpServerTask.Close();
	}

	UninitTaskModel();
	return 0;
}

//////////////////////////////////////////////////////////////////////////
