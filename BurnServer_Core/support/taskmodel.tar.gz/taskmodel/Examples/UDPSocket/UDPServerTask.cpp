#include "UDPServerTask.h"

UDPServerTask::UDPServerTask()
: ZTask("UDPServerTask")
{
	//
}

UDPServerTask::~UDPServerTask()
{
	UDPServerTask::Close();
}
//////////////////////////////////////////////////////////////////////////
BOOL UDPServerTask::Create()
{
	ZTask::Create();

	if (m_UDPServerSocket.Create())
	{
		if (m_UDPServerSocket.Bind(0, DEFAULT_UDP_BIND_PORT))
		{
			m_UDPServerSocket.SetNonBlocking();
			ZTask::AddEvent(ZTask::TASK_READ_EVENT);
		}
	}

	return TRUE;
}
BOOL UDPServerTask::Close()
{
	ZTask::Close();

	return TRUE;
}
int	UDPServerTask::Run(int nEvent)
{
	int				nTaskTime	= 0;
	UINT			nLocalEvent	= 0;

	nLocalEvent	= GetEvent(nEvent);

	ZTask::Run(nLocalEvent);

	if(nLocalEvent&TASK_KILL_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_TIMEOUT_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_READ_EVENT)
	{
		OnReceivePacket();
		nTaskTime	= 90;
	}else
	if(nLocalEvent&TASK_UPDATE_EVENT)
	{
		OnReceivePacket();
		nTaskTime	= 90;
	}

	return nTaskTime;
}
//////////////////////////////////////////////////////////////////////////
BOOL UDPServerTask::OnReceivePacket()
{
#if 0 /*on way*/
	int nSelectCode = 0;
	int hSocket		= m_UDPServerSocket.GetHandle();
	fd_set	fd;
	timeval	tv;

	FD_ZERO(&fd);
	FD_SET(hSocket, &fd);

	tv.tv_sec	= 0;
	tv.tv_usec	= 999;// 1 millsecond

	if (nSelectCode = select(hSocket+1, &fd, NULL, NULL, &tv) > 0)
	{
		if (FD_ISSET(hSocket, &fd))
		{
			UINT nRemoteAddr;
			UINT nRemotePort;
			char sData[DEFAULT_UDP_COMMUNICATE_LEN];
			int nData = DEFAULT_UDP_COMMUNICATE_LEN;
			nData = m_UDPServerSocket.RecvFrom(sData, nData, &nRemoteAddr, &nRemotePort, NULL);
			sData[nData] = '\0';
			LOG_DEBUG(("[UDPServerTask::OnReceivePacket] c->s: %s\r\n", sData));
		}
	}
#else/*the other way*/
	UINT nRemoteAddr;
	UINT nRemotePort;
	char sData[DEFAULT_UDP_COMMUNICATE_LEN];
	int nData = DEFAULT_UDP_COMMUNICATE_LEN;
	nData = m_UDPServerSocket.RecvFrom(sData, nData, &nRemoteAddr, &nRemotePort, NULL);
	if (nData > 0)
	{
		sData[nData] = '\0';
		LOG_DEBUG(("[UDPServerTask::OnReceivePacket] c->s: %s\r\n", sData));
	}
#endif

	return TRUE;
}
//////////////////////////////////////////////////////////////////////////
