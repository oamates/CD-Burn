#ifndef _USEHEAP_H_
#define _USEHEAP_H_

#include "TaskModel.h"

class MyData
{
public:
	void SetValue(int nValue);
	int GetValue();
	ZOSHeapElement * GetHeapElement();

public:
	MyData();
	~MyData();
private:
	int				m_nValue;
	ZOSHeapElement	m_OSHeapElement;
};

class UseHeap
{
public:
	bool Insert(MyData *pMyData);
	MyData * ExtractMin();
	void PrintAllData();
	void Test();
public:
	UseHeap();
	~UseHeap();
private:
	ZOSHeap		m_Heap;
};

#endif //_USEHEAP_H_
