#include "TaskModel.h"
#include "UseHeap.h"

int main()
{
	static	ZLog log;
	InitTaskModel();

	LOG_SET_LEVEL(ZLog::LOG_DEBUG);

	{
		UseHeap		useHeap;
		useHeap.Test();
	}

	UninitTaskModel();

	return 0;
}
