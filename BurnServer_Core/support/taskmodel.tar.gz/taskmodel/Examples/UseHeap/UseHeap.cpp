#include "UseHeap.h"

MyData::MyData()
{
	m_nValue = 0;
	m_OSHeapElement.SetObject(this);
}

MyData::~MyData()
{
	//
}

void MyData::SetValue(int nValue)
{
	m_OSHeapElement.SetValue(nValue);
	m_nValue = nValue;
}

int MyData::GetValue()
{
	return m_nValue;
}

ZOSHeapElement * MyData::GetHeapElement()
{
	return &m_OSHeapElement;
}
//////////////////////////////////////////////////////////////////////////
UseHeap::UseHeap()
:m_Heap("MyHeap")
{

}

UseHeap::~UseHeap()
{
	//
}

bool UseHeap::Insert(MyData *pMyData)
{
	if (pMyData != NULL)
	{
		if (m_Heap.Insert(pMyData->GetHeapElement()) != NULL)
		{
			return true;
		}
	}

	return false;
}

MyData * UseHeap::ExtractMin()
{
	return (MyData*)m_Heap.ExtractMin()->GetObject();
}

void UseHeap::PrintAllData()
{
	// heap element start from 1;
	int i = 1;

	LOG_INFO(("[UseHeap::PrintAllData] current state:\r\n"));
	for (i = 1; i <= m_Heap.HeapCount(); i ++)
	{
		MyData *pMyData = (MyData *)m_Heap.Peek(i)->GetObject();
		if (pMyData != NULL)
		{
			LOG_INFO(("[UseHeap::PrintAllData] data value %d\r\n", pMyData->GetValue()));
		}
	}
	LOG_INFO(("\r\n"));
	LOG_INFO(("\r\n"));
}

void UseHeap::Test()
{
	MyData *pData_0 = NEW MyData;
	MyData *pData_1 = NEW MyData;
	MyData *pData_2 = NEW MyData;
	MyData *pDataTemp = NULL;

	pData_0->SetValue(100);
	pData_1->SetValue(101);
	pData_2->SetValue(102);

	Insert(pData_0);
	Insert(pData_2);
    Insert(pData_1);
	PrintAllData();

	// first get min
	pDataTemp = ExtractMin();
	if (pDataTemp != NULL)
	{
		LOG_INFO(("[UseHeap::Test] min value %d\r\n", pDataTemp->GetValue()));
	}
	PrintAllData();

	// second get min
	pDataTemp = ExtractMin();
	if (pDataTemp != NULL)
	{
		LOG_INFO(("[UseHeap::Test] min value %d\r\n", pDataTemp->GetValue()));
	}
	PrintAllData();

	// third get min
	pDataTemp = ExtractMin();
	if (pDataTemp != NULL)
	{
		LOG_INFO(("[UseHeap::Test] min value %d\r\n", pDataTemp->GetValue()));
	}
	PrintAllData();

	SAFE_DELETE(pData_0);
	SAFE_DELETE(pData_1);
	SAFE_DELETE(pData_2);
}
