#include "SocketWithTask.h"
#include <stdio.h>
#include <string.h>

/************************************************************************/
/* Task TcpServerListener code                  begin                   */
/************************************************************************/
static OS_TCPLISTENERSOCKET_HANDLE  g_hOSTcpListenerSocket = NULL;
static OS_TCPSOCKET_HANDLE      g_hOSTcpServer = NULL;
static CHNSYS_UINT              g_nTcpServerPort = 12580;

CHNSYS_BOOL TcpServerListener_CallBackFunc(CHNSYS_INT hAccept, CHNSYS_UINT nLocalAddr, CHNSYS_UINT nLocalPort,
                                           CHNSYS_UINT nRemoteAddr, CHNSYS_UINT nRemotePort, VOID *pContext)
{
    CHNSYS_CHAR     *sReply = "bye bye";

    g_hOSTcpServer = OS_TCPSOCKET_CreateInstance();
    if (g_hOSTcpServer != NULL)
    {
        if (OS_TCPSOCKET_Attach(g_hOSTcpServer, hAccept, nRemoteAddr, nRemotePort))
        {
            OS_TCPSOCKET_Send(g_hOSTcpServer, sReply, strlen(sReply));
            OS_TCPSOCKET_Close(g_hOSTcpServer);
            OS_TCPSOCKET_DestroyInstance(g_hOSTcpServer);
        }
    }

    return TRUE;
}

CHNSYS_BOOL TCPListenerServerStart()
{
    CHNSYS_BOOL     bReturn = FALSE;

    do 
    {
        g_hOSTcpListenerSocket = OS_TCPLISTENERSOCKET_CreateInstance();
        if (g_hOSTcpListenerSocket == NULL)
        {
            break;
        }

        bReturn = OS_TCPLISTENERSOCKET_Create(g_hOSTcpListenerSocket, TcpServerListener_CallBackFunc,
            NULL, 0, g_nTcpServerPort);
        if (!bReturn)
        {
            break;
        }

        bReturn = TRUE;

    } while (FALSE);

    if (!bReturn)
    {
        if (g_hOSTcpListenerSocket != NULL)
        {
            OS_TCPLISTENERSOCKET_Close(g_hOSTcpListenerSocket);
            OS_TCPLISTENERSOCKET_DestroyInstance(g_hOSTcpListenerSocket);
            g_hOSTcpListenerSocket = NULL;
        }
    }

    return bReturn;
}

VOID TCPListenerServerStop()
{
    if (g_hOSTcpListenerSocket != NULL)
    {
        OS_TCPLISTENERSOCKET_Close(g_hOSTcpListenerSocket);
        OS_TCPLISTENERSOCKET_DestroyInstance(g_hOSTcpListenerSocket);
        g_hOSTcpListenerSocket = NULL;
    }
}

/************************************************************************/
/* Task TcpServerListener code                  end                     */
/************************************************************************/

/************************************************************************/
/* Task TcpClient code                  end                             */
/************************************************************************/
static TASK_TASK_HANDLE    g_hTcpClientReceiveTask;
static OS_TCPSOCKET_HANDLE g_hOSTcpClient = NULL;

CHNSYS_INT My_Task_CB_1(CHNSYS_INT nEventType, VOID *pContext)
{
    CHNSYS_CHAR sData[1024];
    CHNSYS_INT nData = 1024;
    CHNSYS_INT  nReceivedData;

    if (nEventType == TASK_EVENT_READ)
    {
        do 
        {
            memset(sData, 0, 1024);
            nReceivedData = OS_TCPSOCKET_Recv(g_hOSTcpClient, sData, nData);

            if (nReceivedData > 0)
            {
                printf("recv %s\n", sData);
                OS_SOCKET_RequestEvent(g_hOSTcpClient, SOCKET_EVENT_READ);
            }
            else if (nReceivedData == 0)
            {
                printf("server disconnect\n");
                TaskTCPClientStop();
            }

        } while (nReceivedData > 0);
    }

    return 0;
}

CHNSYS_BOOL TCPClientTaskStart()
{
    g_hTcpClientReceiveTask = TASK_TASK_CreateInstance(-1, -1);
    if (g_hTcpClientReceiveTask != NULL)
    {
        TASK_TASK_SetCallBack(g_hTcpClientReceiveTask, My_Task_CB_1, NULL);
        if (TASK_TASK_Create(g_hTcpClientReceiveTask))
        {
            return TRUE;
        }
    }

    return FALSE;
}

VOID TCPClientTaskStop()
{
    if (g_hTcpClientReceiveTask != NULL)
    {
        TASK_TASK_Close(g_hTcpClientReceiveTask);
        TASK_TASK_DestroyInstance(g_hTcpClientReceiveTask);
        g_hTcpClientReceiveTask = NULL;
    }
}

CHNSYS_BOOL TaskTCPClientStart()
{
    CHNSYS_BOOL     bReturn = FALSE;

    do
    {
        g_hOSTcpClient = OS_TCPSOCKET_CreateInstance();
        if (g_hOSTcpClient == NULL)
        {
            break;
        }

        bReturn = OS_TCPSOCKET_Create(g_hOSTcpClient);
        if (!bReturn)
        {
            break;
        }

        if (g_hTcpClientReceiveTask != NULL)
        {
            bReturn = OS_SOCKET_SetTask(g_hOSTcpClient, g_hTcpClientReceiveTask);
        }
        if (!bReturn)
        {
            break;
        }

        bReturn = OS_SOCKET_RequestEvent(g_hOSTcpClient, SOCKET_EVENT_READ);

        bReturn = TRUE;
    } while (FALSE);

    if (!bReturn)
    {
        if (g_hOSTcpClient != NULL)
        {
            OS_TCPSOCKET_Close(g_hOSTcpClient);
            OS_TCPSOCKET_DestroyInstance(g_hOSTcpClient);
            g_hOSTcpClient = NULL;
        }
    }

    return bReturn;
}

VOID TaskTCPClientStop()
{
    if (g_hOSTcpClient != NULL)
    {
        OS_TCPSOCKET_Close(g_hOSTcpClient);
        OS_TCPSOCKET_DestroyInstance(g_hOSTcpClient);
        g_hOSTcpClient = NULL;
    }
}

VOID TaskTCPClientRun(CHNSYS_CHAR *sServerIP, CHNSYS_UINT nServerPort)
{
    CHNSYS_BOOL         bConnectOK = FALSE;

    if (sServerIP == NULL)
    {
        return;
    }

    OS_SOCKET_SetNonBlocking(g_hOSTcpClient, TRUE);
    if (OS_TCPSOCKET_Connect(g_hOSTcpClient, OS_SOCKET_ConvertAddrToUINT(sServerIP), nServerPort))
    {
        bConnectOK = TRUE;
    }
    else
    {
        bConnectOK = OS_TCPSOCKET_ConnectAble(g_hOSTcpClient, 5000);
    }

    getchar();
}

/************************************************************************/
/* Task TcpClient code                  end                             */
/************************************************************************/
