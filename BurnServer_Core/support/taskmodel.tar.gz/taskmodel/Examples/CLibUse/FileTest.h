#ifndef _FILETEST_H_
#define _FILETEST_H_

void TestFile();

#endif //_FILETEST_H_
