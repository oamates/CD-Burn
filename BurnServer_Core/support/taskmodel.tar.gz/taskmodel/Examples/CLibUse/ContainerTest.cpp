#include "ContainerTest.h"
#include "ChnsysLog.h"

void TestIntArray()
{
    int i =0;
    int iCnt = 0;
    int iRet = 0;
    OS_INTARRAY_HANDLE hIntArrayHandle;

    OS_LOG_Init();

    OS_LOG_SET_LEVEL(ZLog::LOG_DEBUG);

#ifdef WIN32
    OS_LOG_SET_PATH("D:\\Task\\log");
#else
    OS_LOG_SET_PATH("/home/Task/log");
#endif

    hIntArrayHandle = OS_INTARRAY_CreateInstance(20);

    for (i=0; i<10; i++)
    {
        OS_INTARRAY_Add(hIntArrayHandle,i);
    }
    
    iCnt = OS_INTARRAY_Count(hIntArrayHandle);
    OS_LOG_INFO(("[TestIntArray] IntArray Count: %d\r\n", iCnt));
    for(i=0; i<iCnt; i++)
    {
        OS_INTARRAY_At(hIntArrayHandle,i,&iRet);
        OS_LOG_INFO(("[TestIntArray] IntArray data: %d\r\n", iRet));
    }

    OS_INTARRAY_Set(hIntArrayHandle,0,100);
    OS_INTARRAY_Insert(hIntArrayHandle,1,60);
    OS_INTARRAY_Remove(hIntArrayHandle,3);
    OS_INTARRAY_Remove(hIntArrayHandle,7);
    OS_INTARRAY_Remove(hIntArrayHandle,5);

    iCnt = OS_INTARRAY_Count(hIntArrayHandle);
    OS_LOG_INFO(("[TestIntArray] IntArray Count: %d\r\n", iCnt));
    for(i=0; i<iCnt; i++)
    {
        OS_INTARRAY_At(hIntArrayHandle,i,&iRet);
        OS_LOG_INFO(("[TestIntArray] IntArray data: %d\r\n", iRet));
    }

    OS_INTARRAY_RemoveAll(hIntArrayHandle);
    OS_LOG_INFO(("[TestIntArray] IntArray Count: %d\r\n", OS_INTARRAY_Count(hIntArrayHandle)));
    OS_INTARRAY_DestroyInstance(hIntArrayHandle);
    OS_LOG_UnInit();
}

void TestVoidArray()
{
    int i=0;
    int iCnt = 0;
    char* sTemp = "aaa";
    OS_VOIDARRAY_HANDLE hVoidArrayHandle;

    OS_LOG_Init();
    OS_LOG_SET_LEVEL(ZLog::LOG_DEBUG);
#ifdef WIN32
    OS_LOG_SET_PATH("D:\\Task\\log");
#else
    OS_LOG_SET_PATH("/home/Task/log");
#endif
    hVoidArrayHandle = OS_VOIDARRAY_CreateInstance(20);

    for(i=0; i<20; i++)
    {
        OS_VOIDARRAY_Add(hVoidArrayHandle,sTemp);
    }
    
    iCnt = OS_VOIDARRAY_Count(hVoidArrayHandle);
    OS_LOG_INFO(("[TestVoidArray] VoidArray Count: %d\r\n", iCnt));
    for(i=0; i<iCnt; i++)
    {
        OS_VOIDARRAY_At(hVoidArrayHandle,i,(VOID**)&sTemp);
        OS_LOG_INFO(("[TestVoidArray] VoidArray data: %s\r\n", sTemp));
    }

    OS_VOIDARRAY_Set(hVoidArrayHandle,0,(VOID*)("bbb"));
    OS_VOIDARRAY_Insert(hVoidArrayHandle,6,(VOID*)("bbb"));
    OS_VOIDARRAY_Remove(hVoidArrayHandle,3);
    OS_VOIDARRAY_Remove(hVoidArrayHandle,7);
    OS_VOIDARRAY_Remove(hVoidArrayHandle,5);

    iCnt = OS_INTARRAY_Count(hVoidArrayHandle);
    OS_LOG_INFO(("[TestVoidArray] VoidArray Count: %d\r\n", iCnt));
    for(i=0; i<iCnt; i++)
    {
        OS_VOIDARRAY_At(hVoidArrayHandle,i,(VOID**)&sTemp);
        OS_LOG_INFO(("[TestVoidArray] VoidArray data: %s\r\n", sTemp));
    }

    OS_VOIDARRAY_RemoveAll(hVoidArrayHandle);
    OS_LOG_INFO(("[TestVoidArray] VoidArray Count: %d\r\n", OS_VOIDARRAY_Count(hVoidArrayHandle)));
    OS_VOIDARRAY_DestroyInstance(hVoidArrayHandle);
    OS_LOG_UnInit();
}


void TestHeap()
{
    char* sTemp = NULL;
    int iCnt = 0;
    OS_HEAPELEMENT_HANDLE hHeapElementHandle,hHeapElementHandle1,tempHeapElementHandle;
    OS_HEAP_HANDLE hHeapHandle;
    OS_HEAP_HANDLE hHeapHandle1;
    CHNSYS_UINT64 iValue = 0;
    OS_LOG_Init();
     OS_LOG_SET_LEVEL(ZLog::LOG_DEBUG);
#ifdef WIN32
    OS_LOG_SET_PATH("D:\\Task\\log");
#else
    OS_LOG_SET_PATH("/home/Task/log");
#endif
    hHeapElementHandle = OS_HEAPELEMENT_CreateInstance(20,(VOID*)("HeapElement"));
    hHeapElementHandle1 = OS_HEAPELEMENT_CreateInstance(5,(VOID*)("HeapElement"));
    hHeapHandle = OS_HEAP_CreateInstance(20);
 
    OS_HEAPELEMENT_SetObject(hHeapElementHandle,(VOID*)("Eelment1"));
    OS_HEAPELEMENT_SetValue(hHeapElementHandle,10);
    OS_HEAPELEMENT_SetObject(hHeapElementHandle1,(VOID*)("Eelment2"));
    OS_HEAPELEMENT_SetValue(hHeapElementHandle1,20);
    
    OS_HEAP_Insert(hHeapHandle,hHeapElementHandle);
    OS_HEAP_Insert(hHeapHandle,hHeapElementHandle1);
    iCnt = OS_HEAP_Count(hHeapHandle);
    OS_LOG_INFO(("[TestHeap] Heap Count: %d\r\n", iCnt));

    OS_HEAPELEMENT_GetHeap(hHeapElementHandle,&hHeapHandle1);
    iCnt = OS_HEAP_Count(hHeapHandle1);
    OS_LOG_INFO(("[TestHeap] Heap1 Count: %d\r\n", iCnt));

    OS_HEAP_PeekMin(hHeapHandle,&tempHeapElementHandle);
    OS_HEAPELEMENT_GetObject(tempHeapElementHandle,(VOID**)&sTemp);
    OS_HEAPELEMENT_GetValue(tempHeapElementHandle,(CHNSYS_UINT64*)&iValue);
    OS_LOG_INFO(("[TestHeap] HeapElement object: %s,value:%d \r\n",sTemp ,iValue));
    iCnt = OS_HEAP_Count(hHeapHandle);
    OS_LOG_INFO(("[TestHeap] Heap Count: %d\r\n", iCnt));
   
    OS_HEAP_ExtractMin(hHeapHandle,&tempHeapElementHandle);
    OS_HEAPELEMENT_GetObject(tempHeapElementHandle,(VOID**)&sTemp);
    OS_HEAPELEMENT_GetValue(tempHeapElementHandle,(CHNSYS_UINT64*)&iValue);
    OS_LOG_INFO(("[TestHeap] HeapElement object: %s,value:%d \r\n",sTemp ,iValue));
    iCnt = OS_HEAP_Count(hHeapHandle);
    OS_LOG_INFO(("[TestHeap] Heap Count: %d\r\n", iCnt));
    
    OS_HEAP_RemoveAll(hHeapHandle);
    iCnt = OS_HEAP_Count(hHeapHandle);
    OS_LOG_INFO(("[TestHeap] Heap Count: %d\r\n", iCnt));

   OS_HEAPELEMENT_DestroyInstance(hHeapElementHandle);
   OS_HEAPELEMENT_DestroyInstance(hHeapElementHandle1);
   OS_HEAP_DestroyInstance(hHeapHandle);
   OS_LOG_UnInit();
}

void TestQueue()
{
    int iCnt = 0;
    int iIndex = 0;
    int i = 0;
    char* sTemp = NULL;
    OS_QUEUE_HANDLE hQueueHandle;
    OS_QUEUEELEMENT_HANDLE hQueueElementHandle,hQueueElementHandle1,hQueueElementHandle2,hQueueElementHandle3,hQueueElementHandle4;
    OS_QUEUEELEMENT_HANDLE tempQueueElementHandle;

    OS_LOG_Init();
    OS_LOG_SET_LEVEL(ZLog::LOG_DEBUG);
#ifdef WIN32
    OS_LOG_SET_PATH("D:\\Task\\log");
#else
    OS_LOG_SET_PATH("/home/Task/log");
#endif
    hQueueElementHandle = OS_QUEUEELEMENT_CreateInstance((VOID*)("qq1"));
    hQueueElementHandle1 = OS_QUEUEELEMENT_CreateInstance((VOID*)("qq2"));
    hQueueElementHandle2 = OS_QUEUEELEMENT_CreateInstance((VOID*)("qq3"));
    hQueueElementHandle3 = OS_QUEUEELEMENT_CreateInstance((VOID*)("qq4"));
    hQueueElementHandle4 = OS_QUEUEELEMENT_CreateInstance((VOID*)("qq5"));
    hQueueHandle = OS_QUEUE_CreateInstance();
    
    OS_QUEUE_Push(hQueueHandle,hQueueElementHandle);
    OS_QUEUE_Push(hQueueHandle,hQueueElementHandle1);
    OS_QUEUE_Push(hQueueHandle,hQueueElementHandle2);
    OS_QUEUE_Push(hQueueHandle,hQueueElementHandle3);
    OS_QUEUE_Push(hQueueHandle,hQueueElementHandle4);

    OS_QUEUE_GetHead(hQueueHandle,&tempQueueElementHandle);
    OS_QUEUEELEMENT_GetObject(tempQueueElementHandle,(VOID**)&sTemp);
    OS_LOG_INFO(("[TestQueue] Queue HeadObject: %s\r\n", sTemp));

    OS_QUEUE_GetTail(hQueueHandle,&tempQueueElementHandle);
    OS_QUEUEELEMENT_GetObject(tempQueueElementHandle,(VOID**)&sTemp);
    OS_LOG_INFO(("[TestQueue] Queue TailObject: %s\r\n", sTemp));

    iCnt = OS_QUEUE_Count(hQueueHandle);
    OS_LOG_INFO(("[TestQueue] Queue Count: %d\r\n", iCnt));
    for(i=0; i<iCnt; i++)
    {
        tempQueueElementHandle = NULL;
        OS_QUEUE_Pop(hQueueHandle,&tempQueueElementHandle);
        OS_QUEUEELEMENT_GetObject(tempQueueElementHandle,(VOID**)&sTemp);
        iIndex = OS_QUEUE_Count(hQueueHandle);
        OS_LOG_INFO(("[TestQueue] Queue count: %d,value:%s \r\n",iIndex,sTemp));
    }

    OS_QUEUEELEMENT_DestroyInstance(hQueueElementHandle);
    OS_QUEUEELEMENT_DestroyInstance(hQueueElementHandle1);
    OS_QUEUEELEMENT_DestroyInstance(hQueueElementHandle2);
    OS_QUEUEELEMENT_DestroyInstance(hQueueElementHandle3);
    OS_QUEUEELEMENT_DestroyInstance(hQueueElementHandle4);
    OS_QUEUE_DestroyInstance(hQueueHandle);
    OS_LOG_UnInit();
}
