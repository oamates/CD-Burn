#include <stdio.h>
#include <stdlib.h>
#include "SocketWithThread.h"
#include "SocketWithTask.h"
#include "ContainerTest.h"
#include "FileTest.h"

void UdpServerProgram()
{
    char cTmp;

    OS_SOCKET_Init();

    UdpServerThreadStart();
    while (1)
    {
        cTmp = getchar();
        if (cTmp == 'q')
        {
            break;
        }
    }
    UdpServerThreadStop();

    OS_SOCKET_Uninit();
}

void UdpClientProgram(char *sServerIP, unsigned int nServerPort)
{
    OS_SOCKET_Init();

    UDPClientStart();
    UDPClientRun(sServerIP, nServerPort);
    UDPClientStop();

    OS_SOCKET_Uninit();
}

void TCPServerProgram()
{
    char cTmp;

    OS_SOCKET_Init();

    TCPAcceptThreadStart();
    TCPServerReceiveThreadStart();
    while (1)
    {
        cTmp = getchar();
        if (cTmp == 'q')
        {
            break;
        }
    }
    TCPServerReceiveThreadStop();
    TCPAcceptThreadStop();

    OS_SOCKET_Uninit();
}

void TcpClientProgram(char *sServerIP, unsigned int nServerPort)
{
    OS_SOCKET_Init();

    TCPClientStart();
    TCPClientRun(sServerIP, nServerPort);
    TCPClientStop();

    OS_SOCKET_Uninit();
}

void TaskTcpServerProgram()
{
    char cTmp;

    OS_SOCKET_Init();
    TASK_POOL_Init(10, 1);

    TCPListenerServerStart();
    while (1)
    {
        cTmp = getchar();
        if (cTmp == 'q')
        {
            break;
        }
    }
    TCPListenerServerStop();

    TASK_POOL_Uninit();
    OS_SOCKET_Uninit();
}


void TaskTcpClientProgram(char *sServerIP, unsigned int nServerPort)
{
    OS_SOCKET_Init();
    TASK_POOL_Init(10, 1);

    TCPClientTaskStart();
    TaskTCPClientStart();

    TaskTCPClientRun(sServerIP, nServerPort);

    TaskTCPClientStop();
    TCPClientTaskStop();

    TASK_POOL_Uninit();
    OS_SOCKET_Uninit();
}



int main (int argc, char *argv[])
{
    int nProgram = 0;

    if (argc > 1)
    {
        nProgram = atoi(argv[1]);
        if (nProgram == 1)
        {
            UdpServerProgram();
        }
        else if (nProgram == 2)
        {
            if (argc > 3)
            {
                UdpClientProgram(argv[2], atoi(argv[3]));
            }
        }
        else if (nProgram == 3)
        {
            TCPServerProgram();
        }
        else if (nProgram == 4)
        {
            if (argc > 3)
            {
                TcpClientProgram(argv[2], atoi(argv[3]));
            }
        }
        else if (nProgram == 5)
        {
            TaskTcpServerProgram();
        }
        else if (nProgram == 6)
        {
            if (argc > 3)
            {
                TaskTcpClientProgram(argv[2], atoi(argv[3]));
            }
        }
        else if (nProgram == 7)
        {
            TestIntArray();
        }
        else if (nProgram == 8)
        {
            TestVoidArray();
        }
        else if (nProgram == 9)
        {
            TestHeap();
        }
        else if (nProgram == 10)
        {
            TestQueue();
        }
        else if (nProgram == 11)
        {
            TestFile();
        }
    }

    return 0;
}
