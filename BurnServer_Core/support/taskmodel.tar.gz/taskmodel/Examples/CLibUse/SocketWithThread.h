#ifndef _SOCKETWITHTHREAD_H_
#define _SOCKETWITHTHREAD_H_

#include "ChnsysSocket.h"
#include "ChnsysThread.h"

CHNSYS_BOOL UDPServerStart();
VOID UDPServerStop();
VOID UDPServerRun();

CHNSYS_BOOL UdpServerThreadStart();
VOID UdpServerThreadStop();

CHNSYS_BOOL UDPClientStart();
VOID UDPClientStop();
VOID UDPClientRun(CHNSYS_CHAR *sServerIP, CHNSYS_UINT nServerPort);

CHNSYS_BOOL TCPServerStart();
VOID TCPServerStop();
VOID TCPServerAccept();

CHNSYS_BOOL TCPAcceptThreadStart();
VOID TCPAcceptThreadStop();

CHNSYS_BOOL TCPServerReceiveThreadStart();
VOID TCPServerReceiveThreadStop();

CHNSYS_BOOL TCPClientStart();
VOID TCPClientStop();
VOID TCPClientRun(CHNSYS_CHAR *sServerIP, CHNSYS_UINT nServerPort);

#endif //_SOCKETWITHTHREAD_H_
