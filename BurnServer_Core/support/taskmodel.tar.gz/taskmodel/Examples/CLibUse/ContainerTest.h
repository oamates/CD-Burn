#ifndef _CONTAINERTEST_H_
#define _CONTAINERTEST_H_

#include "ChnsysTypes.h"
#include "ChnsysContainers.h"
#include "TaskModel.h"

void TestIntArray();
void TestVoidArray();

void TestHeap();
void TestQueue();

#endif //_CONTAINERTEST_H_
