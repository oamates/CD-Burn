#include "SocketWithThread.h"
#include <stdio.h>
#include <string.h>
#include "ChnsysContainers.h"
#include <stdlib.h>
#include "ChnsysThread.h"

#ifdef WIN32
#include <winsock2.h>
#else
#include <sys/select.h>
#endif //_WIN32_

/************************************************************************/
/* UDPServer code                  begin                                */
/************************************************************************/
#define MAX_UDPSERVER_RECV_SIZE         (2048)
#define MAX_UDPSERVER_SEND_SIZE         (2048)
static OS_UDPSOCKET_HANDLE  g_hOSUdpServer      = NULL;
static CHNSYS_UINT          g_nUdpServerPort    = 12315;

CHNSYS_BOOL UDPServerStart()
{
    CHNSYS_BOOL     bReturn = FALSE;

    do 
    {
        g_hOSUdpServer = OS_UDPSOCKET_CreateInstance();
        if (g_hOSUdpServer == NULL)
        {
            break;
        }

        bReturn = OS_UDPSOCKET_Create(g_hOSUdpServer);
        if (!bReturn)
        {
            break;
        }

        bReturn = OS_SOCKET_Bind(g_hOSUdpServer, 0, g_nUdpServerPort);
        if (!bReturn)
        {
            break;
        }

        bReturn = TRUE;
    } while (FALSE);

    if (!bReturn)
    {
        if (g_hOSUdpServer != NULL)
        {
            OS_UDPSOCKET_Close(g_hOSUdpServer);
            OS_UDPSOCKET_DestroyInstance(g_hOSUdpServer);
            g_hOSUdpServer = NULL;
        }
    }

    return bReturn;
}

VOID UDPServerStop()
{
    if (g_hOSUdpServer != NULL)
    {
        OS_UDPSOCKET_Close(g_hOSUdpServer);
        OS_UDPSOCKET_DestroyInstance(g_hOSUdpServer);
        g_hOSUdpServer = NULL;
    }
}

VOID UDPServerRun()
{
    CHNSYS_CHAR         sRecvData[MAX_UDPSERVER_RECV_SIZE];
    CHNSYS_INT          nRecvDataSize = MAX_UDPSERVER_RECV_SIZE;
    CHNSYS_UINT         nRemoteAddr;
    CHNSYS_UINT         nRemotePort;
    CHNSYS_CHAR         sSendData[MAX_UDPSERVER_SEND_SIZE];
    CHNSYS_INT          nSendDataSize = MAX_UDPSERVER_SEND_SIZE;

    memset(sSendData, 0, MAX_UDPSERVER_SEND_SIZE);
    if (g_hOSUdpServer != NULL)
    {
        nRecvDataSize = OS_UDPSOCKET_RecvFrom(g_hOSUdpServer, sRecvData, nRecvDataSize,
            &nRemoteAddr, &nRemotePort);
        if (nRecvDataSize > 0)
        {
            sprintf(sSendData, "%s", "UDPServer Recveive: ");
            memcpy(sSendData+strlen(sSendData), sRecvData, nRecvDataSize);
            nSendDataSize = nRecvDataSize+strlen(sSendData);
            if (
                OS_UDPSOCKET_SendTo(g_hOSUdpServer, sSendData, nSendDataSize, 
                nRemoteAddr, nRemotePort) == nSendDataSize
                )
            {
                //send success
            }
        }
    }
}

/************************************************************************/
/* UDPServer code                  end                                  */
/************************************************************************/

/************************************************************************/
/* UDPServer Thread code               begin                            */
/************************************************************************/
static OS_THREAD_HANDLE         g_hOSUDPServerThread = NULL;

CHNSYS_BOOL UdpServerThreadFunc(OS_THREAD_HANDLE hOSThread, int nThreadPhase, VOID *pContext)
{
    if (nThreadPhase == 1)
    {
        return UDPServerStart();
    }
    else if (nThreadPhase == 3)
    {
        UDPServerStop();
        return TRUE;
    }
    else if (nThreadPhase == 2)
    {
        UDPServerRun();
        return TRUE;
    }

    return FALSE;
}

CHNSYS_BOOL UdpServerThreadStart()
{
    g_hOSUDPServerThread = OS_THREAD_CreateInstance();
    if (g_hOSUDPServerThread != NULL)
    {
        OS_THREAD_SetCallBack(g_hOSUDPServerThread, UdpServerThreadFunc, NULL);
        OS_THREAD_Start(g_hOSUDPServerThread);
        return TRUE;
    }

    return FALSE;
}

VOID UdpServerThreadStop()
{
    if (g_hOSUDPServerThread != NULL)
    {
        UDPServerStop();
        OS_THREAD_Stop(g_hOSUDPServerThread, TRUE);
        OS_THREAD_DestroyInstance(g_hOSUDPServerThread);
        g_hOSUDPServerThread = NULL;
    }
}

/************************************************************************/
/* UDPServer Thread code               end                              */
/************************************************************************/

/************************************************************************/
/* UDPClient code                    begin                              */
/************************************************************************/

#define MAX_UDPCLIENT_SEND_SIZE         (2048)
static OS_UDPSOCKET_HANDLE  g_hOSUdpClient      = NULL;
//static CHNSYS_CHAR *        g_sServerIP         = "10.1.10.225";

CHNSYS_BOOL UDPClientStart()
{
    CHNSYS_BOOL     bReturn = FALSE;

    do 
    {
        g_hOSUdpClient = OS_UDPSOCKET_CreateInstance();
        if (g_hOSUdpClient == NULL)
        {
            break;
        }

        bReturn = OS_UDPSOCKET_Create(g_hOSUdpClient);
        if (!bReturn)
        {
            break;
        }

        bReturn = TRUE;
    } while (FALSE);

    if (!bReturn)
    {
        if (g_hOSUdpClient != NULL)
        {
            OS_UDPSOCKET_Close(g_hOSUdpClient);
            OS_UDPSOCKET_DestroyInstance(g_hOSUdpClient);
            g_hOSUdpClient = NULL;
        }
    }

    return bReturn;
}

VOID UDPClientStop()
{
    if (g_hOSUdpClient != NULL)
    {
        OS_UDPSOCKET_Close(g_hOSUdpClient);
        OS_UDPSOCKET_DestroyInstance(g_hOSUdpClient);
        g_hOSUdpClient = NULL;
    }
}

VOID UDPClientRun(CHNSYS_CHAR *sServerIP, CHNSYS_UINT nServerPort)
{
    CHNSYS_CHAR         sSendData[MAX_UDPCLIENT_SEND_SIZE];

    while (1)
    {
        memset(sSendData, 0, MAX_UDPCLIENT_SEND_SIZE);
        gets(sSendData);
        if (strcmp("quit", sSendData) != 0)
        {
            OS_UDPSOCKET_SendTo(g_hOSUdpClient, sSendData, strlen(sSendData)+1, 
                OS_SOCKET_ConvertAddrToUINT(sServerIP), nServerPort);
        }
        else
        {
            break;
        }
    }
}
/************************************************************************/
/* UDPClient  code                          end                         */
/************************************************************************/

/************************************************************************/
/* TCPServer  code                    begin                             */
/************************************************************************/
typedef struct _CLIENT_INFO_ 
{
    CHNSYS_INT      nClientSocket;
    CHNSYS_UINT     nRemoteAddr;
    CHNSYS_UINT     nRemotePort;
    OS_TCPSOCKET_HANDLE     hOSTcpSocket;
}CLIENT_INFO;

VOID AddClient(CLIENT_INFO clientInfo);
VOID DeleteClient(CLIENT_INFO clientInfo);
VOID ClearClient();

static OS_TCPSOCKET_HANDLE  g_hOSTcpServer      = NULL;
static CHNSYS_UINT          g_nTcpServerPort    = 10086;

static OS_VOIDARRAY_HANDLE  g_hArrayClient      = NULL;
static OS_MUTEX_HANDLE      g_hMutexArrayClient = NULL;


CHNSYS_BOOL TCPServerStart()
{
    CHNSYS_BOOL     bReturn = FALSE;

    do 
    {
        g_hOSTcpServer = OS_TCPSOCKET_CreateInstance();
        if (g_hOSTcpServer == NULL)
        {
            break;
        }

        bReturn = OS_TCPSOCKET_Create(g_hOSTcpServer);
        if (!bReturn)
        {
            break;
        }

        bReturn = OS_SOCKET_Bind(g_hOSTcpServer, 0, g_nTcpServerPort);
        if (!bReturn)
        {
            break;
        }

        bReturn = OS_TCPSOCKET_Listen(g_hOSTcpServer, 100);
        if (!bReturn)
        {
            break;
        }

        g_hMutexArrayClient = OS_MUTEX_CreateInstance();
        if (!bReturn)
        {
            break;
        }

        bReturn = TRUE;
    } while (FALSE);

    if (!bReturn)
    {
        if (g_hOSTcpServer != NULL)
        {
            OS_TCPSOCKET_Close(g_hOSTcpServer);
            OS_TCPSOCKET_DestroyInstance(g_hOSTcpServer);
            g_hOSTcpServer = NULL;
        }

        if (g_hMutexArrayClient != NULL)
        {
            OS_MUTEX_DestroyInstance(g_hMutexArrayClient);
            g_hMutexArrayClient = NULL;
        }
    }

    return bReturn;
}

VOID TCPServerStop()
{
    if (g_hOSTcpServer != NULL)
    {
        OS_TCPSOCKET_Close(g_hOSTcpServer);
        OS_TCPSOCKET_DestroyInstance(g_hOSTcpServer);
        g_hOSTcpServer = NULL;
    }

    ClearClient();

    if (g_hMutexArrayClient != NULL)
    {
        OS_MUTEX_DestroyInstance(g_hMutexArrayClient);
        g_hMutexArrayClient = NULL;
    }
}

VOID AddClient(CLIENT_INFO clientInfo)
{
    CLIENT_INFO *pInfo;

    if (g_hMutexArrayClient != NULL)
    {
        OS_MUTEX_Lock(g_hMutexArrayClient);
        if (g_hArrayClient == NULL)
        {
            g_hArrayClient = OS_VOIDARRAY_CreateInstance(10);
        }
        if (g_hArrayClient != NULL)
        {
            pInfo = (CLIENT_INFO*)malloc(sizeof(CLIENT_INFO));
            memcpy(pInfo, &clientInfo, sizeof(CLIENT_INFO));
            OS_VOIDARRAY_Add(g_hArrayClient, pInfo);
        }
        OS_MUTEX_Unlock(g_hMutexArrayClient);
    }
}

CHNSYS_BOOL GetClient(CLIENT_INFO *pInClientInfo)
{
    CHNSYS_INT  i = 0;
    CHNSYS_INT  nArrayCount = 0;
    CLIENT_INFO *pClientInfo = NULL;
    CHNSYS_BOOL bReturn = FALSE;

    if (pInClientInfo == NULL)
    {
        return FALSE;
    }

    if (g_hMutexArrayClient != NULL)
    {
        OS_MUTEX_Lock(g_hMutexArrayClient);
        if (g_hArrayClient != NULL)
        {
            nArrayCount = OS_VOIDARRAY_Count(g_hArrayClient);
            for (i = 0; i < nArrayCount; i ++)
            {
                if (OS_VOIDARRAY_At(g_hArrayClient, i, (VOID **)&pClientInfo) == 0)
                {
                    if (
                        (pClientInfo != NULL)
                        && (pInClientInfo->nClientSocket == pClientInfo->nClientSocket)
                        )
                    {
                        pInClientInfo->nClientSocket = pClientInfo->nClientSocket;
                        pInClientInfo->hOSTcpSocket = pClientInfo->hOSTcpSocket;
                        pInClientInfo->nRemoteAddr = pClientInfo->nRemoteAddr;
                        pInClientInfo->nRemotePort = pClientInfo->nRemotePort;

                        bReturn = TRUE;
                        break;
                    }
                }
            }

        }
        OS_MUTEX_Unlock(g_hMutexArrayClient);
    }

    return bReturn;
}

VOID DeleteClient(CLIENT_INFO clientInfo)
{
    CHNSYS_INT  i = 0;
    CHNSYS_INT  nArrayCount = 0;
    CLIENT_INFO *pClientInfo = NULL;

    if (g_hMutexArrayClient != NULL)
    {
        OS_MUTEX_Lock(g_hMutexArrayClient);
        if (g_hArrayClient != NULL)
        {
            nArrayCount = OS_VOIDARRAY_Count(g_hArrayClient);
            for (i = 0; i < nArrayCount; i ++)
            {
                if (OS_VOIDARRAY_At(g_hArrayClient, i, (VOID **)&pClientInfo) == 0)
                {
                    if (
                        (pClientInfo != NULL)
                        && (clientInfo.nClientSocket == pClientInfo->nClientSocket)
                        && (clientInfo.nRemoteAddr == pClientInfo->nRemoteAddr)
                        && (clientInfo.nRemotePort == pClientInfo->nRemotePort)
                        )
                    {
                        if (pClientInfo->hOSTcpSocket != NULL)
                        {
                            OS_TCPSOCKET_Close(pClientInfo->hOSTcpSocket);
                            OS_TCPSOCKET_DestroyInstance(pClientInfo->hOSTcpSocket);
                        }
                        free(pClientInfo);
                        OS_VOIDARRAY_Remove(g_hArrayClient, i);
                        break;
                    }
                }
            }

        }
        OS_MUTEX_Unlock(g_hMutexArrayClient);
    }
}

VOID ClearClient()
{
    if (g_hMutexArrayClient != NULL)
    {
        OS_MUTEX_Lock(g_hMutexArrayClient);

        if (g_hArrayClient != NULL)
        {
            OS_VOIDARRAY_RemoveAll(g_hArrayClient);
        }

        OS_MUTEX_Unlock(g_hMutexArrayClient);
    }
}

VOID TCPServerAccept()
{
    CLIENT_INFO clientInfo;

    if (g_hOSTcpServer != NULL)
    {
        if (OS_TCPSOCKET_Accept(g_hOSTcpServer, &clientInfo.nClientSocket, &clientInfo.nRemoteAddr, &clientInfo.nRemotePort))
        {
            OS_TCPSOCKET_HANDLE hOSTcpSocket = OS_TCPSOCKET_CreateInstance();
            if (hOSTcpSocket != NULL)
            {
                clientInfo.hOSTcpSocket = hOSTcpSocket;
                OS_TCPSOCKET_Attach(hOSTcpSocket, clientInfo.nClientSocket, clientInfo.nRemoteAddr, clientInfo.nRemotePort);
                OS_SOCKET_SetNonBlocking(hOSTcpSocket, TRUE);
                AddClient(clientInfo);
            }
        }
    }
}
/************************************************************************/
/* TCPServer  code                    end                               */
/************************************************************************/

/************************************************************************/
/* TCPServer Accept Thread code         begin                           */
/************************************************************************/
static OS_THREAD_HANDLE         g_hTCPServerAcceptThread = NULL;

CHNSYS_BOOL TcpAcceptThreadFunc(OS_THREAD_HANDLE hOSThread, int nThreadPhase, VOID *pContext)
{
    if (nThreadPhase == 1)
    {
        return TCPServerStart();
    }
    else if (nThreadPhase == 3)
    {
        TCPServerStop();
        return TRUE;
    }
    else if (nThreadPhase == 2)
    {
        TCPServerAccept();
        return TRUE;
    }

    return FALSE;
}

CHNSYS_BOOL TCPAcceptThreadStart()
{
    g_hTCPServerAcceptThread = OS_THREAD_CreateInstance();
    if (g_hTCPServerAcceptThread != NULL)
    {
        OS_THREAD_SetCallBack(g_hTCPServerAcceptThread, TcpAcceptThreadFunc, NULL);
        OS_THREAD_Start(g_hTCPServerAcceptThread);
        return TRUE;
    }

    return FALSE;
}

VOID TCPAcceptThreadStop()
{
    if (g_hTCPServerAcceptThread != NULL)
    {
        TCPServerStop();
        OS_THREAD_Stop(g_hTCPServerAcceptThread, TRUE);
        OS_THREAD_DestroyInstance(g_hTCPServerAcceptThread);
        g_hTCPServerAcceptThread = NULL;
    }
}

/************************************************************************/
/* TCPServer Accept Thread code         end                             */
/************************************************************************/

/************************************************************************/
/* TCPServer receive Thread code         begin                          */
/************************************************************************/
static OS_THREAD_HANDLE         g_hTCPServerReceiveThread = NULL;
// g_ReadSet and g_WriteSet operate need mutex. this example omit it.
static fd_set                   g_ReadSet;
static fd_set                   g_WriteSet;

static CHNSYS_INT               g_nMaxFds = 0;

#define MAX_TCPSERVER_RECV_DATA         (4096)

VOID InitSet()
{
    FD_ZERO(&g_ReadSet);
    FD_ZERO(&g_WriteSet);
}

VOID AddToSet(CHNSYS_INT hLowSocket)
{
    if (!FD_ISSET(hLowSocket, &g_ReadSet))
    {
        FD_SET(hLowSocket, &g_ReadSet);
    }

    if (!FD_ISSET(hLowSocket, &g_WriteSet))
    {
        FD_SET(hLowSocket, &g_WriteSet);
    }
}

VOID DeleteFromSet(CHNSYS_INT hLowSocket)
{
    FD_CLR(hLowSocket, &g_ReadSet);
    FD_CLR(hLowSocket, &g_WriteSet);
}

VOID AddAllClientSocketToSet()
{
    CHNSYS_INT  i = 0;
    CHNSYS_INT  nArrayCount = 0;
    CLIENT_INFO *pClientInfo = NULL;

    if (g_hMutexArrayClient != NULL)
    {
        OS_MUTEX_Lock(g_hMutexArrayClient);
        if (g_hArrayClient != NULL)
        {
            nArrayCount = OS_VOIDARRAY_Count(g_hArrayClient);
            for (i = 0; i < nArrayCount; i ++)
            {
                if (OS_VOIDARRAY_At(g_hArrayClient, i, (VOID **)&pClientInfo) == 0)
                {
                    if (pClientInfo != NULL)
                    {
                        if (pClientInfo->nClientSocket > g_nMaxFds)
                        {
                            g_nMaxFds = pClientInfo->nClientSocket;
                        }
                        AddToSet(pClientInfo->nClientSocket);
                    }
                }
            }
        }
        OS_MUTEX_Unlock(g_hMutexArrayClient);
    }
}

CHNSYS_INT GetSockFromReadSet(CHNSYS_INT *pIndex)
{
    CHNSYS_INT  i = 0;
    CHNSYS_INT  nArrayCount = 0;
    CLIENT_INFO *pClientInfo = NULL;
    CHNSYS_INT  nReturn = -1;

    if (g_hMutexArrayClient != NULL)
    {
        OS_MUTEX_Lock(g_hMutexArrayClient);
        if (g_hArrayClient != NULL)
        {
            nArrayCount = OS_VOIDARRAY_Count(g_hArrayClient);
            for (i = *pIndex; i < nArrayCount; i ++)
            {
                if (OS_VOIDARRAY_At(g_hArrayClient, i, (VOID **)&pClientInfo) == 0)
                {
                    if (pClientInfo != NULL)
                    {
                        if (FD_ISSET(pClientInfo->nClientSocket, &g_ReadSet))
                        {
                            *pIndex = i;
                            nReturn = pClientInfo->nClientSocket;
                            FD_CLR(pClientInfo->nClientSocket, &g_ReadSet);
                            FD_SET(pClientInfo->nClientSocket, &g_ReadSet);
                            break;
                        }
                    }
                }
            }
        }
        OS_MUTEX_Unlock(g_hMutexArrayClient);
    }

    return nReturn;
}

VOID SendDataToAllClient(CHNSYS_CHAR *sData, CHNSYS_INT nData)
{
    CHNSYS_INT  i = 0;
    CHNSYS_INT  nArrayCount = 0;
    CLIENT_INFO *pClientInfo = NULL;

    if (g_hMutexArrayClient != NULL)
    {
        OS_MUTEX_Lock(g_hMutexArrayClient);
        if (g_hArrayClient != NULL)
        {
            nArrayCount = OS_VOIDARRAY_Count(g_hArrayClient);
            for (i = 0; i < nArrayCount; i ++)
            {
                if (OS_VOIDARRAY_At(g_hArrayClient, i, (VOID **)&pClientInfo) == 0)
                {
                    if (pClientInfo != NULL)
                    {
                        OS_TCPSOCKET_Send(pClientInfo->hOSTcpSocket, sData, nData);
                    }
                }
            }
        }
        OS_MUTEX_Unlock(g_hMutexArrayClient);
    }
}

VOID RecvDataSendToAll(CHNSYS_INT hSocket)
{
    CHNSYS_CHAR sData[MAX_TCPSERVER_RECV_DATA];
    CHNSYS_INT nData = MAX_TCPSERVER_RECV_DATA;
    CLIENT_INFO clientInfo;
    CHNSYS_INT  nReceivedData;
    CHNSYS_CHAR sSendData[MAX_TCPSERVER_RECV_DATA];

    clientInfo.nClientSocket = hSocket;
    if (GetClient(&clientInfo))
    {
        do 
        {
            memset(sData, 0, MAX_TCPSERVER_RECV_DATA);
            memset(sSendData, 0, MAX_TCPSERVER_RECV_DATA);
            nReceivedData = OS_TCPSOCKET_Recv(clientInfo.hOSTcpSocket, sData, nData);

            if (nReceivedData > 0)
            {
                sprintf(sSendData, "recv from %s %d data: %s", 
                    OS_SOCKET_ConvertAddrToSTRING(clientInfo.nRemoteAddr),
                    clientInfo.nRemotePort,
                    sData);
                SendDataToAllClient(sSendData, strlen(sSendData));
            }
            else if (nReceivedData == 0)
            {
                DeleteFromSet(clientInfo.nClientSocket);
                DeleteClient(clientInfo);
            }

        } while (nReceivedData > 0);
    }

}

CHNSYS_BOOL TcpServerReceiveProcess()
{
    struct	timeval	tv;
    CHNSYS_INT      nSelectCount = 0;
    CHNSYS_INT      nIndex = 0;
    CHNSYS_INT      hSocket = 0;


    tv.tv_usec	= (100*1000);
    tv.tv_sec	= 0;

    AddAllClientSocketToSet();

    nSelectCount = select(g_nMaxFds+1, &g_ReadSet, NULL/*&g_WriteSet*/, NULL, &tv);
    if (nSelectCount > 0)
    {
        hSocket = GetSockFromReadSet(&nIndex);
        while (hSocket != -1)
        {
            RecvDataSendToAll(hSocket);
            nIndex ++;
            hSocket = GetSockFromReadSet(&nIndex);
        }
    }

    return TRUE;
}

CHNSYS_BOOL TcpServerReceiveThreadFunc(OS_THREAD_HANDLE hOSThread, int nThreadPhase, VOID *pContext)
{
    if (nThreadPhase == 1)
    {
        return TRUE;
    }
    else if (nThreadPhase == 3)
    {
        return TRUE;
    }
    else if (nThreadPhase == 2)
    {
        return TcpServerReceiveProcess();
    }

    return FALSE;
}

CHNSYS_BOOL TCPServerReceiveThreadStart()
{
    g_hTCPServerReceiveThread = OS_THREAD_CreateInstance();
    if (g_hTCPServerReceiveThread != NULL)
    {
        OS_THREAD_SetCallBack(g_hTCPServerReceiveThread, TcpServerReceiveThreadFunc, NULL);
        OS_THREAD_Start(g_hTCPServerReceiveThread);
        return TRUE;
    }

    return FALSE;
}

VOID TCPServerReceiveThreadStop()
{
    if (g_hTCPServerReceiveThread != NULL)
    {
        OS_THREAD_Stop(g_hTCPServerReceiveThread, TRUE);
        OS_THREAD_DestroyInstance(g_hTCPServerReceiveThread);
        g_hTCPServerReceiveThread = NULL;
    }
}
/************************************************************************/
/* TCPServer receive Thread code         end                            */
/************************************************************************/

/************************************************************************/
/* TCPClient  code         begin                                        */
/************************************************************************/
static OS_TCPSOCKET_HANDLE  g_hOSTcpClient      = NULL;
#define MAX_TCPCLIENT_SEND_SIZE     (1024)

CHNSYS_BOOL TCPClientStart()
{
    CHNSYS_BOOL     bReturn = FALSE;

    do 
    {
        g_hOSTcpClient = OS_TCPSOCKET_CreateInstance();
        if (g_hOSTcpClient == NULL)
        {
            break;
        }

        bReturn = OS_TCPSOCKET_Create(g_hOSTcpClient);
        if (!bReturn)
        {
            break;
        }

        bReturn = TRUE;
    } while (FALSE);

    if (!bReturn)
    {
        if (g_hOSTcpClient != NULL)
        {
            OS_TCPSOCKET_Close(g_hOSTcpClient);
            OS_TCPSOCKET_DestroyInstance(g_hOSTcpClient);
            g_hOSTcpClient = NULL;
        }
    }

    return bReturn;
}

VOID TCPClientStop()
{
    if (g_hOSTcpClient != NULL)
    {
        OS_TCPSOCKET_Close(g_hOSTcpClient);
        OS_TCPSOCKET_DestroyInstance(g_hOSTcpClient);
        g_hOSTcpClient = NULL;
    }
}

VOID TCPClientRun(CHNSYS_CHAR *sServerIP, CHNSYS_UINT nServerPort)
{
    CHNSYS_CHAR         sSendData[MAX_TCPCLIENT_SEND_SIZE];
    CHNSYS_INT          nSendData = MAX_TCPCLIENT_SEND_SIZE;
    CHNSYS_BOOL         bConnectOK = FALSE;

    if (sServerIP == NULL)
    {
        return;
    }

    OS_SOCKET_SetNonBlocking(g_hOSTcpClient, TRUE);
    if (OS_TCPSOCKET_Connect(g_hOSTcpClient, OS_SOCKET_ConvertAddrToUINT(sServerIP), nServerPort))
    {
        bConnectOK = TRUE;
    }
    else
    {
        bConnectOK = OS_TCPSOCKET_ConnectAble(g_hOSTcpClient, 5000);
    }

    while (bConnectOK)
    {
        memset(sSendData, 0, MAX_TCPCLIENT_SEND_SIZE);
        gets(sSendData);
        if (strcmp("quit", sSendData) != 0)
        {
            OS_TCPSOCKET_Send(g_hOSTcpClient, sSendData, nSendData);
        }
        else
        {
            break;
        }
    }
}
/************************************************************************/
/* TCPClient  code         end                                          */
/************************************************************************/
