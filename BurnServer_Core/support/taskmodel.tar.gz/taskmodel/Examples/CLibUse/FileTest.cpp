#include "FileTest.h"
#include "ChnsysFiles.h"
#include <string.h>

VOID TestFile()
{
    OS_FILE_HANDLE  hFileHandle;
    CHNSYS_INT64 nSize = 0;
    CHNSYS_INT64 nPos = 0;
    CHNSYS_CHAR *sWriteData = "hello world";
    CHNSYS_CHAR sReadData[1024];
    CHNSYS_CHAR *sPath;

    hFileHandle = OS_FILE_CreateInstance();
    if (hFileHandle != NULL)
    {
#ifdef WIN32
        OS_FILE_Create(hFileHandle, "C:\\abc.txt");
#else
        OS_FILE_Create(hFileHandle, "/home/abc.txt");
#endif
        OS_FILE_Write(hFileHandle, sWriteData, strlen(sWriteData));
        OS_FILE_Close(hFileHandle);
#ifdef WIN32
        OS_FILE_Open(hFileHandle,"C:\\abc.txt");
#else
        OS_FILE_Open(hFileHandle,"/home/abc.txt");
#endif
        nSize = OS_FILE_GetSize(hFileHandle);
        nPos = OS_FILE_GetPosition(hFileHandle);
        OS_FILE_Seek(hFileHandle,5);
        nPos = OS_FILE_GetPosition(hFileHandle);
        OS_FILE_SetPosition(hFileHandle,6);
        memset(sReadData,0,1024);
        OS_FILE_Read(hFileHandle,sReadData,1024);
        sPath = OS_FILE_GetPath(hFileHandle);
        OS_FILE_Close(hFileHandle);

        OS_FILE_DestroyInstance(hFileHandle);
    }

}
