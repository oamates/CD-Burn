#ifndef _SOCKETWITHTASK_H_
#define _SOCKETWITHTASK_H_

#include "ChnsysSocket.h"
#include "ChnsysTask.h"


CHNSYS_BOOL TCPListenerServerStart();
VOID TCPListenerServerStop();

CHNSYS_BOOL TCPClientTaskStart();
VOID TCPClientTaskStop();
CHNSYS_BOOL TaskTCPClientStart();
VOID TaskTCPClientStop();
VOID TaskTCPClientRun(CHNSYS_CHAR *sServerIP, CHNSYS_UINT nServerPort);

#endif //_SOCKETWITHTASK_H_
