#include "stdafx.h"
#include "MyTask.h"

MyTask::MyTask()
: ZTask("MyTask")
{
	m_cCurCharacter = ' ';
}

MyTask::~MyTask()
{
	MyTask::Close();
}
//////////////////////////////////////////////////////////////////////////
BOOL MyTask::Create()
{
	ZTask::Create();
	return TRUE;
}
BOOL MyTask::Close()
{
	ZTask::Close();
	return TRUE;
}
//////////////////////////////////////////////////////////////////////////
int	MyTask::Run(int nEvent)
{
	int				nTaskTime	= 0;
	UINT			nLocalEvent	= 0;

	nLocalEvent	= GetEvent(nEvent);

	ZTask::Run(nLocalEvent);

	if(nLocalEvent&TASK_KILL_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_TIMEOUT_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_READ_EVENT)
	{
		LOG_DEBUG(("[MyTask::Run] read char [%c]\r\n", m_cCurCharacter));
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_UPDATE_EVENT)
	{
		nTaskTime	= 0;
	}

	return nTaskTime;
}
//////////////////////////////////////////////////////////////////////////
int MyTask::ReadChar(char cRead)
{
	m_cCurCharacter = cRead;
	ZTask::AddEvent(TASK_READ_EVENT);

	return 0;
}
//////////////////////////////////////////////////////////////////////////
