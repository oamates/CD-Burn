#include <stdio.h>
#include <string.h>
#include "NCX.h"


#ifdef WIN32

#ifdef _DEBUG
#pragma comment(lib, "../Debug/NCXDLLd.lib")
#else
#pragma comment(lib, "../Release/NCXDLL.lib")
#endif

#endif//WIN32


int main()
{
	ncxInitNCXEnvironment();

	NCXXMLNODEHANDLE hNodeTVW = ncxCreateXMLNode();
	ncxXMLSetNodeName(hNodeTVW, "tvw");
	NCXXMLNODEHANDLE hNodeCMD = ncxCreateXMLNode();
	ncxXMLSetNodeName(hNodeCMD, "cmd");
	NCXXMLNODEHANDLE hNodeParam = ncxCreateXMLNode();
	ncxXMLSetNodeName(hNodeParam, "param");
	ncxXMLSetNodeValue(hNodeParam, "200");
	ncxXMLAddChildNode(hNodeCMD, hNodeParam);
	ncxXMLAddChildNode(hNodeTVW, hNodeCMD);

	hNodeCMD = ncxCreateXMLNode();
	ncxXMLSetNodeName(hNodeCMD, "cmd");
	hNodeParam = ncxCreateXMLNode();
	ncxXMLSetNodeName(hNodeParam, "param");
	ncxXMLSetNodeValue(hNodeParam, "100");
	ncxXMLAddChildNode(hNodeCMD, hNodeParam);
	ncxXMLAddChildNode(hNodeTVW, hNodeCMD);

	int nProtocolLength = ncxXMLGetStringLength(hNodeTVW);
	char *sProtocol = new char[nProtocolLength+1];
	memset(sProtocol, 0, nProtocolLength+1);
	ncxXMLToString(hNodeTVW, sProtocol, &nProtocolLength);

	ncxDestroyXMLNode(hNodeTVW);

	NCXCLIENTHANDLE hNcxClientHandle = ncxCreateNCXClient();
	if (hNcxClientHandle != NULL)
	{
		ncxSetNCXClientOuterMostTagName(hNcxClientHandle, "tvw");
		if (ncxConnectServer(hNcxClientHandle, "127.0.0.1", 19876, 3))
		{
			if (ncxCommunicateWithServer(hNcxClientHandle, sProtocol, nProtocolLength+1, 10) == 0)
			{
				char *sRespond = ncxGetRespondProtocol(hNcxClientHandle);
				printf("respond %s\n", sRespond);
			}
		}
		ncxDestroyNCXClient(hNcxClientHandle);
	}

	getchar();

	ncxUnInitNCXEnvironment();

	return 0;
}
