#include "TCPClientTask.h"

//////////////////////////////////////////////////////////////////////////
TCPClientTask::TCPClientTask()
: ZTask("TCPClientTask")
{
	memset(m_sServerIP, 0, MAX_IP_LENGTH);
	m_nServerPort = 0;
}

TCPClientTask::~TCPClientTask()
{
	TCPClientTask::Close();
}
//////////////////////////////////////////////////////////////////////////
BOOL TCPClientTask::Create()
{
	ZTask::Create();

	if (
		strlen(m_sServerIP) > 0 
		&& (m_nServerPort != 0)
		)
	{
		m_tcpSocket.Create();
		if (m_tcpSocket.Connect(ZSocket::ConvertAddr(m_sServerIP), m_nServerPort))
		{
			m_tcpSocket.SetTask(this);
			m_tcpSocket.RequestEvent(ZEvent::EVENT_READ);
			return TRUE;
		}
	}

	return FALSE;
}
BOOL TCPClientTask::Close()
{
	m_tcpSocket.Close();

	ZTask::Close();
	return TRUE;
}
//////////////////////////////////////////////////////////////////////////
int	TCPClientTask::Run(int nEvent)
{
	int				nTaskTime	= 0;
	UINT			nLocalEvent	= 0;

	nLocalEvent	= GetEvent(nEvent);

	ZTask::Run(nLocalEvent);

	if(nLocalEvent&TASK_KILL_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_TIMEOUT_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_READ_EVENT)
	{
		char	sData[DEFAULT_MAX_COMMUNICATE_LEN];
		int		nData	= DEFAULT_MAX_COMMUNICATE_LEN;
		int		nRead	= 0;

		if (m_tcpSocket.IsConnected())
		{
			nRead = m_tcpSocket.StreamRead(sData, nData);
			if (nRead > 0)
			{
				sData[nRead] = '\0';
				LOG_DEBUG(("[TCPClientTask::Run] %s\r\n", sData));
				m_tcpSocket.RequestEvent(ZEvent::EVENT_READ);
			}
			else if (nRead == -1)
			{
				LOG_DEBUG(("[TCPClientTask::Run] read timeout\r\n"));
				m_tcpSocket.RequestEvent(ZEvent::EVENT_READ);
			}
			else if (nRead == 0)
			{
				LOG_DEBUG(("[TCPClientTask::Run] server disconnected\r\n"));
				m_tcpSocket.Close();
			}
			else
			{
				LOG_DEBUG(("[TCPClientTask::Run] Unknown\r\n"));
				m_tcpSocket.Close();
			}
		}

		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_UPDATE_EVENT)
	{
		nTaskTime	= 0;
	}

	return nTaskTime;
}
//////////////////////////////////////////////////////////////////////////
void TCPClientTask::SetIPPort(char *sIP, int nPort)
{
	strncpy(m_sServerIP, sIP, MAX_IP_LENGTH);
	m_nServerPort = nPort;
}
void TCPClientTask::InputString(CHAR *sData)
{
	if (m_tcpSocket.IsConnected())
	{
		m_tcpSocket.Send(sData, strlen(sData));
	}
}
//////////////////////////////////////////////////////////////////////////
