#ifndef _TCPSERVERTASK_H_
#define _TCPSERVERTASK_H_

#include "TaskModel.h"

#define DEFAULT_TCP_SERVER_PORT			(34567)
#define DEFAULT_MAX_COMMUNICATE_LEN		(1024)

class TCPServerTask
	: public ZTask
	, public ZTCPListenerEvent
{
public:
	TCPServerTask();
	~TCPServerTask();
//////////////////////////////////////////////////////////////////////////
public:
	virtual	BOOL	Create();
	virtual	BOOL	Close();
//////////////////////////////////////////////////////////////////////////
public:
	virtual	BOOL	OnListenerEvent(const int hAccept,const struct sockaddr_in* pLocalAddr,const struct sockaddr_in* pRemoteAddr);
//////////////////////////////////////////////////////////////////////////
protected:
	virtual	int		Run(int nEvent = 0);
//////////////////////////////////////////////////////////////////////////
private:
	ZTCPListenerSocket		*m_pTCPListenerSocket;
	ZTCPSocket				m_tcpServerSocket;
};

#endif //_TCPSERVERTASK_H_
//////////////////////////////////////////////////////////////////////////
