//////////////////////////////////////////////////////////////////////////

#include "TaskModel.h"
#include "TCPClientTask.h"
#include "TCPServerTask.h"
#include <stdio.h>

int main()
{
	static	ZLog log;
	InitTaskModel();

	{
		TCPServerTask	tcpServerTask;
		tcpServerTask.Create();
		TCPClientTask	tcpClientTask;
		tcpClientTask.SetIPPort("127.0.0.1", DEFAULT_TCP_SERVER_PORT);
		tcpClientTask.Create();

		char sInput[DEFAULT_MAX_COMMUNICATE_LEN];
		while (1)
		{
			gets(sInput);
			if (strlen(sInput)==1 && sInput[0]== 'q')
			{
				break;
			}
			else if (strlen(sInput)==2 && strcmp(sInput, "KC")==0)
			{
				tcpClientTask.Close();
			}
			else if (strlen(sInput)==2 && strcmp(sInput, "SC")==0)
			{
				tcpClientTask.Create();
			}
			else if (strlen(sInput)==2 && strcmp(sInput, "KS")==0)
			{
				tcpServerTask.Close();
			}
			else if (strlen(sInput)==2 && strcmp(sInput, "SS")==0)
			{
				tcpServerTask.Create();
				tcpClientTask.Close();
				tcpClientTask.Create();
			}

			tcpClientTask.InputString(sInput);
		}

		tcpClientTask.Close();
		tcpServerTask.Close();
	}

	UninitTaskModel();
	return 0;
}

//////////////////////////////////////////////////////////////////////////
