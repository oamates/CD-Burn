#include "TCPServerTask.h"

//////////////////////////////////////////////////////////////////////////
TCPServerTask::TCPServerTask()
: ZTask("TCPServerTask")
, ZTCPListenerEvent()
{
	m_pTCPListenerSocket = NULL;
}

TCPServerTask::~TCPServerTask()
{
	TCPServerTask::Close();
}
//////////////////////////////////////////////////////////////////////////
BOOL TCPServerTask::Create()
{
	ZTask::Create();

	SAFE_DELETE(m_pTCPListenerSocket);
	m_pTCPListenerSocket = NEW ZTCPListenerSocket;

	if (m_pTCPListenerSocket->Create(0, DEFAULT_TCP_SERVER_PORT))
	{
		m_pTCPListenerSocket->SetListenerEvent(this);
		return TRUE;
	}

	return FALSE;
}
BOOL TCPServerTask::Close()
{
	m_tcpServerSocket.Close();
	m_tcpServerSocket.StreamClose();

	if (m_pTCPListenerSocket != NULL)
	{
		m_pTCPListenerSocket->Close();
		SAFE_DELETE(m_pTCPListenerSocket);
	}

	ZTask::Close();
	return TRUE;
}
//////////////////////////////////////////////////////////////////////////
BOOL TCPServerTask::OnListenerEvent(const int hAccept,const struct sockaddr_in* pLocalAddr,const struct sockaddr_in* pRemoteAddr)
{
	if (!m_tcpServerSocket.IsConnected())
	{
		m_tcpServerSocket.Attach(hAccept, pRemoteAddr);
		m_tcpServerSocket.StreamCreate();
		m_tcpServerSocket.SetRecvBufferSize(DEFAULT_TCP_RECV_BUFFER_SIZE);
		m_tcpServerSocket.SetNonBlocking();
		m_tcpServerSocket.SetTask(this);
		m_tcpServerSocket.RequestEvent(ZEvent::EVENT_READ);
		return TRUE;
	}
	else
	{
		char szBusy[100];
		sprintf(szBusy, "Is Busy!\n");
		ZTCPSocket::TCPSend(hAccept, szBusy, strlen(szBusy));
		return FALSE;
	}
}
//////////////////////////////////////////////////////////////////////////
int	TCPServerTask::Run(int nEvent)
{
	int				nTaskTime	= 0;
	UINT			nLocalEvent	= 0;

	nLocalEvent	= GetEvent(nEvent);

	ZTask::Run(nLocalEvent);

	if(nLocalEvent&TASK_KILL_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_TIMEOUT_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_READ_EVENT)
	{
		char	sData[DEFAULT_MAX_COMMUNICATE_LEN];
		int		nData	= DEFAULT_MAX_COMMUNICATE_LEN;
		int		nRead	= 0;

		char	sWriteData[DEFAULT_MAX_COMMUNICATE_LEN];
		int		nWriteData	= DEFAULT_MAX_COMMUNICATE_LEN;

		if (m_tcpServerSocket.IsConnected())
		{
			nRead = m_tcpServerSocket.StreamRead(sData, nData);
			if (nRead > 0)
			{
				sData[nRead] = '\0';
				LOG_DEBUG(("[TCPServerTask::Run] c->s %s\r\n", sData));
				m_tcpServerSocket.RequestEvent(ZEvent::EVENT_READ);

				sprintf(sWriteData, "s->c %s", sData);
				m_tcpServerSocket.StreamWrite(sWriteData, strlen(sWriteData));
			}
			else if (nRead == -1)
			{
				LOG_DEBUG(("[TCPServerTask::Run] read timeout\r\n"));
				m_tcpServerSocket.RequestEvent(ZEvent::EVENT_READ);
			}
			else if (nRead == 0)
			{
				LOG_DEBUG(("[TCPServerTask::Run] client disconnected\r\n"));
				m_tcpServerSocket.Close();
			}
			else
			{
				LOG_DEBUG(("[TCPServerTask::Run] Unknown\r\n"));
			}

		}

		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_UPDATE_EVENT)
	{
		nTaskTime	= 0;
	}

	return nTaskTime;
}
//////////////////////////////////////////////////////////////////////////
