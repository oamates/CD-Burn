//////////////////////////////////////////////////////////////////////////
#include "TaskModel.h"

int main()
{
	static	ZLog log;
	InitTaskModel();

	{
#ifdef WIN32
		LOG_SET_PATH("D:\\Task\\log");
#else
		LOG_SET_PATH("/home/Task/log");
#endif

		LOG_SET_LEVEL(ZLog::LOG_ERROR);
		LOG_ERROR(("[main] Level = LOG_ERROR, info = LOG_ERROR\r\n"));
		LOG_WARNING(("[main] Level = LOG_ERROR, info = LOG_WARNING\r\n"));
		LOG_INFO(("[main] Level = LOG_ERROR, info = LOG_INFO\r\n"));
		LOG_DEBUG(("[main] Level = LOG_ERROR, info = LOG_DEBUG\r\n"));

		LOG_SET_LEVEL(ZLog::LOG_WARNING);
		LOG_ERROR(("[main] Level = LOG_WARNING, info = LOG_ERROR\r\n"));
		LOG_WARNING(("[main] Level = LOG_WARNING, info = LOG_WARNING\r\n"));
		LOG_INFO(("[main] Level = LOG_WARNING, info = LOG_INFO\r\n"));
		LOG_DEBUG(("[main] Level = LOG_WARNING, info = LOG_DEBUG\r\n"));

		LOG_SET_LEVEL(ZLog::LOG_INFORMATION);
		LOG_ERROR(("[main] Level = LOG_INFORMATION, info = LOG_ERROR\r\n"));
		LOG_WARNING(("[main] Level = LOG_INFORMATION, info = LOG_WARNING\r\n"));
		LOG_INFO(("[main] Level = LOG_INFORMATION, info = LOG_INFO\r\n"));
		LOG_DEBUG(("[main] Level = LOG_INFORMATION, info = LOG_DEBUG\r\n"));

		LOG_SET_LEVEL(ZLog::LOG_DEBUG);
		LOG_ERROR(("[main] Level = LOG_DEBUG, info = LOG_ERROR\r\n"));
		LOG_WARNING(("[main] Level = LOG_DEBUG, info = LOG_WARNING\r\n"));
		LOG_INFO(("[main] Level = LOG_DEBUG, info = LOG_INFO\r\n"));
		LOG_DEBUG(("[main] Level = LOG_DEBUG, info = LOG_DEBUG\r\n"));
	}

	UninitTaskModel();
	return 0;
}

//////////////////////////////////////////////////////////////////////////
