#include "MyTimeoutTask.h"

#define DEFAULT_MYTASK_TIMEOUT	(10*1000)
//////////////////////////////////////////////////////////////////////////
MyTimeoutTask::MyTimeoutTask()
: ZTimeoutTask("MyTimeoutTask")
{
	m_cCurCharacter = ' ';
	m_bIsTimeout = FALSE;
}
MyTimeoutTask::~MyTimeoutTask()
{
	MyTimeoutTask::Close();
}
//////////////////////////////////////////////////////////////////////////
BOOL MyTimeoutTask::Create()
{
	ZTimeoutTask::Create();
	ZTimeoutTask::SetTimeout(DEFAULT_MYTASK_TIMEOUT);
	return TRUE;
}
BOOL MyTimeoutTask::Close()
{
	ZTimeoutTask::Close();
	return TRUE;
}
//////////////////////////////////////////////////////////////////////////
int	MyTimeoutTask::Run(int nEvent)
{
	int				nTaskTime	= 0;
	UINT			nLocalEvent	= 0;

	nLocalEvent	= GetEvent(nEvent);

	ZTimeoutTask::Run(nLocalEvent);

	if(nLocalEvent&TASK_KILL_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_TIMEOUT_EVENT)
	{
		m_bIsTimeout = TRUE;
		LOG_DEBUG(("[MyTimeoutTask::Run] time out\r\n"));
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_READ_EVENT)
	{
		LOG_DEBUG(("[MyTimeoutTask::Run] read char [%c]\r\n", m_cCurCharacter));
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_UPDATE_EVENT)
	{
		nTaskTime	= 0;
	}

	return nTaskTime;
}
//////////////////////////////////////////////////////////////////////////
int MyTimeoutTask::ReadChar(char cRead)
{
	m_cCurCharacter = cRead;
	ZTask::AddEvent(TASK_READ_EVENT);
	ZTimeoutTask::RefreshTimeout();
	return 0;
}

BOOL MyTimeoutTask::IsTimeout()
{
	return m_bIsTimeout;
}
//////////////////////////////////////////////////////////////////////////
