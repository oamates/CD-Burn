#ifndef _USEARRAY_H_
#define _USEARRAY_H_

#include "TaskModel.h"

class MyData
{
public:
	void SetValue(int nValue);
	int GetValue();
public:
	MyData();
	~MyData();
private:
	int		m_nValue;
};

typedef ZOSArray<MyData*>	MyDataArray;	

class UseArray
{
public:
	int AddMyData(MyData *pMyData);
	bool FindMyData(MyData *pMyData);
	int RemoveMyData(MyData *pMyData);
	void PrintAllData();

	void Test();
public:
	UseArray();
	~UseArray();
private:
	MyDataArray		m_MyDataArray;
};

#endif //_USEARRAY_H_
