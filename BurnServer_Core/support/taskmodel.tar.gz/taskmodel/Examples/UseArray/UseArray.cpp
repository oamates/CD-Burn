#include "UseArray.h"

MyData::MyData()
{
	m_nValue = 0;
}

MyData::~MyData()
{
	//
}

void MyData::SetValue(int nValue)
{
	m_nValue = nValue;
}

int MyData::GetValue()
{
	return m_nValue;
}
//////////////////////////////////////////////////////////////////////////

#define MYDATA_ARRAY_INIT_SIZE	8

UseArray::UseArray()
: m_MyDataArray(MYDATA_ARRAY_INIT_SIZE)
{
	//
}

UseArray::~UseArray()
{
	//
}

int UseArray::AddMyData(MyData *pMyData)
{
	if (FindMyData(pMyData))
	{
		return 1;
	}
	else
	{
		m_MyDataArray.Add(pMyData);
		return 0;
	}
}

bool UseArray::FindMyData(MyData *pMyData)
{
	int i = 0;

	for (i = 0; i < m_MyDataArray.Count(); i ++)
	{
		if (m_MyDataArray[i] == pMyData)
		{
			return true;
		}
	}

	return false;
}

int UseArray::RemoveMyData(MyData *pMyData)
{
	int i = 0;
	int nReturn = -1;

	for (i = 0; i < m_MyDataArray.Count(); i ++)
	{
		if (m_MyDataArray[i] == pMyData)
		{
			m_MyDataArray.Remove(i);
			nReturn = 0;
			break;
		}
	}

	return nReturn;
}

void UseArray::PrintAllData()
{
	int i = 0;

	LOG_INFO(("[UseArray::PrintAllData] current state:\r\n"))
	for (i = 0; i < m_MyDataArray.Count(); i ++)
	{
		if (m_MyDataArray[i] != NULL)
		{
			LOG_INFO(("[UseArray::PrintAllData] data value %d\r\n", m_MyDataArray[i]->GetValue()));
		}
	}
	LOG_INFO(("\r\n"));
	LOG_INFO(("\r\n"));
}

void UseArray::Test()
{
	MyData *pData_0 = NEW MyData;
	MyData *pData_1 = NEW MyData;
	MyData *pData_2 = NEW MyData;

	pData_0->SetValue(100);
	pData_1->SetValue(101);
	pData_2->SetValue(102);

	AddMyData(pData_0);
	AddMyData(pData_1);
	AddMyData(pData_2);

	PrintAllData();

	RemoveMyData(pData_1);
	PrintAllData();
	RemoveMyData(pData_2);
	PrintAllData();
	RemoveMyData(pData_0);
	PrintAllData();

	SAFE_DELETE(pData_0);
	SAFE_DELETE(pData_1);
	SAFE_DELETE(pData_2);
}
