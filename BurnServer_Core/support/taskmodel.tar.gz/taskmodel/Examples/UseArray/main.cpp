#include "TaskModel.h"
#include "UseArray.h"

int main()
{
	static	ZLog log;
	InitTaskModel();

	LOG_SET_LEVEL(ZLog::LOG_DEBUG);

	{
		UseArray	useArray;
		useArray.Test();
	}

	UninitTaskModel();

	return 0;
}
