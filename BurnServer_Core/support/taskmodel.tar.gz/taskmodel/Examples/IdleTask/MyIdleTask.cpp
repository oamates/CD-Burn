#include "MyIdleTask.h"

#define DEFAULT_MYIDLE_TIME (3*1000)
//////////////////////////////////////////////////////////////////////////
MyIdleTask::MyIdleTask()
: ZIdleTask("MyIdleTask")
{
	//
}
MyIdleTask::~MyIdleTask()
{
	//
}
//////////////////////////////////////////////////////////////////////////
BOOL MyIdleTask::Create()
{
	ZIdleTask::Create();

	ZIdleTask::AddIdleTask(DEFAULT_MYIDLE_TIME);

	return TRUE;
}
BOOL MyIdleTask::Close()
{
	ZIdleTask::Close();
	return TRUE;
}
//////////////////////////////////////////////////////////////////////////
int	MyIdleTask::Run(int nEvent)
{
	int				nTaskTime	= 0;
	UINT			nLocalEvent	= 0;

	nLocalEvent	= GetEvent(nEvent);

	ZIdleTask::Run(nLocalEvent);

	if(nLocalEvent&TASK_KILL_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_TIMEOUT_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_READ_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_UPDATE_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_IDLE_EVENT)
	{
		LOG_DEBUG(("[MyIdleTask::Run] TASK_IDLE_EVENT\r\n"));
		ZIdleTask::AddIdleTask(DEFAULT_MYIDLE_TIME);
		nTaskTime	= 0;
	}

	return nTaskTime;
}
//////////////////////////////////////////////////////////////////////////
