#ifndef _XMLOPERATOR_H_
#define _XMLOPERATOR_H_

#include "TaskModel.h"

class XMLOperator : public ZXMLParser
{
public:
	XMLOperator();
	virtual ~XMLOperator();
public:
	BOOL	Open(const char * sFullPath);
	BOOL	Save(const char * sWritePath);
	virtual char * OnElementParse(char *p, ZXMLNode *pNode);
};

#endif //_XMLOPERATOR_H_
