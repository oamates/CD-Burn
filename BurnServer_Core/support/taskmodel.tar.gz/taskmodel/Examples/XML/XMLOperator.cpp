#include "XMLOperator.h"

XMLOperator::XMLOperator()
{
	//
}

XMLOperator::~XMLOperator()
{
	//
}

BOOL XMLOperator::Open(const char * sFullPath)
{
	return ZXMLParser::ReadFile(sFullPath);
}

char * XMLOperator::OnElementParse(char *p, ZXMLNode *pNode)
{
	ZXMLElement*	pParentElement = (ZXMLElement*)pNode;
	ZXMLElement		element(0);

	p = element.Parse(p, this);
	if (
		(pParentElement != NULL)
		&& (element.GetName() != NULL)
		&& (element.GetValue() != NULL)
		)
	{
		if(strcasecmp(pParentElement->GetName(),"SERVER")==0)
		{
			if(strcasecmp(element.GetName(),"LOGLEVEL")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] LOGLEVEL %d\r\n", atoi(element.GetValue())));
			}
			if(strcasecmp(element.GetName(),"LOGPATH")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] LOGPATH %s\r\n", element.GetValue()));
			}
		}
		if(strcasecmp(pParentElement->GetName(),"ADMIN")==0)
		{
			if(strcasecmp(element.GetName(),"ADDRESS")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] ADDRESS %s\r\n", element.GetValue()));
			}
			if(strcasecmp(element.GetName(),"PORT")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] PORT %d\r\n", atoi(element.GetValue())));
			}
		}
		if(strcasecmp(pParentElement->GetName(),"PROTOCOL")==0)
		{
			if(strcasecmp(element.GetName(),"NAME")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] NAME %s\r\n", element.GetValue()));
			}
			if(strcasecmp(element.GetName(),"ADDRESS")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] ADDRESS %d\r\n", atoi(element.GetValue())));
			}
			if(strcasecmp(element.GetName(),"PORT")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] PORT %d\r\n", atoi(element.GetValue())));
			}
			if(strcasecmp(element.GetName(),"RECVFREQ")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] RECVFREQ %d\r\n", atoi(element.GetValue())));
			}
			if(strcasecmp(element.GetName(),"RECVCOUNT")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] RECVCOUNT %d\r\n", atoi(element.GetValue())));
			}
			if(strcasecmp(element.GetName(),"SENDFREQ")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] SENDFREQ %d\r\n", atoi(element.GetValue())));
			}
			if(strcasecmp(element.GetName(),"SENDCOUNT")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] SENDCOUNT %d\r\n", atoi(element.GetValue())));
			}
			if(strcasecmp(element.GetName(),"UDPPAIRCOUNT")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] UDPPAIRCOUNT %d\r\n", atoi(element.GetValue())));
			}
			if(strcasecmp(element.GetName(),"PACKETINTERVAL")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] PACKETINTERVAL %d\r\n", atoi(element.GetValue())));
			}
			if(strcasecmp(element.GetName(),"FILTERPACKETSIZE")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] FILTERPACKETSIZE %d\r\n", atoi(element.GetValue())));
			}
		}
		if(strcasecmp(pParentElement->GetName(),"CHANNEL")==0)
		{
			if (strcasecmp(element.GetName(),"MULTIADDR")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] MULTIADDR %s\r\n", element.GetValue()));
			}
			if (strcasecmp(element.GetName(),"MULTIPORT")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] MULTIPORT %d\r\n", atoi(element.GetValue())));
			}
			if (strcasecmp(element.GetName(),"MULTIRECVWAITMILLISECOND")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] MULTIRECVWAITMILLISECOND %d\r\n", atoi(element.GetValue())));
			}
		}
		if(strcasecmp(pParentElement->GetName(),"RECORDER")==0)
		{
			if(strcasecmp(element.GetName(),"SPLITTIMER")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] SPLITTIMER %d\r\n", atoi(element.GetValue())));
			}
			if (strcasecmp(element.GetName(),"SPLITSAFETHRESHOLD")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] SPLITSAFETHRESHOLD %d\r\n", atoi(element.GetValue())));
			}
		}
		if(strcasecmp(pParentElement->GetName(),"OTHER")==0)
		{
			if(strcasecmp(element.GetName(),"SMSBUSINESSIP")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] SMSBUSINESSIP %s\r\n", element.GetValue()));
			}
			if (strcasecmp(element.GetName(),"SMSBUSINESSPORT")==0)
			{
				LOG_INFO(("[XMLOperator::OnElementParse] SMSBUSINESSPORT %d\r\n", atoi(element.GetValue())));
			}
		}
	}

	return p;
}

BOOL XMLOperator::Save(const char * sWritePath)
{
	ZXMLElement*	pConfiguration;
	ZXMLElement*	pFirstLayer;
	ZXMLElement*	pSecondLayer;
	char			sTemp[1024];

	if (sWritePath != NULL)
	{
		pConfiguration	= NEW ZXMLElement("CONFIGURATION", NULL, 0);

		// SERVER
		pFirstLayer		= NEW ZXMLElement("SERVER", NULL, 2);
		sprintf(sTemp, "%d", 4);
		pSecondLayer	= NEW ZXMLElement("LOGLEVEL", sTemp, 4);
		pFirstLayer->AddChild(pSecondLayer);
		pSecondLayer	= NEW ZXMLElement("LOGPATH", "/home/sms50/log", 4);
		pFirstLayer->AddChild(pSecondLayer);
		pConfiguration->AddChild(pFirstLayer);

		m_pRootNode = pConfiguration;
		if (ZXMLParser::WriteFile(sWritePath))
		{
			return TRUE;
		}
	}


	return FALSE;
}
