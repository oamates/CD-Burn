//////////////////////////////////////////////////////////////////////////

#include "TaskModel.h"
#include "XMLOperator.h"

int main()
{
	static	ZLog log;
	InitTaskModel();

	{
		XMLOperator		xmlConfig;
#ifdef WIN32
		xmlConfig.Open("C:\\kernelconfig.xml");
		xmlConfig.Save("C:\\kernelconfigfixed.xml");
#else
		xmlConfig.Open("/home/kernelconfig.xml");
		xmlConfig.Save("/home/kernelconfigfixed.xml");
#endif
	}

	UninitTaskModel();
	return 0;
}

//////////////////////////////////////////////////////////////////////////
