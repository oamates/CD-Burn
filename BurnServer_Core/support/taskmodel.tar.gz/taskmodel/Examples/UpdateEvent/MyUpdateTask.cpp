#include "MyUpdateTask.h"

MyUpdateTask::MyUpdateTask()
: ZTask("MyUpdateTask")
{
}

MyUpdateTask::~MyUpdateTask()
{
	MyUpdateTask::Close();
}
//////////////////////////////////////////////////////////////////////////
BOOL MyUpdateTask::Create()
{
	ZTask::Create();
	ZTask::AddEvent(TASK_UPDATE_EVENT);
	return TRUE;
}
BOOL MyUpdateTask::Close()
{
	ZTask::Close();
	return TRUE;
}
//////////////////////////////////////////////////////////////////////////
int	MyUpdateTask::Run(int nEvent)
{
	int				nTaskTime	= 0;
	UINT			nLocalEvent	= 0;
    static          int nCount = 0;

	nLocalEvent	= GetEvent(nEvent);

	ZTask::Run(nLocalEvent);

	if(nLocalEvent&TASK_KILL_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_TIMEOUT_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_READ_EVENT)
	{
		nTaskTime	= 0;
	}else
	if(nLocalEvent&TASK_UPDATE_EVENT)
	{
        nCount ++;
        if (nCount % 1000 == 0)
        {
            LOG_DEBUG(("[MyUpdateTask::Run] 1000\r\n"));
        }
		//LOG_DEBUG(("[MyUpdateTask::Run] TASK_UPDATE_EVENT\r\n"));
		nTaskTime	= 4;
	}

	return nTaskTime;
}
//////////////////////////////////////////////////////////////////////////
