#include "TaskModel.h"
#include "MyUpdateTask.h"

#ifdef WIN32
#include <conio.h>
#endif

int main()
{
	static	ZLog log;
	InitTaskModel();

	LOG_SET_LEVEL(ZLog::LOG_DEBUG);

	{
		MyUpdateTask myUpdateTask;
		myUpdateTask.Create();

#ifdef _LINUX_
		// use getchar like use getch in windows
		system("stty raw");
#endif

		char cInput;
		do 
		{
#ifdef WIN32
			cInput = getch();
#else
			cInput = getchar();
#endif
		} while (cInput != 'q');

		myUpdateTask.Close();

#ifdef _LINUX_
		// use getchar like use getch in windows
		system("stty cooked");
#endif
	}

	UninitTaskModel();

	return 0;
}

//////////////////////////////////////////////////////////////////////////
