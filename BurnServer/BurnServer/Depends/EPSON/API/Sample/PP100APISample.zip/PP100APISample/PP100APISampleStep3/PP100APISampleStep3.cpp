//=============================================================================
//	Step2
//
//	FileName	:	PP100APISampleStep3.cpp
//	Contents	:	Connecting PC and enumerating PP-100 Series(PP-100, PP-100AP, and PP-100N) PP-100 Series API sample application.
//	Language	:	C++
//	Copyright	:	Copyright(C) SEIKO EPSON CORPORATION 2010. All rights reserved.
//	Note		:	
//	 1.Outline
//	  Initialize, connect to PC, enumerate PP-100 Series, disconnect from PC, destroy, and output it return value to the console.
//	 2.Process
//	 (1)Initialize PP-100 Series API. 
//		PP100_Initialize()
//	 (2)Connect to PC that TDBridge is running. 
//		PP100_ConnectServer()
//	 (3)Enumerate PP-100 Series.
//		PP100_EnumPublishers()
//	 (4)Disconnect from PC that TDBridge is running. 
//		PP100_DisconnectServer()
//	 (5)Release PP-100 Series API.
//		PP100_Destroy()
//	CommandLine	:	PP100APISampleStep3
//=============================================================================

//=============================================================================
//	include files (#include)
//=============================================================================
#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include <shfolder.h>
#include "PP100API.h"

//=============================================================================
//	global variables
//=============================================================================
// The full path of PP100API.dll.
// If you changed the installation folder of EPSON TD Bridge, you need to changed the value.
TCHAR g_pPP100APIDLL[] = _T("\\EPSON\\TDBridge\\API\\PP100API.dll");
HMODULE g_hPP100APIDLL = NULL;
PP100_INITIALIZE g_pPP100_Initialize = NULL;
PP100_DESTROY g_pPP100_Destroy = NULL;
PP100_CONNECTSERVER g_pPP100_ConnectServer = NULL;
PP100_DISCONNECTSERVER g_pPP100_DisconnectServer = NULL;
PP100_ENUMPUBLISHERS g_pPP100_EnumPublishers = NULL;

//=============================================================================
//	global functions
//=============================================================================
int LoadPP100API(); // Load PP-100 Series API and get function pointers.
void DisplayEnumPublisherInfo(PP100_ENUM_PUBLISHER_INFO pEnumPublisherInfo[] , unsigned long ulEnumPublisherInfoNum); // Display PP100_ENUM_PUBLISHER_INFO.

//=============================================================================
//	main
//
//	(1)Initialize PP-100 Series API. 
//		PP100_Initialize()
//	(2)Connect to PC that TDBridge is running. 
//		PP100_ConnectServer()
//	(3)Enumerate PP-100 Series.
//		PP100_EnumPublishers()
//	(4)Disconnect from PC that TDBridge is running. 
//		PP100_DisconnectServer()
//	(5)Release PP-100 Series API.
//		PP100_Destroy()
//	
//	IN  : argc		- Number of input parameter.
//		  argv		- Pointer to input paraemter.
//	OUT : 
//
//	Return : void
//=============================================================================
void main(int argc, char *argv[])
{
	int nRet = LoadPP100API();
	printf("LoadPP100API() returns %d\n", nRet);
	if(0 != nRet)
	{
		printf("Loading PP-100 Series API failed.\n");
		return;
	}

	//=========================================================================
	// (1)Initialize PP100 Series API.
	//=========================================================================
	nRet = g_pPP100_Initialize();
	printf("PP100_Initialize() returns %d\n", nRet);
	if(PP100API_SUCCESS != nRet)
	{
		printf("Initializing PP-100 Series API failed.\n");
		return;
	}

	//=========================================================================
	// (2)Connect to PC that TDBridge is running.
	//    This sample sets pHost : 127.0.0.1 , pOrderFolder : Orders
	//    i.e. \\127.0.0.1\Orders is full path of monitoring folder.
	//    If pHost is NULL, PP-100 Series API assume that local PC specified, and ignore pOrderFolder parameter.
	//=========================================================================
	unsigned long ulHandle = 0;
	nRet = g_pPP100_ConnectServer(L"127.0.0.1" , L"Orders" , &ulHandle);
	printf("PP100_ConnectServer() returns %d\n", nRet);
	printf("ulHandle is %u\n", ulHandle);
	if(PP100API_SUCCESS != nRet)
	{
		printf("Connecting to PC that TDBridge is running failed.\n");
		return;
	}

	//=========================================================================
	// (3)Enumerate PP-100 Series.
	//    First, call PP100_EnumPublishers() to get number of PP-100 Series.
	//    If return value is PP100API_MORE_ITEMS, PP100_EnumPublishers() succeeded.
	//    Then allocate new memory and call PP100_EnumPublishers() again.
	//=========================================================================
	PP100_ENUM_PUBLISHER_INFO* pEnumPublisherInfo = NULL;
	unsigned long ulEnumPublisherInfoNum = 0;
	nRet = g_pPP100_EnumPublishers(ulHandle , pEnumPublisherInfo , &ulEnumPublisherInfoNum);
	printf("PP100_EnumPublishers() returns %d\n", nRet);
	printf("ulEnumPublisherInfoNum is %u\n", ulEnumPublisherInfoNum);
	if(PP100API_MORE_ITEMS == nRet)
	{	
		while(PP100API_MORE_ITEMS == nRet)
		{
			pEnumPublisherInfo = new PP100_ENUM_PUBLISHER_INFO[ulEnumPublisherInfoNum];
			if(NULL == pEnumPublisherInfo)
			{
				printf("Allocating new memory failed.\n");
				break;
			}
			else
			{
				memset(pEnumPublisherInfo , 0 , sizeof(PP100_ENUM_PUBLISHER_INFO) * ulEnumPublisherInfoNum);
				nRet = g_pPP100_EnumPublishers(ulHandle , pEnumPublisherInfo , &ulEnumPublisherInfoNum);
				printf("PP100_EnumPublishers() returns %u\n", nRet);
				if(PP100API_SUCCESS == nRet)
				{
					DisplayEnumPublisherInfo(pEnumPublisherInfo , ulEnumPublisherInfoNum);
				}
				delete[] pEnumPublisherInfo;
			}
		}
	}
	else
	{
		printf("Enumerating to PC that TDBridge is running failed.\n");
		return;
	}

	//=========================================================================
	// (4)Disconnecting from PC that TDBridge is running.
	//=========================================================================
	nRet = g_pPP100_DisconnectServer(ulHandle);
	printf("PP100_DisconnectServer() returns %d\n", nRet);
	if(PP100API_SUCCESS != nRet)
	{
		printf("Disconnecting from PC that TDBridge is running failed.\n");
		return;
	}

	//=========================================================================
	// (5)Release PP100 Series API.
	//=========================================================================
	nRet = g_pPP100_Destroy();
	printf("PP100_Destroy() returns %d\n", nRet);
	if(PP100API_SUCCESS != nRet)
	{
		printf("Destroying PP-100 Series API failed.\n");
		return;
	}

	return;
}

//=============================================================================
//	LoadPP100API
//	
//	(1)Load PP-100 Series API and get function pointers.
//
//	IN  :
//	OUT :
//
//	Return :	0	- success
//				1	- failure
//=============================================================================
int LoadPP100API()
{
	// Load PP100API.dll

	TCHAR tcDLLPath[MAX_PATH];
	HRESULT hResult;
	hResult = SHGetFolderPath(NULL, CSIDL_PROGRAM_FILES, NULL, 0, tcDLLPath);
	if(S_OK != hResult)
	{
		printf("Loading PP-100 Series API failed.\n");
		return 1;
	}

	_tcscat(tcDLLPath, g_pPP100APIDLL);

	g_hPP100APIDLL = ::LoadLibrary(tcDLLPath);
	if(NULL == g_hPP100APIDLL)
	{
		printf("Loading PP-100 Series API failed.\n");
		return 1;
	}

	// Get function pointer of PP100_Initialize() and PP100_Destroy()
	g_pPP100_Initialize = (PP100_INITIALIZE)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_INITIALIZE);
	g_pPP100_Destroy = (PP100_DESTROY)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_DESTROY);
	g_pPP100_ConnectServer = (PP100_CONNECTSERVER)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_CONNECTSERVER);
	g_pPP100_DisconnectServer = (PP100_DISCONNECTSERVER)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_DISCONNECTSERVER);
	g_pPP100_EnumPublishers = (PP100_ENUMPUBLISHERS)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_ENUMPUBLISHERS);
	if(	NULL == g_pPP100_Initialize || 
		NULL == g_pPP100_Destroy || 
		NULL == g_pPP100_ConnectServer || 
		NULL == g_pPP100_DisconnectServer || 
		NULL == g_pPP100_EnumPublishers)
	{
		printf("Getting function address failed.\n");
		return 1;
	}

	return 0;
}

//=============================================================================
//	DisplayEnumPublisherInfo
//	
//	(1)Display PP100_ENUM_PUBLISHER_INFO.
//
//	IN  : pEnumPublisherInfo		- Pointer to PP100_ENUM_PUBLISHER_INFO array.
//		  ulEnumPublisherInfoNum	- Number of array.
//	OUT : 
//
//	Return : void
//=============================================================================
void DisplayEnumPublisherInfo(PP100_ENUM_PUBLISHER_INFO pEnumPublisherInfo[] , unsigned long ulEnumPublisherInfoNum)
{
	for(unsigned long ul = 0;ul < ulEnumPublisherInfoNum;ul++)
	{
		wprintf(L"pEnumPublisherInfo[%u].pPublisherName is %s\n" , ul , pEnumPublisherInfo[ul].pPublisherName);
		wprintf(L"pEnumPublisherInfo[%u].ulDriveNumber is %u\n" , ul , pEnumPublisherInfo[ul].ulDriveNumber);
		wprintf(L"pEnumPublisherInfo[%u].ulConnectType is %u\n" , ul , pEnumPublisherInfo[ul].ulConnectType);
	}
}