#pragma once

#include <windows.h>
#include <tchar.h>
#include "PP100API.h"

enum PP100API_ID
{
	ID_PP100_INITIALIZE = 0 , 
	ID_PP100_DESTROY , 
	ID_PP100_CONNECTSERVER , 
	ID_PP100_DISCONNECTSERVER , 
	ID_PP100_ENUMPUBLISHERS , 
	ID_PP100_GETPUBLISHERSTATUS , 
	ID_PP100_GETJOBSTATUS , 
	ID_PP100_CREATEJOB , 
	ID_PP100_GETCREATEDJOBLIST , 
	ID_PP100_COPYJOB , 
	ID_PP100_DELETEJOB ,
	ID_PP100_SUBMITJOB , 
	ID_PP100_CANCELJOB , 
	ID_PP100_SETPUBLISHER , 
	ID_PP100_GETPUBLISHER , 
	ID_PP100_SETCOPIES , 
	ID_PP100_GETCOPIES , 
	ID_PP100_SETOUTSTACKER , 
	ID_PP100_GETOUTSTACKER , 
	ID_PP100_SETINSTACKER , 
	ID_PP100_GETINSTACKER , 
	ID_PP100_SETDISCTYPE , 
	ID_PP100_GETDISCTYPE , 
	ID_PP100_SETWRITINGSPEED , 
	ID_PP100_GETWRITINGSPEED , 
	ID_PP100_SETCOMPARE , 
	ID_PP100_GETCOMPARE , 
	ID_PP100_SETCLOSEDISC , 
	ID_PP100_GETCLOSEDISC , 
	ID_PP100_SETFORMAT , 
	ID_PP100_GETFORMAT , 
	ID_PP100_SETDATA , 
	ID_PP100_ADDDATA , 
	ID_PP100_DELETEDATA , 
	ID_PP100_GETDATA , 
	ID_PP100_SETVOLUMELABEL , 
	ID_PP100_GETVOLUMELABEL , 
	ID_PP100_SETVIDEO , 
	ID_PP100_GETVIDEO , 
	ID_PP100_SETVIDEOTITLE , 
	ID_PP100_GETVIDEOTITLE , 
	ID_PP100_SETIMAGE , 
	ID_PP100_GETIMAGE , 
	ID_PP100_SETAUDIOTRACK , 
	ID_PP100_ADDAUDIOTRACK , 
	ID_PP100_DELETEAUDIOTRACK , 
	ID_PP100_GETAUDIOTRACK , 
	ID_PP100_SETAUDIOTITLE , 
	ID_PP100_GETAUDIOTITLE , 
	ID_PP100_SETAUDIOCATALOGCODE , 
	ID_PP100_GETAUDIOCATALOGCODE , 
	ID_PP100_SETAUDIOPERFORMER , 
	ID_PP100_GETAUDIOPERFORMER , 
	ID_PP100_SETLABEL , 
	ID_PP100_GETLABEL , 
	ID_PP100_SETLABELTYPE , 
	ID_PP100_GETLABELTYPE , 
	ID_PP100_SETREPLACEFIELDTEXT , 
	ID_PP100_ADDREPLACEFIELDTEXT , 
	ID_PP100_DELETEREPLACEFIELDTEXT , 
	ID_PP100_GETREPLACEFIELDTEXT , 
	ID_PP100_SETREPLACEFIELDBINARY , 
	ID_PP100_ADDREPLACEFIELDBINARY , 
	ID_PP100_DELETEREPLACEFIELDBINARY , 
	ID_PP100_GETREPLACEFIELDBINARY , 
	ID_PP100_SETLABELAREA , 
	ID_PP100_GETLABELAREA , 
	ID_PP100_SETPRINTMODE , 
	ID_PP100_GETPRINTMODE ,
	ID_PP100_SETPLUGINID , 
	ID_PP100_GETPLUGINID , 
	ID_PP100_SETPLUGINPARAMETER , 
	ID_PP100_GETPLUGINPARAMETER , 
	ID_PP100_SETPRIORITY , 
	ID_PP100_GETPRIORITY ,
	ID_PP100_SETMEASURE , 
	ID_PP100_GETMEASURE ,
	ID_PP100_SETARCHIVEDISCONLY , 
	ID_PP100_GETARCHIVEDISCONLY ,
	ID_PP100_CONVERTERRORCODETOSTRING , 
	ID_PP100_CONVERTINFORMATIONCODETOSTRING ,
	NUM_PP100_API
};

// API Name   correspond to PP100API_ID
const char pFunctionName[NUM_PP100_API][65] = 
{
	FNSTR_PP100_INITIALIZE ,
	FNSTR_PP100_DESTROY , 
	FNSTR_PP100_CONNECTSERVER , 
	FNSTR_PP100_DISCONNECTSERVER , 
	FNSTR_PP100_ENUMPUBLISHERS , 
	FNSTR_PP100_GETPUBLISHERSTATUS , 
	FNSTR_PP100_GETJOBSTATUS , 
	FNSTR_PP100_CREATEJOB , 
	FNSTR_PP100_GETCREATEDJOBLIST ,
	FNSTR_PP100_COPYJOB ,
	FNSTR_PP100_DELETEJOB ,
	FNSTR_PP100_SUBMITJOB , 
	FNSTR_PP100_CANCELJOB , 
	FNSTR_PP100_SETPUBLISHER , 
	FNSTR_PP100_GETPUBLISHER , 
	FNSTR_PP100_SETCOPIES , 
	FNSTR_PP100_GETCOPIES , 
	FNSTR_PP100_SETOUTSTACKER , 
	FNSTR_PP100_GETOUTSTACKER , 
	FNSTR_PP100_SETINSTACKER , 
	FNSTR_PP100_GETINSTACKER , 
	FNSTR_PP100_SETDISCTYPE , 
	FNSTR_PP100_GETDISCTYPE , 
	FNSTR_PP100_SETWRITINGSPEED , 
	FNSTR_PP100_GETWRITINGSPEED , 
	FNSTR_PP100_SETCOMPARE , 
	FNSTR_PP100_GETCOMPARE , 
	FNSTR_PP100_SETCLOSEDISC , 
	FNSTR_PP100_GETCLOSEDISC , 
	FNSTR_PP100_SETFORMAT , 
	FNSTR_PP100_GETFORMAT , 
	FNSTR_PP100_SETDATA , 
	FNSTR_PP100_ADDDATA , 
	FNSTR_PP100_DELETEDATA , 
	FNSTR_PP100_GETDATA , 
	FNSTR_PP100_SETVOLUMELABEL , 
	FNSTR_PP100_GETVOLUMELABEL , 
	FNSTR_PP100_SETVIDEO , 
	FNSTR_PP100_GETVIDEO , 
	FNSTR_PP100_SETVIDEOTITLE , 
	FNSTR_PP100_GETVIDEOTITLE , 
	FNSTR_PP100_SETIMAGE , 
	FNSTR_PP100_GETIMAGE , 
	FNSTR_PP100_SETAUDIOTRACK , 
	FNSTR_PP100_ADDAUDIOTRACK , 
	FNSTR_PP100_DELETEAUDIOTRACK , 
	FNSTR_PP100_GETAUDIOTRACK , 
	FNSTR_PP100_SETAUDIOTITLE , 
	FNSTR_PP100_GETAUDIOTITLE , 
	FNSTR_PP100_SETAUDIOCATALOGCODE , 
	FNSTR_PP100_GETAUDIOCATALOGCODE , 
	FNSTR_PP100_SETAUDIOPERFORMER , 
	FNSTR_PP100_GETAUDIOPERFORMER , 
	FNSTR_PP100_SETLABEL , 
	FNSTR_PP100_GETLABEL , 
	FNSTR_PP100_SETLABELTYPE , 
	FNSTR_PP100_GETLABELTYPE , 
	FNSTR_PP100_SETREPLACEFIELDTEXT , 
	FNSTR_PP100_ADDREPLACEFIELDTEXT , 
	FNSTR_PP100_DELETEREPLACEFIELDTEXT , 
	FNSTR_PP100_GETREPLACEFIELDTEXT , 
	FNSTR_PP100_SETREPLACEFIELDBINARY , 
	FNSTR_PP100_ADDREPLACEFIELDBINARY , 
	FNSTR_PP100_DELETEREPLACEFIELDBINARY , 
	FNSTR_PP100_GETREPLACEFIELDBINARY , 
	FNSTR_PP100_SETLABELAREA , 
	FNSTR_PP100_GETLABELAREA , 
	FNSTR_PP100_SETPRINTMODE , 
	FNSTR_PP100_GETPRINTMODE ,
	FNSTR_PP100_SETPLUGINID , 
	FNSTR_PP100_GETPLUGINID , 
	FNSTR_PP100_SETPLUGINPARAMETER , 
	FNSTR_PP100_GETPLUGINPARAMETER , 
	FNSTR_PP100_SETPRIORITY ,
	FNSTR_PP100_GETPRIORITY ,
	FNSTR_PP100_SETMEASURE ,
	FNSTR_PP100_GETMEASURE ,
	FNSTR_PP100_SETARCHIVEDISCONLY ,
	FNSTR_PP100_GETARCHIVEDISCONLY ,
	FNSTR_PP100_CONVERTERRORCODETOSTRING , 
	FNSTR_PP100_CONVERTINFORMATIONCODETOSTRING ,
};

/** @brief This class is wrapper of PP100API.dll
 * This class contains all function which PP100API.dll exports.
 */
class CPP100APIManager
{
public:
	CPP100APIManager(void);
	~CPP100APIManager(void);

	long PP100_Initialize(void);
	long PP100_Destroy(void);
	long PP100_ConnectServer(wchar_t pHost[64] , wchar_t pOrderFolder[256] , unsigned long* pHandle);
	long PP100_DisconnectServer(unsigned long ulHandle);
	long PP100_EnumPublishers(unsigned long ulHandle , PP100_ENUM_PUBLISHER_INFO pEnumPublisherInfo[] , unsigned long* pEnumPublisherInfoNum);
	long PP100_GetPublisherStatus(unsigned long ulHandle , wchar_t pPublisherName[65] , LPPP100_PUBLISHER_STATUS pPublisherStatus);
	long PP100_GetJobStatus(unsigned long ulHandle , wchar_t pJobID[41] , PP100_JOB_STATUS pJobStatus[] , unsigned long* pJobStatusNum);
	long PP100_CreateJob(wchar_t pJobID[41]);
	long PP100_GetCreatedJobList(wchar_t** pJobID , unsigned long* pJobIdNum);
	long PP100_CopyJob(wchar_t pSourceJobID[41] , wchar_t pDestinationJobID[41]);
	long PP100_DeleteJob(wchar_t pJobID[41]);
	long PP100_SubmitJob(unsigned long ulHandle , wchar_t pJobID[41] , bool bAutoDelete);
	long PP100_CancelJob(unsigned long ulHandle , wchar_t pJobID[41]);
	long PP100_SetPublisher(wchar_t pJobID[41] , wchar_t pPublisher[65]);
	long PP100_GetPublisher(wchar_t pJobID[41] , wchar_t pPublisher[65]);
	long PP100_SetCopies(wchar_t pJobID[41] , unsigned long ulNumber);
	long PP100_GetCopies(wchar_t pJobID[41] , unsigned long* pNumber);
	long PP100_SetOutStacker(wchar_t pJobID[41] , unsigned long ulOutStacker);
	long PP100_GetOutStacker(wchar_t pJobID[41] , unsigned long* pOutStacker);
	long PP100_SetInStacker(wchar_t pJobID[41] , unsigned long ulInStacker);
	long PP100_GetInStacker(wchar_t pJobID[41] , unsigned long* pInStacker);
	long PP100_SetDiscType(wchar_t pJobID[41] , unsigned long ulDiscType);
	long PP100_GetDiscType(wchar_t pJobID[41] , unsigned long* pDiscType);
	long PP100_SetWritingSpeed(wchar_t pJobID[41] , float fWritingSpeed);
	long PP100_GetWritingSpeed(wchar_t pJobID[41] , float* pWritingSpeed);
	long PP100_SetCompare(wchar_t pJobID[41] , unsigned long ulCompare);
	long PP100_GetCompare(wchar_t pJobID[41] , unsigned long* pCompare);
	long PP100_SetCloseDisc(wchar_t pJobID[41] , unsigned long ulCloseDisc);
	long PP100_GetCloseDisc(wchar_t pJobID[41] , unsigned long* pCloseDisc);
	long PP100_SetFormat(wchar_t pJobID[41] , unsigned long ulWritingFormat);
	long PP100_GetFormat(wchar_t pJobID[41] , unsigned long* pWritingFormat);
	long PP100_SetData(wchar_t pJobID[41] , PP100_WRITE_DATA pWriteData[] , unsigned long ulWriteDataNum);
	long PP100_AddData(wchar_t pJobID[41] , PP100_WRITE_DATA pWriteData[] , unsigned long ulWriteDataNum);
	long PP100_DeleteData(wchar_t pJobID[41] , PP100_WRITE_DATA pWriteData[] , unsigned long ulWriteDataNum);
	long PP100_GetData(wchar_t pJobID[41] , PP100_WRITE_DATA pWriteData[] , unsigned long* pWriteDataNum);
	long PP100_SetVolumeLabel(wchar_t pJobID[41] , wchar_t pVolumeLabel[63]);
	long PP100_GetVolumeLabel(wchar_t pJobID[41] , wchar_t pVolumeLabel[63]);
	long PP100_SetVideo(wchar_t pJobID[41] , wchar_t pVideoPath[256]);
	long PP100_GetVideo(wchar_t pJobID[41] , wchar_t pVideoPath[256]);
	long PP100_SetVideoTitle(wchar_t pJobID[41] , wchar_t pVideoTitle[33]);
	long PP100_GetVideoTitle(wchar_t pJobID[41] , wchar_t pVideoTitle[33]);
	long PP100_SetImage(wchar_t pJobID[41] , wchar_t pImage[256]);
	long PP100_GetImage(wchar_t pJobID[41] , wchar_t pImage[256]);
	long PP100_SetAudioTrack(wchar_t pJobID[41] , PP100_AUDIO_TRACK pAudioTrack[] , unsigned long ulAudioTrackNum);
	long PP100_AddAudioTrack(wchar_t pJobID[41] , PP100_AUDIO_TRACK pAudioTrack[] , unsigned long ulAudioTrackNum);
	long PP100_DeleteAudioTrack(wchar_t pJobID[41] , PP100_AUDIO_TRACK pAudioTrack[] , unsigned long ulAudioTrackNum);
	long PP100_GetAudioTrack(wchar_t pJobID[41] , PP100_AUDIO_TRACK pAudioTrack[] , unsigned long* pAudioTrackNum);
	long PP100_SetAudioTitle(wchar_t pJobID[41] , wchar_t pAudioTitle[129]);
	long PP100_GetAudioTitle(wchar_t pJobID[41] , wchar_t pAudioTitle[129]);
	long PP100_SetAudioCatalogCode(wchar_t pJobID[41] , wchar_t pAudioCatalogCode[14]);
	long PP100_GetAudioCatalogCode(wchar_t pJobID[41] , wchar_t pAudioCatalogCode[14]);
	long PP100_SetAudioPerformer(wchar_t pJobID[41] , wchar_t pAudioPerformer[129]);
	long PP100_GetAudioPerformer(wchar_t pJobID[41] , wchar_t pAudioPerformer[129]);
	long PP100_SetLabel(wchar_t pJobID[41] , wchar_t pLabel[256]);
	long PP100_GetLabel(wchar_t pJobID[41] , wchar_t pLabel[256]);
	long PP100_SetLabelType(wchar_t pJobID[41] , unsigned long ulLabelType);
	long PP100_GetLabelType(wchar_t pJobID[41] , unsigned long* pLabelType);
	long PP100_SetReplaceFieldText(wchar_t pJobID[41] , PP100_REPLACE_FIELD_TEXT pReplaceFieldText[] , unsigned long ulReplaceFieldTextNum);
	long PP100_AddReplaceFieldText(wchar_t pJobID[41] , PP100_REPLACE_FIELD_TEXT pReplaceFieldText[] , unsigned long ulReplaceFieldTextNum);
	long PP100_DeleteReplaceFieldText(wchar_t pJobID[41] , PP100_REPLACE_FIELD_TEXT pReplaceFieldText[] , unsigned long ulReplaceFieldTextNum);
	long PP100_GetReplaceFieldText(wchar_t pJobID[41] , PP100_REPLACE_FIELD_TEXT pReplaceFieldText[] , unsigned long* pReplaceFieldTextNum);
	long PP100_SetReplaceFieldBinary(wchar_t pJobID[41] , PP100_REPLACE_FIELD_BINARY pReplaceFieldBinary[] , unsigned long ulReplaceFieldBinaryNum);
	long PP100_AddReplaceFieldBinary(wchar_t pJobID[41] , PP100_REPLACE_FIELD_BINARY pReplaceFieldBinary[] , unsigned long ulReplaceFieldBinaryNum);
	long PP100_DeleteReplaceFieldBinary(wchar_t pJobID[41] , PP100_REPLACE_FIELD_BINARY pReplaceFieldBinary[] , unsigned long ulReplaceFieldBinaryNum);
	long PP100_GetReplaceFieldBinary(wchar_t pJobID[41] , PP100_REPLACE_FIELD_BINARY pReplaceFieldBinary[] , unsigned long* pReplaceFieldBinaryNum);
	long PP100_SetLabelArea(wchar_t pJobID[41] , unsigned long ulDiscDiamOut , unsigned long ulDiscDiamIn);
	long PP100_GetLabelArea(wchar_t pJobID[41] , unsigned long* pDiscDiamOut , unsigned long* pDiscDiamIn);
	long PP100_SetPrintMode(wchar_t pJobID[41] , unsigned long ulPrintMode);
	long PP100_GetPrintMode(wchar_t pJobID[41] , unsigned long* pPrintMode);
	long PP100_SetPlugInID(wchar_t pJobID[41] , wchar_t pPlugInId[41]);
	long PP100_GetPlugInID(wchar_t pJobID[41] , wchar_t pPlugInId[41]);
	long PP100_SetPlugInParameter(wchar_t pJobID[41] , wchar_t pPlugInParameter[1025]);
	long PP100_GetPlugInParameter(wchar_t pJobID[41] , wchar_t pPlugInParameter[1025]);
	long PP100_SetPriority(wchar_t pJobID[41] , unsigned long ulPriority);
	long PP100_GetPriority(wchar_t pJobID[41] , unsigned long* pPriority);
	long PP100_SetMeasure(wchar_t pJobID[41] , unsigned long ulMeasure);
	long PP100_GetMeasure(wchar_t pJobID[41] , unsigned long* pMeasure);
	long PP100_SetArchiveDiscOnly(wchar_t pJobID[41] , unsigned long ulArchiveDiscOnly);
	long PP100_GetArchiveDiscOnly(wchar_t pJobID[41] , unsigned long* pArchiveDiscOnly);
	long PP100_ConvertErrorCodeToString(unsigned long ulErrorCode , wchar_t pErrorString[1025]);
	long PP100_ConvertInformationCodeToString(unsigned long ulInformationCode , wchar_t pInformationString[1025]);

private:
	HMODULE m_hPP100APIDLL;

	FARPROC m_pFunctionPointer[NUM_PP100_API];

	INT LoadPP100API();
	INT FreePP100API();
	INT GetAllFunctionAddress(HMODULE hModule);
	void InitializeFunctionPointer();
};
