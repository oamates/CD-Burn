
// PP100APISampleCPlusPlusDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PP100APISampleCPlusPlus.h"
#include "PP100APISampleCPlusPlusDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CPP100APISampleCPlusPlusDlg dialog

// Key : Server handle, Host and OrderFolder string
// Value : Server handle which is got by calling PP100_ConnectServer()
CMapStringToString serverTable;

// Translate signed number to CString
template <typename T>
CString SignedNumToString(T num)
{
	CString strRet;
	strRet.Format(_T("%d") , num);
	return strRet;
}

// Translate unsigned number to CString
template <typename T>
CString UnsignedNumToString(T num)
{
	CString strRet;
	strRet.Format(_T("%lu") , num);
	return strRet;
}

CPP100APISampleCPlusPlusDlg::CPP100APISampleCPlusPlusDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPP100APISampleCPlusPlusDlg::IDD, pParent)
	, m_strHost(_T(""))
	, m_strOrderFolder(_T(""))
	, m_strResultText(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	// Allocate the CPP100APIManager
	m_lpPP100APIManager = new CPP100APIManager();
	if(NULL != m_lpPP100APIManager)
	{
		// If allocating succeeded, initialize PP100API.dll
		m_lpPP100APIManager->PP100_Initialize();
	}
}

CPP100APISampleCPlusPlusDlg::~CPP100APISampleCPlusPlusDlg()
{
	if(NULL != m_lpPP100APIManager)
	{
		// If CPP100APIManager object exists, release PP100API.dll and delete CPP100APIManager
		m_lpPP100APIManager->PP100_Destroy();
		delete m_lpPP100APIManager;
	}
}

void CPP100APISampleCPlusPlusDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BUTTON_CONNECT, m_buttonConnect);
	DDX_Control(pDX, IDC_BUTTON_ENUMERATE_PUBLISHERS, m_buttonEnumeratePublishers);
	DDX_Control(pDX, IDC_BUTTON_GET_PUBLISHER_STATUS, m_buttonGetPublisherStatus);
	DDX_Control(pDX, IDC_BUTTON_SUBMIT_JOB, m_buttonSubmitJob);
	DDX_Control(pDX, IDC_BUTTON_GET_CREATED_JOB_LIST, m_buttonGetCreatedJobList);
	DDX_Control(pDX, IDC_BUTTON_GET_JOB_STATUS, m_buttonGetJobStatus);
	DDX_Control(pDX, IDC_BUTTON_CANCEL_JOB, m_buttonCancelJob);
	DDX_Control(pDX, IDC_BUTTON_CLEAR_TEXT, m_buttonClearText);
	DDX_Control(pDX, IDC_COMBO_SERVER_HANDLE, m_comboboxServerHandle);
	DDX_Control(pDX, IDC_COMBO_PUBLISHERS, m_comboboxPublishers);
	DDX_Control(pDX, IDC_COMBO_JOB_ID, m_comboboxJobID);
	DDX_Text(pDX, IDC_EDIT_HOST, m_strHost);
	DDX_Text(pDX, IDC_EDIT_ORDER_FOLDER, m_strOrderFolder);
	DDX_Text(pDX, IDC_EDIT_RESULT_TEXT, m_strResultText);
}

BEGIN_MESSAGE_MAP(CPP100APISampleCPlusPlusDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_CONNECT, &CPP100APISampleCPlusPlusDlg::buttonConnect_Click)
	ON_BN_CLICKED(IDC_BUTTON_ENUMERATE_PUBLISHERS, &CPP100APISampleCPlusPlusDlg::buttonEnumeratePublishers_Click)
	ON_BN_CLICKED(IDC_BUTTON_GET_PUBLISHER_STATUS, &CPP100APISampleCPlusPlusDlg::buttonGetPublisherStatus_Click)
	ON_BN_CLICKED(IDC_BUTTON_SUBMIT_JOB, &CPP100APISampleCPlusPlusDlg::buttonSubmitJob_Click)
	ON_BN_CLICKED(IDC_BUTTON_GET_CREATED_JOB_LIST, &CPP100APISampleCPlusPlusDlg::buttonGetCreatedJobList_Click)
	ON_BN_CLICKED(IDC_BUTTON_GET_JOB_STATUS, &CPP100APISampleCPlusPlusDlg::buttonGetJobStatus_Click)
	ON_BN_CLICKED(IDC_BUTTON_CANCEL_JOB, &CPP100APISampleCPlusPlusDlg::buttonCancelJob_Click)
	ON_BN_CLICKED(IDC_BUTTON_CLEAR_TEXT, &CPP100APISampleCPlusPlusDlg::buttonClearText_Click)
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
END_MESSAGE_MAP()


// CPP100APISampleCPlusPlusDlg message handlers

BOOL CPP100APISampleCPlusPlusDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	m_buttonEnumeratePublishers.EnableWindow(FALSE);
	m_buttonGetPublisherStatus.EnableWindow(FALSE);
	m_buttonSubmitJob.EnableWindow(FALSE);
	m_buttonGetJobStatus.EnableWindow(FALSE);
	m_buttonCancelJob.EnableWindow(FALSE);
	m_comboboxServerHandle.SetDroppedWidth(200);
	m_comboboxJobID.SetDroppedWidth(200);

	CRect rc;
	GetWindowRect(&rc);
	m_ptMinimum.x = rc.Size().cx;
	m_ptMinimum.y = rc.Size().cy;

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPP100APISampleCPlusPlusDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPP100APISampleCPlusPlusDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CPP100APISampleCPlusPlusDlg::OnDestroy()
{
	CDialog::OnDestroy();

	// Disconnect from server which is connected
	CString strKey , strValue;
	POSITION pos;
	unsigned long ulServerHandle = 0;
	for (pos = serverTable.GetStartPosition(); NULL != pos;)
	{
		// Get the Host and the OrderFolder string
		serverTable.GetNextAssoc(pos , strKey , strValue);
		// Get the server handle which is got by calling PP100_ConnectServer()
		ulServerHandle = ::_tstol(strValue);
		// Disconnect from server
		m_lpPP100APIManager->PP100_DisconnectServer(ulServerHandle);
	}
}

void CPP100APISampleCPlusPlusDlg::buttonConnect_Click()
{
	long lRet = PP100API_SUCCESS;
	unsigned long ulServerHandle = 0;
	UpdateData(TRUE);
	// Call PP100_ConnectServer()
	// If Host is empty, pHost parameter will be assumed NULL(local PC)
	// If Order Folder is empty, pOrderFolder parameter will be assumed NULL(local PC)
	lRet = m_lpPP100APIManager->PP100_ConnectServer(	(true == m_strHost.IsEmpty())?NULL:CT2W(m_strHost) , 
														(true == m_strOrderFolder.IsEmpty())?NULL:CT2W(m_strOrderFolder) , 
														&ulServerHandle);
	// If succeeded, output the result and store the server handle which is got by PP100_ConnectServer() to serverTable(CMapStringToString)
	if(PP100API_SUCCESS == lRet)
	{
		m_strResultText += _T("PP100_ConnectServer(") + m_strHost + _T(" , ") + m_strOrderFolder + _T(") returns PP100API_SUCCESS\r\n");
		
		CString strServerHandle;
		// Translate server handle(unsigned long) to CString
		strServerHandle.Format(_T("%d") , ulServerHandle);
		// If server handle does not exist yet, add to serverTable(CMapStringToString)
		if(CB_ERR == m_comboboxServerHandle.FindString(-1 , strServerHandle + _T("(") + m_strHost + _T(" , ") + m_strOrderFolder + _T(")")))
		{
			serverTable.SetAt(strServerHandle + _T("(") + m_strHost + _T(" , ") + m_strOrderFolder + _T(")") , strServerHandle);
			m_comboboxServerHandle.AddString(strServerHandle + _T("(") + m_strHost + _T(" , ") + m_strOrderFolder + _T(")"));
		}
		// If the string in ServerHandle combobox is not empty, enable button
		if(0 != m_comboboxServerHandle.GetLBTextLen(m_comboboxServerHandle.GetCurSel()))
		{
			m_buttonEnumeratePublishers.EnableWindow(TRUE);
			m_buttonGetJobStatus.EnableWindow(TRUE);
			m_buttonCancelJob.EnableWindow(TRUE);
		}
		// Set the ServerHandle combobox selection to server handle just now
		if(CB_ERR != m_comboboxServerHandle.FindString(-1 , strServerHandle + _T("(") + m_strHost + _T(" , ") + m_strOrderFolder + _T(")")))
		{
			m_comboboxServerHandle.SetCurSel(m_comboboxServerHandle.FindString(-1 , strServerHandle + _T("(") + m_strHost + _T(" , ") + m_strOrderFolder + _T(")")));
		}
	}
	else
	{
		m_strResultText += _T("PP100_ConnectServer(") + m_strHost + _T(" , ") + m_strOrderFolder + _T(") returns ") + SignedNumToString(lRet) + _T("\r\n");
	}
	m_strResultText += _T("\r\n");
	UpdateData(FALSE);
	this->ScrollToLastLine();
}

void CPP100APISampleCPlusPlusDlg::buttonEnumeratePublishers_Click()
{
	long lRet = PP100API_SUCCESS;
	// If the ServerHandle combobox selected, call PP100_EnumPublishers()
	if(0 != m_comboboxServerHandle.GetCount() && 0 != m_comboboxServerHandle.GetLBTextLen(m_comboboxServerHandle.GetCurSel()))
	{
		CString strKey;
		// Translate the ServerHandle combobox string to server handle 
		m_comboboxServerHandle.GetLBText(m_comboboxServerHandle.GetCurSel() , strKey);
		CString strServerHandle;
		serverTable.Lookup(strKey , strServerHandle);
		unsigned long ulServerHandle = ::_tstol(strServerHandle);
		unsigned long ulEnumPublisherInfoNum = 0;
		// Call PP100_EnumPublishers()
		// To get the publisher number, pEnumPublisherInfo is set to NULL
		lRet = m_lpPP100APIManager->PP100_EnumPublishers(ulServerHandle , NULL , &ulEnumPublisherInfoNum);
		// If succeeded, allocate new memory to get the publisher's information and call PP100_EnumPublishers() again
		if(0 < ulEnumPublisherInfoNum)
		{
			while(PP100API_MORE_ITEMS == lRet)
			{
				PP100_ENUM_PUBLISHER_INFO* pEnumPublisherInfo = new PP100_ENUM_PUBLISHER_INFO[ulEnumPublisherInfoNum];
				::ZeroMemory(pEnumPublisherInfo , sizeof(PP100_ENUM_PUBLISHER_INFO) * ulEnumPublisherInfoNum);
				lRet = m_lpPP100APIManager->PP100_EnumPublishers(ulServerHandle , pEnumPublisherInfo , &ulEnumPublisherInfoNum);
				if(PP100API_SUCCESS == lRet)
				{
					m_strResultText += _T("PP100_EnumPublishers(") + strServerHandle + _T(") returns PP100API_SUCCESS\r\n");
					m_comboboxPublishers.ResetContent();
					// Output the result of PP100_EnumPublishers()
					// pPublisherName : the name which is registered by Total Disc Setup(ex.PP-100 1)
					// ulDriveNumber : the drive number which publisher equips(0 : PP-100 and PP-100N , 2 : PP-100AP)
					// ulConnectType : the publisher's connection type(0 : USB , 1 : Ethernet)
					for(unsigned long ul = 0;ul < ulEnumPublisherInfoNum;ul++)
					{
						m_comboboxPublishers.AddString(CW2T(pEnumPublisherInfo[ul].pPublisherName));

						m_strResultText += _T("\r\n");

						m_strResultText += _T("pEnumPublisherInfo[") + UnsignedNumToString(ul) + _T("].pPublisherName : ") + CW2T(pEnumPublisherInfo[ul].pPublisherName) + _T("\r\n");
						m_strResultText += _T("pEnumPublisherInfo[") + UnsignedNumToString(ul) + _T("].ulDriveNumber : ") + UnsignedNumToString(pEnumPublisherInfo[ul].ulDriveNumber) + _T("\r\n");
						m_strResultText += _T("pEnumPublisherInfo[") + UnsignedNumToString(ul) + _T("].ulConnectType : ") + UnsignedNumToString(pEnumPublisherInfo[ul].ulConnectType) + _T("\r\n");
					}
					// Set the Publishers combobox selection to pEnumPublisherInfo[0].pPublisherName
					if(0 != m_comboboxPublishers.GetCount())
					{
						m_comboboxPublishers.SetCurSel(0);
						m_buttonGetPublisherStatus.EnableWindow(TRUE);
						m_buttonSubmitJob.EnableWindow(TRUE);
					}
				}
				else
				{
					m_strResultText += _T("PP100_EnumPublishers(") + strServerHandle + _T(") returns") + SignedNumToString(lRet) + _T("\r\n");
				}
				m_strResultText += _T("\r\n");
				delete[] pEnumPublisherInfo;
			}
		}
	}
	UpdateData(FALSE);
	this->ScrollToLastLine();
}

void CPP100APISampleCPlusPlusDlg::buttonGetPublisherStatus_Click()
{
	long lRet = PP100API_SUCCESS;
	// If the ServerHandle combobox and Publishers combobox selected, call PP100_GetPublisherStatus()
	if(0 != m_comboboxServerHandle.GetLBTextLen(m_comboboxServerHandle.GetCurSel()))
	{
		CString strKey;
		m_comboboxServerHandle.GetLBText(m_comboboxServerHandle.GetCurSel() , strKey);
		CString strServerHandle;
		serverTable.Lookup(strKey , strServerHandle);
		unsigned long ulServerHandle = ::_tstol(strServerHandle);
		PP100_PUBLISHER_STATUS stPublisherStatus = {0};
		CString strPublisher;
		m_comboboxPublishers.GetLBText(m_comboboxPublishers.GetCurSel() , strPublisher);
		// Call PP100_GetPublisherStatus()
		lRet = m_lpPP100APIManager->PP100_GetPublisherStatus(ulServerHandle , CT2W(strPublisher) , &stPublisherStatus);
		// If succeeded, output the result of PP100_GetPublisherStatus()
		if(PP100API_SUCCESS == lRet)
		{
			m_strResultText += _T("PP100_GetPublisherStatus(") + strServerHandle + _T(") returns PP100API_SUCCESS\r\n");
			m_strResultText += _T("\r\n");

			for(unsigned long ul = 0;ul < sizeof(stPublisherStatus.ulINFORMATIONCode) / sizeof(stPublisherStatus.ulINFORMATIONCode[0]);ul++)
			{
				// If the ulINFORMATIONCode[ul] is 0(=PP100API_SUCCESS), no more INFORMATION code
				if(0 == stPublisherStatus.ulINFORMATIONCode[ul])
				{
					break;
				}
				m_strResultText += _T("stPublisherStatus.ulINFORMATIONCode[") + UnsignedNumToString(ul) + _T("] : ") + UnsignedNumToString(stPublisherStatus.ulINFORMATIONCode[ul]) + _T("\r\n");
			}
			m_strResultText += _T("stPublisherStatus.ulMode : ") + UnsignedNumToString(stPublisherStatus.ulMode) + _T("\r\n");
			for(unsigned long ul = 0;ul < sizeof(stPublisherStatus.ulDriveStatus) / sizeof(stPublisherStatus.ulDriveStatus[0]);ul++)
			{
				m_strResultText += _T("stPublisherStatus.ulDriveStatus[") + UnsignedNumToString(ul) + _T("] : ") + UnsignedNumToString(stPublisherStatus.ulDriveStatus[ul]) + _T("\r\n");
			}
			for(unsigned long ul = 0;ul < sizeof(stPublisherStatus.pDrivePluginName) / sizeof(stPublisherStatus.pDrivePluginName[0]);ul++)
			{
				m_strResultText += _T("stPublisherStatus.pDrivePluginName[") + UnsignedNumToString(ul) + _T("] : ") + CW2T(stPublisherStatus.pDrivePluginName[ul]) + _T("\r\n");
			}
			for(unsigned long ul = 0;ul < sizeof(stPublisherStatus.ulDriveLife) / sizeof(stPublisherStatus.ulDriveLife[0]);ul++)
			{
				m_strResultText += _T("stPublisherStatus.ulDriveLife[") + UnsignedNumToString(ul) + _T("] : ") + UnsignedNumToString(stPublisherStatus.ulDriveLife[ul]) + _T("\r\n");
			}
			m_strResultText += _T("stPublisherStatus.ulPrinterStatus : ") + UnsignedNumToString(stPublisherStatus.ulPrinterStatus) + _T("\r\n");
			m_strResultText += _T("stPublisherStatus.stInkStatus.ulCyan : ") + UnsignedNumToString(stPublisherStatus.stInkStatus.ulCyan) + _T("\r\n");
			m_strResultText += _T("stPublisherStatus.stInkStatus.ulMagenta : ") + UnsignedNumToString(stPublisherStatus.stInkStatus.ulMagenta) + _T("\r\n");
			m_strResultText += _T("stPublisherStatus.stInkStatus.ulYellow : ") + UnsignedNumToString(stPublisherStatus.stInkStatus.ulYellow) + _T("\r\n");
			m_strResultText += _T("stPublisherStatus.stInkStatus.ulLightCyan : ") + UnsignedNumToString(stPublisherStatus.stInkStatus.ulLightCyan) + _T("\r\n");
			m_strResultText += _T("stPublisherStatus.stInkStatus.ulLightMagenta : ") + UnsignedNumToString(stPublisherStatus.stInkStatus.ulLightMagenta) + _T("\r\n");
			m_strResultText += _T("stPublisherStatus.stInkStatus.ulBlack : ") + UnsignedNumToString(stPublisherStatus.stInkStatus.ulBlack) + _T("\r\n");
			for(unsigned long ul = 0;ul < sizeof(stPublisherStatus.ulStackerSetting) / sizeof(stPublisherStatus.ulStackerSetting[0]);ul++)
			{
				m_strResultText += _T("stPublisherStatus.ulStackerSetting[") + UnsignedNumToString(ul) + _T("] : ") + UnsignedNumToString(stPublisherStatus.ulStackerSetting[ul]) + _T("\r\n");
			}
			for(unsigned long ul = 0;ul < sizeof(stPublisherStatus.ulStackerRest) / sizeof(stPublisherStatus.ulStackerRest[0]);ul++)
			{
				m_strResultText += _T("stPublisherStatus.ulStackerRest[") + UnsignedNumToString(ul) + _T("] : ") + UnsignedNumToString(stPublisherStatus.ulStackerRest[ul]) + _T("\r\n");
			}
			m_strResultText += _T("stPublisherStatus.ulPrintableCopies : ") + UnsignedNumToString(stPublisherStatus.ulPrintableCopies) + _T("\r\n");
			m_strResultText += _T("stPublisherStatus.ulPrintedCopies : ") + UnsignedNumToString(stPublisherStatus.ulPrintedCopies) + _T("\r\n");
			m_strResultText += _T("stPublisherStatus.ulMaintenanceBoxFreeSpace : ") + UnsignedNumToString(stPublisherStatus.ulMaintenanceBoxFreeSpace) + _T("\r\n");
			m_strResultText += _T("stPublisherStatus.pSerialNumber : ") + (CString)CW2T(stPublisherStatus.pSerialNumber) + _T("\r\n");
			for(unsigned long ul = 0;ul < sizeof(stPublisherStatus.ulDriveProgress) / sizeof(stPublisherStatus.ulDriveProgress[0]);ul++)
			{
				m_strResultText += _T("stPublisherStatus.ulDriveProgress[") + UnsignedNumToString(ul) + _T("] : ") + UnsignedNumToString(stPublisherStatus.ulDriveProgress[ul]) + _T("\r\n");
			}
			m_strResultText += _T("stPublisherStatus.ulCompleteDiscNum : ") + UnsignedNumToString(stPublisherStatus.ulCompleteDiscNum) + _T("\r\n");
			m_strResultText += _T("stPublisherStatus.ulUsbConnectionMode : ") + UnsignedNumToString(stPublisherStatus.ulUsbConnectionMode) + _T("\r\n");
		}
		else
		{
			m_strResultText += _T("PP100_GetPublisherStatus(") + strServerHandle + _T(") returns") + SignedNumToString(lRet) + _T("\r\n");
		}
		m_strResultText += _T("\r\n");
	}
	UpdateData(FALSE);
	this->ScrollToLastLine();
}

void CPP100APISampleCPlusPlusDlg::buttonSubmitJob_Click()
{
	long lRet = PP100API_SUCCESS;
	// If the ServerHandle combobox and Publishers combobox selected, call PP100_SubmitJob()
	if(0 != m_comboboxServerHandle.GetLBTextLen(m_comboboxServerHandle.GetCurSel()))
	{
		wchar_t pJobID[41] = {0};
		// First, create JOB object and get JOB ID
		lRet = m_lpPP100APIManager->PP100_CreateJob(pJobID);
		// Second, set the JOB setting
		// Disc type is CD
		lRet = m_lpPP100APIManager->PP100_SetDiscType(pJobID , PP100API_CD);
		CString strPublisher;
		m_comboboxPublishers.GetLBText(m_comboboxPublishers.GetCurSel() , strPublisher);
		// Publisher is selection of Publishers combobox
		lRet = m_lpPP100APIManager->PP100_SetPublisher(pJobID , CT2W(strPublisher));
		PP100_WRITE_DATA stWriteData = {0};
		TCHAR pWindowsDirectory[MAX_PATH] = {0};
		::GetSystemDirectory(pWindowsDirectory , MAX_PATH);
		::PathCombine(stWriteData.pSourceData , CT2W(pWindowsDirectory) , L"NOTEPAD.EXE");
		::wcscpy_s(stWriteData.pDestinationData , L"note\\NOTEPAD.EXE");
		// Writing data is notepad.exe
		lRet = m_lpPP100APIManager->PP100_SetData(pJobID , &stWriteData , 1);

		// Get the server handle(unsigned long) which is got by PP100_ConnectServer()
		CString strKey;
		m_comboboxServerHandle.GetLBText(m_comboboxServerHandle.GetCurSel() , strKey);
		CString strServerHandle;
		serverTable.Lookup(strKey , strServerHandle);
		unsigned long ulServerHandle = ::_tstol(strServerHandle);
		// Call PP100_SubmitJob()
		lRet = m_lpPP100APIManager->PP100_SubmitJob(ulServerHandle , pJobID , false);
		if(PP100API_SUCCESS == lRet)
		{
			m_strResultText += _T("PP100_SubmitJob(") + strServerHandle + _T(") returns PP100API_SUCCESS\r\n");
		}
		else
		{
			m_strResultText += _T("PP100_SubmitJob(") + strServerHandle + _T(") returns") + SignedNumToString(lRet) + _T("\r\n");
		}
		m_strResultText += _T("\r\n");
	}
	UpdateData(FALSE);
	this->ScrollToLastLine();
}

void CPP100APISampleCPlusPlusDlg::buttonGetCreatedJobList_Click()
{
	long lRet = PP100API_SUCCESS;
	unsigned long ulJobIDNum = 0;

	// Call PP100_GetCreatedJobList()
	// To get the JOB number, pJobID is set to NULL
	lRet = m_lpPP100APIManager->PP100_GetCreatedJobList(NULL , &ulJobIDNum);
	// If succeeded, allocate new memory to get the JOB ID and call PP100_GetCreatedJobList() again
	if(0 < ulJobIDNum)
	{
		wchar_t** pJobIDList = new wchar_t*[ulJobIDNum];
		for(unsigned long ul = 0;ul < ulJobIDNum;ul++)
		{
			pJobIDList[ul] = new wchar_t[41];
			::ZeroMemory(pJobIDList[ul] , sizeof(wchar_t) * 41);
		}
		lRet = m_lpPP100APIManager->PP100_GetCreatedJobList(pJobIDList , &ulJobIDNum);
		// If succeeded, all JOB ID will be set Job ID combobox
		if(PP100API_SUCCESS == lRet)
		{
			m_strResultText += _T("PP100_GetCreatedJobList() returns PP100API_SUCCESS\r\n");
			m_comboboxJobID.ResetContent();
			for(unsigned long ul = 0;ul < ulJobIDNum;ul++)
			{
				m_comboboxJobID.AddString(CW2T(pJobIDList[ul]));
			}
			if(0 != m_comboboxJobID.GetCount())
			{
				m_comboboxJobID.SetCurSel(0);
			}
		}
		else
		{
			m_strResultText += _T("PP100_GetCreatedJobList() returns") + SignedNumToString(lRet) + _T("\r\n");
		}

		for(unsigned long ul = 0;ul < ulJobIDNum;ul++)
		{
			if(NULL != pJobIDList[ul])
			{
				delete pJobIDList[ul];
			}
		}
		delete[] pJobIDList;
	}
	else
	{
		m_strResultText += _T("PP100_GetCreatedJobList() returns PP100API_SUCCESS\r\n");
	}
	m_strResultText += _T("\r\n");
	UpdateData(FALSE);
	this->ScrollToLastLine();
}

void CPP100APISampleCPlusPlusDlg::buttonGetJobStatus_Click()
{
	long lRet = PP100API_MORE_ITEMS;

	// If the ServerHandle combobox selected, call PP100_GetJobStatus()
	if(0 != m_comboboxServerHandle.GetLBTextLen(m_comboboxServerHandle.GetCurSel()))
	{
		// Get the server handle(unsigned long) which is got by PP100_ConnectServer()
		CString strKey;
		m_comboboxServerHandle.GetLBText(m_comboboxServerHandle.GetCurSel() , strKey);
		CString strServerHandle;
		serverTable.Lookup(strKey , strServerHandle);
		unsigned long ulServerHandle = ::_tstol(strServerHandle);
		
		// If Job ID combobox is empty, pJobID parameter will be assumed NULL to get all JOB status in ServerHandle combobox
		// If Job ID combobox is not empty, pJobID parameter will be set to Job ID combobox to get the JOB status specified by Job ID combobox
		unsigned long ulJobStatusNum = 0;
		wchar_t* pJobID = NULL;
		while(PP100API_MORE_ITEMS == lRet)
		{
			if(0 != m_comboboxJobID.GetWindowTextLengthW())
			{
				CString strJobID;
				m_comboboxJobID.GetWindowTextW(strJobID);
				ulJobStatusNum = 1;
				pJobID = new wchar_t[41];
				::wcscpy_s(pJobID , 41 , CT2W(strJobID));
			}
			else
			{
				lRet = m_lpPP100APIManager->PP100_GetJobStatus(ulServerHandle , NULL , NULL , &ulJobStatusNum);
				pJobID = NULL;
			}
			// Allocate new memory to get the JOB status and call PP100_GetJobStatus() again
			PP100_JOB_STATUS* pJobStatus = new PP100_JOB_STATUS[ulJobStatusNum];
			::ZeroMemory(pJobStatus , sizeof(PP100_JOB_STATUS) * ulJobStatusNum);
			lRet = m_lpPP100APIManager->PP100_GetJobStatus(ulServerHandle , pJobID , pJobStatus , &ulJobStatusNum);
			if(PP100API_SUCCESS == lRet)
			{
				m_strResultText += _T("PP100_GetJobStatus(") + strServerHandle + _T(") returns PP100API_SUCCESS\r\n");
				// If succeeded, output the result of PP100_GetJobStatus()
				for(unsigned long ul = 0;ul < ulJobStatusNum;ul++)
				{
					m_strResultText += _T("\r\n");

					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].pJobID : ") + CW2T(pJobStatus[ul].pJobID) + _T("\r\n");
					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].pPublisherName : ") + CW2T(pJobStatus[ul].pPublisherName) + _T("\r\n");
					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].ulJobStatus : ") + UnsignedNumToString(pJobStatus[ul].ulJobStatus) + _T("\r\n");
					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].ulErrorCode : ") + UnsignedNumToString(pJobStatus[ul].ulErrorCode) + _T("\r\n");
					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].ulPublicationNumber : ") + UnsignedNumToString(pJobStatus[ul].ulPublicationNumber) + _T("\r\n");
					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].ulCompletionNumber : ") + UnsignedNumToString(pJobStatus[ul].ulCompletionNumber) + _T("\r\n");
					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].ulJobType : ") + UnsignedNumToString(pJobStatus[ul].ulJobType) + _T("\r\n");
					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].ulSource : ") + UnsignedNumToString(pJobStatus[ul].ulSource) + _T("\r\n");
					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].ulDestination : ") + UnsignedNumToString(pJobStatus[ul].ulDestination) + _T("\r\n");
					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].ulJobIndex : ") + UnsignedNumToString(pJobStatus[ul].ulJobIndex) + _T("\r\n");
					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].ulEstimateTime : ") + UnsignedNumToString(pJobStatus[ul].ulEstimateTime) + _T("\r\n");
					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].ulRemainingEstimateTime : ") + UnsignedNumToString(pJobStatus[ul].ulRemainingEstimateTime) + _T("\r\n");
					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].ulErrorNumber : ") + UnsignedNumToString(pJobStatus[ul].ulErrorNumber) + _T("\r\n");
					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].ulMode : ") + UnsignedNumToString(pJobStatus[ul].ulMode) + _T("\r\n");
					m_strResultText += _T("pJobStatus[") + UnsignedNumToString(ul) + _T("].ucIsSubmittedByTotalDiscMaker : ") + UnsignedNumToString(pJobStatus[ul].ucIsSubmittedByTotalDiscMaker) + _T("\r\n");
				}
			}
			else
			{
				m_strResultText += _T("PP100_GetJobStatus(") + strServerHandle + _T(") returns") + SignedNumToString(lRet) + _T("\r\n");
			}

			delete[] pJobStatus;

			if(NULL != pJobID)
			{
				delete pJobID;
			}
		}
	}
	m_strResultText += _T("\r\n");
	UpdateData(FALSE);
	this->ScrollToLastLine();
}

void CPP100APISampleCPlusPlusDlg::buttonCancelJob_Click()
{
	long lRet = PP100API_SUCCESS;
	// If the ServerHandle combobox selected, call PP100_CancelJob()
	if(0 != m_comboboxServerHandle.GetLBTextLen(m_comboboxServerHandle.GetCurSel()))
	{
		// Get the server handle(unsigned long) which is got by PP100_ConnectServer()
		CString strKey;
		m_comboboxServerHandle.GetLBText(m_comboboxServerHandle.GetCurSel() , strKey);
		CString strServerHandle;
		serverTable.Lookup(strKey , strServerHandle);
		unsigned long ulServerHandle = ::_tstol(strServerHandle);
		
		// Get the JOB ID from Job ID combobox
		CString strJobID;
		if(0 != m_comboboxJobID.GetWindowTextLengthW())
		{
			m_comboboxJobID.GetWindowTextW(strJobID);
		}
		else
		{
			strJobID = _T("");
		}

		// Call PP100_CancelJob() and output return value
		lRet = m_lpPP100APIManager->PP100_CancelJob(ulServerHandle , CT2W(strJobID));
		if(PP100API_SUCCESS == lRet)
		{
			m_strResultText += _T("PP100_CancelJob(") + strServerHandle + _T(") returns PP100API_SUCCESS\r\n");
		}
		else
		{
			m_strResultText += _T("PP100_CancelJob(") + strServerHandle + _T(") returns") + SignedNumToString(lRet) + _T("\r\n");
		}
		m_strResultText += _T("\r\n");	
	}
	UpdateData(FALSE);
	this->ScrollToLastLine();
}

void CPP100APISampleCPlusPlusDlg::buttonClearText_Click()
{
	m_strResultText.Empty();
	UpdateData(FALSE);
}

void CPP100APISampleCPlusPlusDlg::ScrollToLastLine()
{
	CEdit* pEdit = (CEdit *)GetDlgItem(IDC_EDIT_RESULT_TEXT);
	pEdit->LineScroll(pEdit->GetLineCount());
}

void CPP100APISampleCPlusPlusDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	// If OnSize() event, adjust the control size
	CEdit* pEditResultText = (CEdit *)GetDlgItem(IDC_EDIT_RESULT_TEXT);
	if(NULL != pEditResultText && NULL != m_buttonCancelJob.m_hWnd &&NULL != m_buttonClearText.m_hWnd)
	{
		CRect rcClient , rcButtonClearText , rcEditResultText , rcButtonCancelJob , rcButtonEditHost;

		GetDlgItem(IDC_EDIT_HOST)->GetWindowRect(&rcButtonEditHost);

		GetClientRect(&rcClient);
		pEditResultText->GetWindowRect(&rcEditResultText);
		m_buttonClearText.GetWindowRect(&rcButtonClearText);
		m_buttonCancelJob.GetWindowRect(&rcButtonCancelJob);
		m_buttonClearText.MoveWindow(	rcClient.right - (rcButtonClearText.right - rcButtonClearText.left) - 10 , 
										rcClient.bottom - (rcButtonClearText.bottom - rcButtonClearText.top) - 10 , 
										rcButtonClearText.right - rcButtonClearText.left , 
										rcButtonClearText.bottom - rcButtonClearText.top);
		m_buttonClearText.GetWindowRect(&rcButtonClearText);
		pEditResultText->MoveWindow(	rcClient.left + 10 , 
										rcButtonCancelJob.bottom - rcButtonEditHost.top + 20 , 
										cx - 20 , 
										rcButtonClearText.top - rcButtonCancelJob.bottom - 20);	
	}
}

void CPP100APISampleCPlusPlusDlg::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{
	if(NULL != m_hWnd)
	{
		lpMMI->ptMinTrackSize = m_ptMinimum;
	}

	CDialog::OnGetMinMaxInfo(lpMMI);
}

