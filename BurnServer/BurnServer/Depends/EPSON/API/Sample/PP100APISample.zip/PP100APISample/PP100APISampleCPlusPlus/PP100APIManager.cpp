#include "StdAfx.h"
#include "PP100APIManager.h"

// The full path of PP100API.dll.
// If you changed the installation folder of EPSON TD Bridge, you need to changed the value.
#define PP100API_DLL _T("\\EPSON\\TDBridge\\API\\PP100API.dll")

CPP100APIManager::CPP100APIManager(void)
{
	// Initialize all function pointer of PP100API.dll
	InitializeFunctionPointer();

	// LoadLibrary() PP100API.dll and get the function pointer
	LoadPP100API();
}

CPP100APIManager::~CPP100APIManager(void)
{
	// FreeLibrary() PP100API.dll
	FreePP100API();

	// Initialize all function pointer of PP100API.dll
	InitializeFunctionPointer();
}

long CPP100APIManager::PP100_Initialize(void)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_INITIALIZE])
	{
		lRet = ((PP100_INITIALIZE)m_pFunctionPointer[ID_PP100_INITIALIZE])();
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_Destroy(void)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_DESTROY])
	{
		lRet = ((PP100_DESTROY)m_pFunctionPointer[ID_PP100_DESTROY])();
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_ConnectServer(wchar_t pHost[256] , wchar_t pOrderFolder[256] , unsigned long* pHandle)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_CONNECTSERVER])
	{
		lRet = ((PP100_CONNECTSERVER)m_pFunctionPointer[ID_PP100_CONNECTSERVER])(pHost , pOrderFolder , pHandle);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_DisconnectServer(unsigned long ulHandle)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_DISCONNECTSERVER])
	{
		lRet = ((PP100_DISCONNECTSERVER)m_pFunctionPointer[ID_PP100_DISCONNECTSERVER])(ulHandle);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_EnumPublishers(unsigned long ulHandle , PP100_ENUM_PUBLISHER_INFO pEnumPublisherInfo[] , unsigned long* pEnumPublisherInfoNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_ENUMPUBLISHERS])
	{
		lRet = ((PP100_ENUMPUBLISHERS)m_pFunctionPointer[ID_PP100_ENUMPUBLISHERS])(ulHandle , pEnumPublisherInfo , pEnumPublisherInfoNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetPublisherStatus(unsigned long ulHandle , wchar_t pPublisherName[256] , LPPP100_PUBLISHER_STATUS pPublisherStatus)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETPUBLISHERSTATUS])
	{
		lRet = ((PP100_GETPUBLISHERSTATUS)m_pFunctionPointer[ID_PP100_GETPUBLISHERSTATUS])(ulHandle , pPublisherName , pPublisherStatus);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetJobStatus(unsigned long ulHandle , wchar_t pJobID[256] , PP100_JOB_STATUS pJobStatus[] , unsigned long* pJobStatusNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETJOBSTATUS])
	{
		lRet = ((PP100_GETJOBSTATUS)m_pFunctionPointer[ID_PP100_GETJOBSTATUS])(ulHandle , pJobID , pJobStatus , pJobStatusNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_CreateJob(wchar_t pJobID[256])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_CREATEJOB])
	{
		lRet = ((PP100_CREATEJOB)m_pFunctionPointer[ID_PP100_CREATEJOB])(pJobID);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetCreatedJobList(wchar_t** pJobID , unsigned long* pJobIdNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETCREATEDJOBLIST])
	{
		lRet = ((PP100_GETCREATEDJOBLIST)m_pFunctionPointer[ID_PP100_GETCREATEDJOBLIST])(pJobID , pJobIdNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_CopyJob(wchar_t pSourceJobID[41] , wchar_t pDestinationJobID[41])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_COPYJOB])
	{
		lRet = ((PP100_COPYJOB)m_pFunctionPointer[ID_PP100_COPYJOB])(pSourceJobID , pDestinationJobID);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_DeleteJob(wchar_t pJobID[41])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_DELETEJOB])
	{
		lRet = ((PP100_DELETEJOB)m_pFunctionPointer[ID_PP100_DELETEJOB])(pJobID);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SubmitJob(unsigned long ulHandle , wchar_t pJobID[256] , bool bAutoDelete)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SUBMITJOB])
	{
		lRet = ((PP100_SUBMITJOB)m_pFunctionPointer[ID_PP100_SUBMITJOB])(ulHandle , pJobID , bAutoDelete);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_CancelJob(unsigned long ulHandle , wchar_t pJobID[256])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_CANCELJOB])
	{
		lRet = ((PP100_CANCELJOB)m_pFunctionPointer[ID_PP100_CANCELJOB])(ulHandle , pJobID);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetPublisher(wchar_t pJobID[256] , wchar_t pPublisher[65])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETPUBLISHER])
	{
		lRet = ((PP100_SETPUBLISHER)m_pFunctionPointer[ID_PP100_SETPUBLISHER])(pJobID , pPublisher);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetPublisher(wchar_t pJobID[256] , wchar_t pPublisher[65])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETPUBLISHER])
	{
		lRet = ((PP100_GETPUBLISHER)m_pFunctionPointer[ID_PP100_GETPUBLISHER])(pJobID , pPublisher);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetCopies(wchar_t pJobID[256] , unsigned long ulNumber)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETCOPIES])
	{
		lRet = ((PP100_SETCOPIES)m_pFunctionPointer[ID_PP100_SETCOPIES])(pJobID , ulNumber);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetCopies(wchar_t pJobID[256] , unsigned long* pNumber)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETCOPIES])
	{
		lRet = ((PP100_GETCOPIES)m_pFunctionPointer[ID_PP100_GETCOPIES])(pJobID , pNumber);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetOutStacker(wchar_t pJobID[256] , unsigned long ulOutStacker)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETOUTSTACKER])
	{
		lRet = ((PP100_SETOUTSTACKER)m_pFunctionPointer[ID_PP100_SETOUTSTACKER])(pJobID , ulOutStacker);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetOutStacker(wchar_t pJobID[256] , unsigned long* pOutStacker)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETOUTSTACKER])
	{
		lRet = ((PP100_GETOUTSTACKER)m_pFunctionPointer[ID_PP100_GETOUTSTACKER])(pJobID , pOutStacker);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetInStacker(wchar_t pJobID[256] , unsigned long ulInStacker)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETINSTACKER])
	{
		lRet = ((PP100_SETINSTACKER)m_pFunctionPointer[ID_PP100_SETINSTACKER])(pJobID , ulInStacker);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetInStacker(wchar_t pJobID[256] , unsigned long* pInStacker)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETINSTACKER])
	{
		lRet = ((PP100_GETINSTACKER)m_pFunctionPointer[ID_PP100_GETINSTACKER])(pJobID , pInStacker);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetDiscType(wchar_t pJobID[256] , unsigned long ulDiscType)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETDISCTYPE])
	{
		lRet = ((PP100_SETDISCTYPE)m_pFunctionPointer[ID_PP100_SETDISCTYPE])(pJobID , ulDiscType);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetDiscType(wchar_t pJobID[256] , unsigned long* pDiscType)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETDISCTYPE])
	{
		lRet = ((PP100_GETDISCTYPE)m_pFunctionPointer[ID_PP100_GETDISCTYPE])(pJobID , pDiscType);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetWritingSpeed(wchar_t pJobID[256] , float fWritingSpeed)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETWRITINGSPEED])
	{
		lRet = ((PP100_SETWRITINGSPEED)m_pFunctionPointer[ID_PP100_SETWRITINGSPEED])(pJobID , fWritingSpeed);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetWritingSpeed(wchar_t pJobID[256] , float* pWritingSpeed)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETWRITINGSPEED])
	{
		lRet = ((PP100_GETWRITINGSPEED)m_pFunctionPointer[ID_PP100_GETWRITINGSPEED])(pJobID , pWritingSpeed);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetCompare(wchar_t pJobID[256] , unsigned long ulCompare)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETCOMPARE])
	{
		lRet = ((PP100_SETCOMPARE)m_pFunctionPointer[ID_PP100_SETCOMPARE])(pJobID , ulCompare);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetCompare(wchar_t pJobID[256] , unsigned long* pCompare)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETCOMPARE])
	{
		lRet = ((PP100_GETCOMPARE)m_pFunctionPointer[ID_PP100_GETCOMPARE])(pJobID , pCompare);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetCloseDisc(wchar_t pJobID[256] , unsigned long ulCloseDisc)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETCLOSEDISC])
	{
		lRet = ((PP100_SETCLOSEDISC)m_pFunctionPointer[ID_PP100_SETCLOSEDISC])(pJobID , ulCloseDisc);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetCloseDisc(wchar_t pJobID[256] , unsigned long* pCloseDisc)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETCLOSEDISC])
	{
		lRet = ((PP100_GETCLOSEDISC)m_pFunctionPointer[ID_PP100_GETCLOSEDISC])(pJobID , pCloseDisc);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetFormat(wchar_t pJobID[256] , unsigned long ulWritingFormat)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETFORMAT])
	{
		lRet = ((PP100_SETFORMAT)m_pFunctionPointer[ID_PP100_SETFORMAT])(pJobID , ulWritingFormat);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetFormat(wchar_t pJobID[256] , unsigned long* pWritingFormat)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETFORMAT])
	{
		lRet = ((PP100_GETFORMAT)m_pFunctionPointer[ID_PP100_GETFORMAT])(pJobID , pWritingFormat);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetData(wchar_t pJobID[41] , PP100_WRITE_DATA pWriteData[] , unsigned long ulWriteDataNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETDATA])
	{
		lRet = ((PP100_SETDATA)m_pFunctionPointer[ID_PP100_SETDATA])(pJobID , pWriteData , ulWriteDataNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_AddData(wchar_t pJobID[41] , PP100_WRITE_DATA pWriteData[] , unsigned long ulWriteDataNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_ADDDATA])
	{
		lRet = ((PP100_ADDDATA)m_pFunctionPointer[ID_PP100_ADDDATA])(pJobID , pWriteData , ulWriteDataNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_DeleteData(wchar_t pJobID[41] , PP100_WRITE_DATA pWriteData[] , unsigned long ulWriteDataNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_DELETEDATA])
	{
		lRet = ((PP100_DELETEDATA)m_pFunctionPointer[ID_PP100_DELETEDATA])(pJobID , pWriteData , ulWriteDataNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetData(wchar_t pJobID[41] , PP100_WRITE_DATA pWriteData[] , unsigned long* pWriteDataNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETDATA])
	{
		lRet = ((PP100_GETDATA)m_pFunctionPointer[ID_PP100_GETDATA])(pJobID , pWriteData , pWriteDataNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetVolumeLabel(wchar_t pJobID[41] , wchar_t pVolumeLabel[63])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETVOLUMELABEL])
	{
		lRet = ((PP100_SETVOLUMELABEL)m_pFunctionPointer[ID_PP100_SETVOLUMELABEL])(pJobID , pVolumeLabel);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetVolumeLabel(wchar_t pJobID[41] , wchar_t pVolumeLabel[63])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETVOLUMELABEL])
	{
		lRet = ((PP100_GETVOLUMELABEL)m_pFunctionPointer[ID_PP100_GETVOLUMELABEL])(pJobID , pVolumeLabel);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetVideo(wchar_t pJobID[41] , wchar_t pVideoPath[256])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETVIDEO])
	{
		lRet = ((PP100_SETVIDEO)m_pFunctionPointer[ID_PP100_SETVIDEO])(pJobID , pVideoPath);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetVideo(wchar_t pJobID[41] , wchar_t pVideoPath[256])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETVIDEO])
	{
		lRet = ((PP100_GETVIDEO)m_pFunctionPointer[ID_PP100_GETVIDEO])(pJobID , pVideoPath);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetVideoTitle(wchar_t pJobID[41] , wchar_t pVideoTitle[33])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETVIDEOTITLE])
	{
		lRet = ((PP100_SETVIDEOTITLE)m_pFunctionPointer[ID_PP100_SETVIDEOTITLE])(pJobID , pVideoTitle);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetVideoTitle(wchar_t pJobID[41] , wchar_t pVideoTitle[33])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETVIDEOTITLE])
	{
		lRet = ((PP100_GETVIDEOTITLE)m_pFunctionPointer[ID_PP100_GETVIDEOTITLE])(pJobID , pVideoTitle);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetImage(wchar_t pJobID[41] , wchar_t pImage[256])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETIMAGE])
	{
		lRet = ((PP100_SETIMAGE)m_pFunctionPointer[ID_PP100_SETIMAGE])(pJobID , pImage);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetImage(wchar_t pJobID[41] , wchar_t pImage[256])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETIMAGE])
	{
		lRet = ((PP100_SETIMAGE)m_pFunctionPointer[ID_PP100_GETIMAGE])(pJobID , pImage);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetAudioTrack(wchar_t pJobID[41] , PP100_AUDIO_TRACK pAudioTrack[] , unsigned long ulAudioTrackNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETAUDIOTRACK])
	{
		lRet = ((PP100_SETAUDIOTRACK)m_pFunctionPointer[ID_PP100_SETAUDIOTRACK])(pJobID , pAudioTrack , ulAudioTrackNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_AddAudioTrack(wchar_t pJobID[41] , PP100_AUDIO_TRACK pAudioTrack[] , unsigned long ulAudioTrackNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_ADDAUDIOTRACK])
	{
		lRet = ((PP100_ADDAUDIOTRACK)m_pFunctionPointer[ID_PP100_ADDAUDIOTRACK])(pJobID , pAudioTrack , ulAudioTrackNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_DeleteAudioTrack(wchar_t pJobID[41] , PP100_AUDIO_TRACK pAudioTrack[] , unsigned long ulAudioTrackNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_DELETEAUDIOTRACK])
	{
		lRet = ((PP100_DELETEAUDIOTRACK)m_pFunctionPointer[ID_PP100_DELETEAUDIOTRACK])(pJobID , pAudioTrack , ulAudioTrackNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetAudioTrack(wchar_t pJobID[41] , PP100_AUDIO_TRACK pAudioTrack[] , unsigned long* pAudioTrackNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETAUDIOTRACK])
	{
		lRet = ((PP100_GETAUDIOTRACK)m_pFunctionPointer[ID_PP100_GETAUDIOTRACK])(pJobID , pAudioTrack , pAudioTrackNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetAudioTitle(wchar_t pJobID[41] , wchar_t pAudioTitle[129])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETAUDIOTITLE])
	{
		lRet = ((PP100_SETAUDIOTITLE)m_pFunctionPointer[ID_PP100_SETAUDIOTITLE])(pJobID , pAudioTitle);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetAudioTitle(wchar_t pJobID[41] , wchar_t pAudioTitle[129])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETAUDIOTITLE])
	{
		lRet = ((PP100_SETAUDIOTITLE)m_pFunctionPointer[ID_PP100_GETAUDIOTITLE])(pJobID , pAudioTitle);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetAudioCatalogCode(wchar_t pJobID[41] , wchar_t pAudioCatalogCode[14])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETAUDIOCATALOGCODE])
	{
		lRet = ((PP100_SETAUDIOCATALOGCODE)m_pFunctionPointer[ID_PP100_SETAUDIOCATALOGCODE])(pJobID , pAudioCatalogCode);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetAudioCatalogCode(wchar_t pJobID[41] , wchar_t pAudioCatalogCode[14])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETAUDIOCATALOGCODE])
	{
		lRet = ((PP100_GETAUDIOCATALOGCODE)m_pFunctionPointer[ID_PP100_GETAUDIOCATALOGCODE])(pJobID , pAudioCatalogCode);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetAudioPerformer(wchar_t pJobID[41] , wchar_t pAudioPerformer[129])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETAUDIOPERFORMER])
	{
		lRet = ((PP100_SETAUDIOPERFORMER)m_pFunctionPointer[ID_PP100_SETAUDIOPERFORMER])(pJobID , pAudioPerformer);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetAudioPerformer(wchar_t pJobID[41] , wchar_t pAudioPerformer[129])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETAUDIOPERFORMER])
	{
		lRet = ((PP100_GETAUDIOPERFORMER)m_pFunctionPointer[ID_PP100_GETAUDIOPERFORMER])(pJobID , pAudioPerformer);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetLabel(wchar_t pJobID[41] , wchar_t pLabel[256])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETLABEL])
	{
		lRet = ((PP100_SETLABEL)m_pFunctionPointer[ID_PP100_SETLABEL])(pJobID , pLabel);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetLabel(wchar_t pJobID[41] , wchar_t pLabel[256])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETLABEL])
	{
		lRet = ((PP100_GETLABEL)m_pFunctionPointer[ID_PP100_GETLABEL])(pJobID , pLabel);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetLabelType(wchar_t pJobID[41] , unsigned long ulLabelType)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETLABELTYPE])
	{
		lRet = ((PP100_SETLABELTYPE)m_pFunctionPointer[ID_PP100_SETLABELTYPE])(pJobID , ulLabelType);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetLabelType(wchar_t pJobID[41] , unsigned long* pLabelType)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETLABELTYPE])
	{
		lRet = ((PP100_GETLABELTYPE)m_pFunctionPointer[ID_PP100_GETLABELTYPE])(pJobID , pLabelType);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetReplaceFieldText(wchar_t pJobID[41] , PP100_REPLACE_FIELD_TEXT pReplaceFieldText[] , unsigned long ulReplaceFieldTextNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETREPLACEFIELDTEXT])
	{
		lRet = ((PP100_SETREPLACEFIELDTEXT)m_pFunctionPointer[ID_PP100_SETREPLACEFIELDTEXT])(pJobID , pReplaceFieldText , ulReplaceFieldTextNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_AddReplaceFieldText(wchar_t pJobID[41] , PP100_REPLACE_FIELD_TEXT pReplaceFieldText[] , unsigned long ulReplaceFieldTextNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_ADDREPLACEFIELDTEXT])
	{
		lRet = ((PP100_ADDREPLACEFIELDTEXT)m_pFunctionPointer[ID_PP100_ADDREPLACEFIELDTEXT])(pJobID , pReplaceFieldText , ulReplaceFieldTextNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_DeleteReplaceFieldText(wchar_t pJobID[41] , PP100_REPLACE_FIELD_TEXT pReplaceFieldText[] , unsigned long ulReplaceFieldTextNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_DELETEREPLACEFIELDTEXT])
	{
		lRet = ((PP100_DELETEREPLACEFIELDTEXT)m_pFunctionPointer[ID_PP100_DELETEREPLACEFIELDTEXT])(pJobID , pReplaceFieldText , ulReplaceFieldTextNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetReplaceFieldText(wchar_t pJobID[41] , PP100_REPLACE_FIELD_TEXT pReplaceFieldText[] , unsigned long* pReplaceFieldTextNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETREPLACEFIELDTEXT])
	{
		lRet = ((PP100_GETREPLACEFIELDTEXT)m_pFunctionPointer[ID_PP100_GETREPLACEFIELDTEXT])(pJobID , pReplaceFieldText , pReplaceFieldTextNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetReplaceFieldBinary(wchar_t pJobID[41] , PP100_REPLACE_FIELD_BINARY pReplaceFieldBinary[] , unsigned long ulReplaceFieldBinaryNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETREPLACEFIELDBINARY])
	{
		lRet = ((PP100_SETREPLACEFIELDBINARY)m_pFunctionPointer[ID_PP100_SETREPLACEFIELDBINARY])(pJobID , pReplaceFieldBinary , ulReplaceFieldBinaryNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_AddReplaceFieldBinary(wchar_t pJobID[41] , PP100_REPLACE_FIELD_BINARY pReplaceFieldBinary[] , unsigned long ulReplaceFieldBinaryNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_ADDREPLACEFIELDBINARY])
	{
		lRet = ((PP100_ADDREPLACEFIELDBINARY)m_pFunctionPointer[ID_PP100_ADDREPLACEFIELDBINARY])(pJobID , pReplaceFieldBinary , ulReplaceFieldBinaryNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_DeleteReplaceFieldBinary(wchar_t pJobID[41] , PP100_REPLACE_FIELD_BINARY pReplaceFieldBinary[] , unsigned long ulReplaceFieldBinaryNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_DELETEREPLACEFIELDBINARY])
	{
		lRet = ((PP100_DELETEREPLACEFIELDBINARY)m_pFunctionPointer[ID_PP100_DELETEREPLACEFIELDBINARY])(pJobID , pReplaceFieldBinary , ulReplaceFieldBinaryNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetReplaceFieldBinary(wchar_t pJobID[41] , PP100_REPLACE_FIELD_BINARY pReplaceFieldBinary[] , unsigned long* pReplaceFieldBinaryNum)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETREPLACEFIELDBINARY])
	{
		lRet = ((PP100_GETREPLACEFIELDBINARY)m_pFunctionPointer[ID_PP100_GETREPLACEFIELDBINARY])(pJobID , pReplaceFieldBinary , pReplaceFieldBinaryNum);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetLabelArea(wchar_t pJobID[41] , unsigned long ulDiscDiamOut , unsigned long ulDiscDiamIn)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETLABELAREA])
	{
		lRet = ((PP100_SETLABELAREA)m_pFunctionPointer[ID_PP100_SETLABELAREA])(pJobID , ulDiscDiamOut , ulDiscDiamIn);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetLabelArea(wchar_t pJobID[41] , unsigned long* pDiscDiamOut , unsigned long* pDiscDiamIn)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETLABELAREA])
	{
		lRet = ((PP100_GETLABELAREA)m_pFunctionPointer[ID_PP100_GETLABELAREA])(pJobID , pDiscDiamOut , pDiscDiamIn);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetPrintMode(wchar_t pJobID[41] , unsigned long ulPrintMode)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETPRINTMODE])
	{
		lRet = ((PP100_SETPRINTMODE)m_pFunctionPointer[ID_PP100_SETPRINTMODE])(pJobID , ulPrintMode);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetPrintMode(wchar_t pJobID[41] , unsigned long* pPrintMode)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETPRINTMODE])
	{
		lRet = ((PP100_GETPRINTMODE)m_pFunctionPointer[ID_PP100_GETPRINTMODE])(pJobID , pPrintMode);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetPlugInID(wchar_t pJobID[41] , wchar_t pPlugInId[41])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETPLUGINID])
	{
		lRet = ((PP100_SETPLUGINID)m_pFunctionPointer[ID_PP100_SETPLUGINID])(pJobID , pPlugInId);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetPlugInID(wchar_t pJobID[41] , wchar_t pPlugInId[41])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETPLUGINID])
	{
		lRet = ((PP100_GETPLUGINID)m_pFunctionPointer[ID_PP100_GETPLUGINID])(pJobID , pPlugInId);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetPlugInParameter(wchar_t pJobID[41] , wchar_t pPlugInParameter[1025])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETPLUGINPARAMETER])
	{
		lRet = ((PP100_SETPLUGINPARAMETER)m_pFunctionPointer[ID_PP100_SETPLUGINPARAMETER])(pJobID , pPlugInParameter);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetPlugInParameter(wchar_t pJobID[41] , wchar_t pPlugInParameter[1025])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETPLUGINPARAMETER])
	{
		lRet = ((PP100_GETPLUGINPARAMETER)m_pFunctionPointer[ID_PP100_GETPLUGINPARAMETER])(pJobID , pPlugInParameter);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetPriority(wchar_t pJobID[41] , unsigned long ulPriority)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETPRIORITY])
	{
		lRet = ((PP100_SETPRIORITY)m_pFunctionPointer[ID_PP100_SETPRIORITY])(pJobID , ulPriority);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetPriority(wchar_t pJobID[41] , unsigned long* pPriority)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETPRIORITY])
	{
		lRet = ((PP100_GETPRIORITY)m_pFunctionPointer[ID_PP100_GETPRIORITY])(pJobID , pPriority);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetMeasure(wchar_t pJobID[41] , unsigned long ulMeasure)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETMEASURE])
	{
		lRet = ((PP100_SETMEASURE)m_pFunctionPointer[ID_PP100_SETMEASURE])(pJobID , ulMeasure);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetMeasure(wchar_t pJobID[41] , unsigned long* pMeasure)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETMEASURE])
	{
		lRet = ((PP100_GETMEASURE)m_pFunctionPointer[ID_PP100_GETMEASURE])(pJobID , pMeasure);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_SetArchiveDiscOnly(wchar_t pJobID[41] , unsigned long ulArchiveDiscOnly)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_SETARCHIVEDISCONLY])
	{
		lRet = ((PP100_SETARCHIVEDISCONLY)m_pFunctionPointer[ID_PP100_SETARCHIVEDISCONLY])(pJobID , ulArchiveDiscOnly);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_GetArchiveDiscOnly(wchar_t pJobID[41] , unsigned long* pArchiveDiscOnly)
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_GETARCHIVEDISCONLY])
	{
		lRet = ((PP100_GETARCHIVEDISCONLY)m_pFunctionPointer[ID_PP100_GETARCHIVEDISCONLY])(pJobID , pArchiveDiscOnly);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_ConvertErrorCodeToString(unsigned long ulErrorCode , wchar_t pErrorCode[1025])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_CONVERTERRORCODETOSTRING])
	{
		lRet = ((PP100_CONVERTERRORCODETOSTRING)m_pFunctionPointer[ID_PP100_CONVERTERRORCODETOSTRING])(ulErrorCode , pErrorCode);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

long CPP100APIManager::PP100_ConvertInformationCodeToString(unsigned long ulInformationCode , wchar_t pInformationCode[1025])
{
	long lRet = PP100API_SUCCESS;

	if(NULL != m_pFunctionPointer[ID_PP100_CONVERTINFORMATIONCODETOSTRING])
	{
		lRet = ((PP100_CONVERTINFORMATIONCODETOSTRING)m_pFunctionPointer[ID_PP100_CONVERTINFORMATIONCODETOSTRING])(ulInformationCode , pInformationCode);
	}
	else
	{
		lRet = PP100API_FAILURE;
	}

	return lRet;
}

INT CPP100APIManager::LoadPP100API()
{
	INT nRet = ERROR_SUCCESS;

	TCHAR tcDLLPath[MAX_PATH];
	HRESULT hResult;
	hResult = SHGetFolderPath(NULL, CSIDL_PROGRAM_FILES, NULL, 0, tcDLLPath);
	if(S_OK != hResult)
	{
		nRet = ::GetLastError();
	}

	_tcscat(tcDLLPath, PP100API_DLL);

	m_hPP100APIDLL = ::LoadLibrary(tcDLLPath);
	if(NULL != m_hPP100APIDLL)
	{
		// Get all function pointer which PP100API.dll exports
		nRet = GetAllFunctionAddress(m_hPP100APIDLL);

		if(ERROR_SUCCESS != nRet)
		{
			nRet = ::GetLastError();
		}
		else
		{
		}
	}
	else
	{
		nRet = ::GetLastError();
	}

	return nRet;
}

INT CPP100APIManager::FreePP100API()
{
	INT nRet = ERROR_SUCCESS;

	if(NULL != m_hPP100APIDLL)
	{
		::FreeLibrary(m_hPP100APIDLL);
		m_hPP100APIDLL = NULL;
	}

	return nRet;
}

INT CPP100APIManager::GetAllFunctionAddress(HMODULE hModule)
{
	INT nRet = ERROR_SUCCESS;

	// Get all function pointer
	// If fail, all function pointer will be set to NULL value
	for(int i = 0;i < NUM_PP100_API;i++)
	{
		m_pFunctionPointer[i] = ::GetProcAddress(hModule , pFunctionName[i]);
		if(NULL == m_pFunctionPointer[i])
		{
			nRet = ::GetLastError();
			InitializeFunctionPointer();
			break;
		}
	}

	return nRet;
}

void CPP100APIManager::InitializeFunctionPointer()
{
	// All function pointer will be set to NULL value
	for(int i = 0;i < NUM_PP100_API;i++)
	{
		m_pFunctionPointer[i] = NULL;
	}
}