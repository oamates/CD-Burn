//=============================================================================
//	Step2
//
//	FileName	:	PP100APISampleStep2.cpp
//	Contents	:	Connecting PC that TDBridge is running PP-100 Series API sample application.
//	Language	:	C++
//	Copyright	:	Copyright(C) SEIKO EPSON CORPORATION 2010. All rights reserved.
//	Note		:	
//	 1.Outline
//	  Initialize, connect to PC, disconnect from PC, destroy, and output it return value to the console.
//	 2.Process
//	 (1)Initialize PP-100 Series API. 
//		PP100_Initialize()
//	 (2)Connect to PC that TDBridge is running. 
//		PP100_ConnectServer()
//	 (3)Disconnect from PC that TDBridge is running. 
//		PP100_DisconnectServer()
//	 (4)Release PP-100 Series API.
//		PP100_Destroy()
//	CommandLine	:	PP100APISampleStep2
//=============================================================================

//=============================================================================
//	include files (#include)
//=============================================================================
#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include <shfolder.h>
#include "PP100API.h"

//=============================================================================
//	global variables
//=============================================================================
// The full path of PP100API.dll.
// If you changed the installation folder of EPSON TD Bridge, you need to changed the value.
TCHAR g_pPP100APIDLL[] = _T("\\EPSON\\TDBridge\\API\\PP100API.dll");
HMODULE g_hPP100APIDLL = NULL;
PP100_INITIALIZE g_pPP100_Initialize = NULL;
PP100_DESTROY g_pPP100_Destroy = NULL;
PP100_CONNECTSERVER g_pPP100_ConnectServer = NULL;
PP100_DISCONNECTSERVER g_pPP100_DisconnectServer = NULL;

//=============================================================================
//	global functions
//=============================================================================
int LoadPP100API(); // Load PP-100 Series API and get function pointers.

//=============================================================================
//	main
//
//	(1)Initialize PP-100 Series API. 
//		PP100_Initialize()
//	(2)Connect to PC that TDBridge is running. 
//		PP100_ConnectServer()
//	(3)Disconnect from PC that TDBridge is running. 
//		PP100_DisconnectServer()
//	(4)Release PP-100 Series API.
//		PP100_Destroy()
//	
//	IN  : argc		- Number of input parameter.
//		  argv		- Pointer to input paraemter.
//	OUT : 
//
//	Return : void
//=============================================================================
void main(int argc, char *argv[])
{
	int nRet = LoadPP100API();
	printf("LoadPP100API() returns %d\n", nRet);
	if(0 != nRet)
	{
		printf("Loading PP-100 Series API failed.\n");
		return;
	}

	//=========================================================================
	// (1)Initialize PP100 Series API.
	//=========================================================================
	nRet = g_pPP100_Initialize();
	printf("PP100_Initialize() returns %d\n", nRet);
	if(PP100API_SUCCESS != nRet)
	{
		printf("Initializing PP-100 Series API failed.\n");
		return;
	}

	//=========================================================================
	// (2)Connect to PC that TDBridge is running.
	//    This sample sets pHost : 127.0.0.1 , pOrderFolder : Orders
	//    i.e. \\127.0.0.1\Orders is full path of monitoring folder.
	//    If pHost is NULL, PP-100 Series API assume that local PC specified, and ignore pOrderFolder parameter.
	//=========================================================================
	unsigned long ulHandle = 0;
	nRet = g_pPP100_ConnectServer(L"127.0.0.1" , L"Orders" , &ulHandle);
	printf("PP100_ConnectServer() returns %d\n", nRet);
	printf("ulHandle is %u\n", ulHandle);
	if(PP100API_SUCCESS != nRet)
	{
		printf("Connecting to PC that TDBridge is running failed.\n");
		return;
	}

	//=========================================================================
	// (3)Disconnecting from PC that TDBridge is running.
	//=========================================================================
	nRet = g_pPP100_DisconnectServer(ulHandle);
	printf("PP100_DisconnectServer() returns %d\n", nRet);
	if(PP100API_SUCCESS != nRet)
	{
		printf("Disconnecting from PC that TDBridge is running failed.\n");
		return;
	}

	//=========================================================================
	// (4)Release PP100 Series API.
	//=========================================================================
	nRet = g_pPP100_Destroy();
	printf("PP100_Destroy() returns %d\n", nRet);
	if(PP100API_SUCCESS != nRet)
	{
		printf("Destroying PP-100 Series API failed.\n");
		return;
	}

	return;
}

//=============================================================================
//	LoadPP100API
//	
//	(1)Load PP-100 Series API and get function pointers.
//
//	IN  :
//	OUT :
//
//	Return :	0	- success
//				1	- failure
//=============================================================================
int LoadPP100API()
{
	// Load PP100API.dll

	TCHAR tcDLLPath[MAX_PATH];
	HRESULT hResult;
	hResult = SHGetFolderPath(NULL, CSIDL_PROGRAM_FILES, NULL, 0, tcDLLPath);
	if(S_OK != hResult)
	{
		printf("Loading PP-100 Series API failed.\n");
		return 1;
	}

	_tcscat(tcDLLPath, g_pPP100APIDLL);

	g_hPP100APIDLL = ::LoadLibrary(tcDLLPath);
	if(NULL == g_hPP100APIDLL)
	{
		printf("Loading PP-100 Series API failed.\n");
		return 1;
	}

	// Get function pointer of PP100_Initialize() and PP100_Destroy()
	g_pPP100_Initialize = (PP100_INITIALIZE)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_INITIALIZE);
	g_pPP100_Destroy = (PP100_DESTROY)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_DESTROY);
	g_pPP100_ConnectServer = (PP100_CONNECTSERVER)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_CONNECTSERVER);
	g_pPP100_DisconnectServer = (PP100_DISCONNECTSERVER)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_DISCONNECTSERVER);
	if(	NULL == g_pPP100_Initialize || 
		NULL == g_pPP100_Destroy || 
		NULL == g_pPP100_ConnectServer || 
		NULL == g_pPP100_DisconnectServer)
	{
		printf("Getting function address failed.\n");
		return 1;
	}

	return 0;
}