﻿using System;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using EPSON.PP100.API;

namespace PP100APISample
{

    public partial class FormPP100APISampleCSharp : Form
    {
        DataTable serverTable = new DataTable();

        public FormPP100APISampleCSharp()
        {
            InitializeComponent();
            Function.PP100_Initialize();
        }

        private void FormPP100APISampleCSharp_FormClosed(object sender, FormClosedEventArgs e)
        {
            DataRowCollection rows = serverTable.Rows;
            foreach (DataRow row in rows)
            {
                try
                {
                    Function.PP100_DisConnectServer(UInt32.Parse(row.ItemArray.GetValue(0).ToString()));
                }
                catch (FormatException ex)
                {
                }
            }
        }

        private void FormPP100APISampleCSharp_Load(object sender, EventArgs e)
        {
            serverTable.Columns.Add("HANDLE", typeof(string));
            serverTable.Columns.Add("ADDRESS", typeof(string));
            comboBoxServerHandle.DataSource = serverTable;
            comboBoxServerHandle.DisplayMember = "ADDRESS";
            comboBoxServerHandle.ValueMember = "HANDLE";

            this.buttonEnumeratePublishers.Enabled = false;
            this.buttonGetJobStatus.Enabled = false;
            this.buttonGetPublisherStatus.Enabled = false;
            this.buttonSubmitJob.Enabled = false;
            this.buttonCancenJob.Enabled = false;
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            int iRet = (int)Define.ReturnValue.PP100API_SUCCESS;
            uint uiServerHandle = 0;

            iRet = Function.PP100_ConnectServer((0 == textBoxHost2.Text.Length) ? null : textBoxHost2.Text,
                                        (0 == textBoxOrderFolder2.Text.Length) ? null : textBoxOrderFolder2.Text,
                                        ref uiServerHandle);

            if ((int)Define.ReturnValue.PP100API_SUCCESS == iRet)
            {
                textBoxResult.Text += "PP100_ConnectServer(" + textBoxHost2.Text + " , " + textBoxOrderFolder2.Text + ") returns PP100API_SUCCESS\r\n";
                if (-1 == comboBoxServerHandle.FindString(uiServerHandle + "(" + textBoxHost2.Text + " , " + textBoxOrderFolder2.Text + ")"))
                {
                    DataRow row = serverTable.NewRow();
                    row["HANDLE"] = uiServerHandle;
                    row["ADDRESS"] = uiServerHandle + "(" + textBoxHost2.Text + " , " + textBoxOrderFolder2.Text + ")";
                    serverTable.Rows.Add(row);
                    serverTable.AcceptChanges();
                }
                if (0 != comboBoxServerHandle.Text.Length)
                {
                    buttonEnumeratePublishers.Enabled = true;
                    buttonGetJobStatus.Enabled = true;
                    buttonCancenJob.Enabled = true;
                }
                if (-1 != comboBoxServerHandle.FindString(uiServerHandle + "(" + textBoxHost2.Text + " , " + textBoxOrderFolder2.Text + ")"))
                {
                    comboBoxServerHandle.SelectedValue = uiServerHandle;
                }
            }
            else
            {
                textBoxResult.Text += "PP100_ConnectServer(" + textBoxHost2.Text + " , " + textBoxOrderFolder2.Text + ") returns " + iRet + "\r\n";
            }
            textBoxResult.Text += "\r\n";
            ScrollToLastLine();
        }

        private void buttonEnumeratePublishers_Click(object sender, EventArgs e)
        {
            int iRet = (int)Define.ReturnValue.PP100API_SUCCESS;
            if (0 != comboBoxServerHandle.Items.Count && 0 != comboBoxServerHandle.SelectedValue.ToString().Length)
            {
                uint uiEnumPubilsherInfoNum = 0;

                iRet = Function.PP100_EnumPublishers(UInt32.Parse(comboBoxServerHandle.SelectedValue.ToString()), null, ref uiEnumPubilsherInfoNum);
                if (0 < uiEnumPubilsherInfoNum)
                {
                    Struct.PP100_ENUM_PUBLISHER_INFO[] enumPublisher = new Struct.PP100_ENUM_PUBLISHER_INFO[uiEnumPubilsherInfoNum];

                    iRet = Function.PP100_EnumPublishers(UInt32.Parse(comboBoxServerHandle.SelectedValue.ToString()), enumPublisher, ref uiEnumPubilsherInfoNum);
                    if ((int)Define.ReturnValue.PP100API_SUCCESS == iRet)
                    {
                        textBoxResult.Text += "PP100_EnumPublishers(" + comboBoxServerHandle.SelectedValue.ToString() + ") returns PP100API_SUCCESS\r\n";
                        comboBoxPublishers3.Items.Clear();
                        comboBoxPublishers3.BeginUpdate();
                        for (uint ui = 0; ui < enumPublisher.Length; ui++)
                        {
                            comboBoxPublishers3.Items.Add(enumPublisher[ui].pPublisherName);

                            textBoxResult.Text += "\r\n";

                            textBoxResult.Text += "enumPublisher[" + ui + "].pPublisherName : " + enumPublisher[ui].pPublisherName + "\r\n";
                            textBoxResult.Text += "enumPublisher[" + ui + "].uiDriveNumber : " + enumPublisher[ui].uiDriveNumber + "\r\n";
                            textBoxResult.Text += "enumPublisher[" + ui + "].uiConnectType : " + enumPublisher[ui].uiConnectType + "\r\n";
                        }
                        comboBoxPublishers3.EndUpdate();
                        if (0 != comboBoxPublishers3.Items.Count)
                        {
                            comboBoxPublishers3.SelectedIndex = 0;
                            buttonGetPublisherStatus.Enabled = true;
                            buttonSubmitJob.Enabled = true;
                        }
                    }
                    else
                    {
                        textBoxResult.Text += "PP100_EnumPublishers(" + comboBoxServerHandle.SelectedValue.ToString() + ") returns " + iRet + "\r\n";
                    }
                }
            }
            textBoxResult.Text += "\r\n";
            ScrollToLastLine();
        }

        private void buttonGetPublisherStatus_Click(object sender, EventArgs e)
        {
            int iRet = (int)Define.ReturnValue.PP100API_SUCCESS;
            if (0 != comboBoxServerHandle.SelectedValue.ToString().Length)
            {
                Struct.PP100_PUBLISHER_STATUS status = new Struct.PP100_PUBLISHER_STATUS();

                iRet = Function.PP100_GetPublisherStatus(UInt32.Parse(comboBoxServerHandle.SelectedValue.ToString()), comboBoxPublishers3.Text, ref status);
                if ((int)Define.ReturnValue.PP100API_SUCCESS == iRet)
                {
                    textBoxResult.Text += "PP100_GetPublisherStatus(" + comboBoxServerHandle.SelectedValue.ToString() + ") returns PP100API_SUCCESS\r\n";

                    for (uint ui = 0; ui < status.uiINFORMATIONCode.Length; ui++)
                    {
                        if (0 == status.uiINFORMATIONCode[ui])
                        {
                            break;
                        }
                        textBoxResult.Text += "status.uiINFORMATIONCode[" + ui + "] : " + status.uiINFORMATIONCode[ui] + "\r\n";
                    }
                    textBoxResult.Text += "status.uiMode : " + status.uiMode + "\r\n";
                    for (uint ui = 0; ui < status.uiDriveStatus.Length; ui++)
                    {
                        textBoxResult.Text += "status.uiDriveStatus[" + ui + "] : " + status.uiDriveStatus[ui] + "\r\n";
                    }
                    textBoxResult.Text += "status.pDrive1PluginName : " + status.pDrive1PluginName + "\r\n";
                    textBoxResult.Text += "status.pDrive2PluginName : " + status.pDrive2PluginName + "\r\n";
                    for (uint ui = 0; ui < status.uiDriveLife.Length; ui++)
                    {
                        textBoxResult.Text += "status.uiDriveLife[" + ui + "] : " + status.uiDriveLife[ui] + "\r\n";
                    }
                    textBoxResult.Text += "status.uiPrinterStatus : " + status.uiPrinterStatus + "\r\n";
                    textBoxResult.Text += "status.uiCyan : " + status.stInkStatus.uiCyan + "\r\n";
                    textBoxResult.Text += "status.uiMagenta : " + status.stInkStatus.uiMagenta + "\r\n";
                    textBoxResult.Text += "status.uiYellow : " + status.stInkStatus.uiYellow + "\r\n";
                    textBoxResult.Text += "status.uiLightCyan : " + status.stInkStatus.uiLightCyan + "\r\n";
                    textBoxResult.Text += "status.uiLightMagenta : " + status.stInkStatus.uiLightMagenta + "\r\n";
                    textBoxResult.Text += "status.uiBlack : " + status.stInkStatus.uiBlack + "\r\n";
                    for (uint ui = 0; ui < status.uiStackerSetting.Length; ui++)
                    {
                        textBoxResult.Text += "status.uiStackerSetting[" + ui + "] : " + status.uiStackerSetting[ui] + "\r\n";
                    }
                    for (uint ui = 0; ui < status.uiStackerRest.Length; ui++)
                    {
                        textBoxResult.Text += "status.uiStackerRest[" + ui + "] : " + status.uiStackerRest[ui] + "\r\n";
                    }
                    textBoxResult.Text += "status.uiPrintableCopies : " + status.uiPrintableCopies + "\r\n";
                    textBoxResult.Text += "status.uiPrintedCopies : " + status.uiPrintedCopies + "\r\n";
                    textBoxResult.Text += "status.uiMaintenanceBoxFreeSpace : " + status.uiMaintenanceBoxFreeSpace + "\r\n";
                    textBoxResult.Text += "status.pSerialNumber : " + status.pSerialNumber + "\r\n";
                    for (uint ui = 0; ui < status.uiDriveProgress.Length; ui++)
                    {
                        textBoxResult.Text += "status.uiDriveProgress[" + ui + "] : " + status.uiDriveProgress[ui] + "\r\n";
                    }
                    textBoxResult.Text += "status.uiCompleteDiscNum : " + status.uiCompleteDiscNum + "\r\n";
                    textBoxResult.Text += "status.uiUsbConnectionMode : " + status.uiUsbConnectionMode + "\r\n";
                }
                else
                {
                    textBoxResult.Text += "PP100_GetPublisherStatus(" + comboBoxServerHandle.SelectedValue.ToString() + ") returns " + iRet + "\r\n";
                }
            }
            textBoxResult.Text += "\r\n";
            ScrollToLastLine();
        }

        private void buttonSubmitJob_Click(object sender, EventArgs e)
        {
            int iRet = (int)Define.ReturnValue.PP100API_SUCCESS;
            if (0 != comboBoxServerHandle.SelectedValue.ToString().Length)
            {
                StringBuilder pJobID = new StringBuilder(65);

                iRet = Function.PP100_CreateJob(pJobID);
                iRet = Function.PP100_SetDiscType(pJobID, (uint)Define.DiscType.PP100API_CD);
                iRet = Function.PP100_SetPublisher(pJobID, new StringBuilder(this.comboBoxPublishers3.Text));
                Struct.PP100_WRITE_DATA[] writeData1 = new Struct.PP100_WRITE_DATA[1];
                writeData1[0].pSourceData = System.IO.Path.Combine(Environment.SystemDirectory, "NOTEPAD.EXE");
                writeData1[0].pDestinationData = "note\\NOTEPAD.EXE";
                iRet = Function.PP100_SetData(pJobID, writeData1, 1);
                iRet = Function.PP100_SubmitJob(UInt32.Parse(comboBoxServerHandle.SelectedValue.ToString()), pJobID, false);
                if ((int)Define.ReturnValue.PP100API_SUCCESS == iRet)
                {
                    textBoxResult.Text += "PP100_SubmitJob(" + comboBoxServerHandle.SelectedValue.ToString() + ") returns PP100API_SUCCESS\r\n";
                }
                else
                {
                    textBoxResult.Text += "PP100_SubmitJob(" + comboBoxServerHandle.SelectedValue.ToString() + ") returns " + iRet + "\r\n";
                }
            }
            textBoxResult.Text += "\r\n";
            ScrollToLastLine();
        }

        private void buttonGetCreatedJobList_Click(object sender, EventArgs e)
        {
            int iRet = (int)Define.ReturnValue.PP100API_SUCCESS;
            uint uiJobIDNum = 0;

            iRet = Function.PP100_GetCreatedJobList(null, ref uiJobIDNum);
            if (0 < uiJobIDNum)
            {
                string[] pJobIDList = new string[uiJobIDNum];
                for (uint ui = 0; ui < uiJobIDNum; ui++)
                {
                    pJobIDList[ui] = "1234567890123456789012345678901234567890";
                }

                iRet = Function.PP100_GetCreatedJobList(pJobIDList, ref uiJobIDNum);
                if ((int)Define.ReturnValue.PP100API_SUCCESS == iRet)
                {
                    textBoxResult.Text += "PP100_GetCreatedJobList() returns PP100API_SUCCESS\r\n";

                    comboBoxJobID.BeginUpdate();
                    comboBoxJobID.Items.Clear();
                    foreach (string s in pJobIDList)
                    {
                        comboBoxJobID.Items.Add(s);
                    }
                    if (0 != comboBoxJobID.Items.Count)
                    {
                        comboBoxJobID.SelectedIndex = 0;
                    }
                    comboBoxJobID.EndUpdate();
                }
                else
                {
                    textBoxResult.Text += "PP100_GetCreatedJobList() returns " + iRet + "\r\n";
                }
            }
            else
            {
                textBoxResult.Text += "PP100_GetCreatedJobList() returns PP100API_SUCCESS\r\n";
            }
            textBoxResult.Text += "\r\n";
            ScrollToLastLine();
        }

        private void buttonGetJobStatus_Click(object sender, EventArgs e)
        {
            int iRet = (int)Define.ReturnValue.PP100API_MORE_ITEMS;
            if (0 != comboBoxServerHandle.SelectedValue.ToString().Length)
            {
                uint uiJobStatusNum = 0;
                StringBuilder pJobID;
                while ((int)Define.ReturnValue.PP100API_MORE_ITEMS == iRet)
                {
                    if (0 != comboBoxJobID.Text.Length)
                    {
                        uiJobStatusNum = 1;
                        pJobID = new StringBuilder(comboBoxJobID.Text);
                    }
                    else
                    {
                        Function.PP100_GetJobStatus(UInt32.Parse(comboBoxServerHandle.SelectedValue.ToString()), null, null, ref uiJobStatusNum);
                        pJobID = null;
                    }
                    Struct.PP100_JOB_STATUS[] jobStatus = new Struct.PP100_JOB_STATUS[uiJobStatusNum];
                    
                    iRet = Function.PP100_GetJobStatus(UInt32.Parse(comboBoxServerHandle.SelectedValue.ToString()), pJobID, jobStatus, ref uiJobStatusNum);
                    if ((int)Define.ReturnValue.PP100API_SUCCESS == iRet)
                    {
                        textBoxResult.Text += "PP100_GetJobStatus(" + comboBoxServerHandle.SelectedValue.ToString() + ") returns PP100API_SUCCESS\r\n";

                        for (uint ui = 0; ui < jobStatus.Length; ui++)
                        {
                            textBoxResult.Text += "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].pJobID : " + jobStatus[ui].pJobID + "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].pPublisherName : " + jobStatus[ui].pPublisherName + "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].uiJobStatus : " + jobStatus[ui].uiJobStatus + "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].uiErrorCode : " + jobStatus[ui].uiErrorCode + "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].uiPublicationNumber : " + jobStatus[ui].uiPublicationNumber + "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].uiCompletionNumber : " + jobStatus[ui].uiCompletionNumber + "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].uiJobType : " + jobStatus[ui].uiJobType + "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].uiSource : " + jobStatus[ui].uiSource + "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].uiDestination : " + jobStatus[ui].uiDestination + "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].uiJobIndex : " + jobStatus[ui].uiJobIndex + "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].uiEstimateTime : " + jobStatus[ui].uiEstimateTime + "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].uiRemainingEstimateTime : " + jobStatus[ui].uiRemainingEstimateTime + "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].uiErrorNumber : " + jobStatus[ui].uiErrorNumber + "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].uiMode : " + jobStatus[ui].uiMode + "\r\n";
                            textBoxResult.Text += "jobStatus[" + ui + "].bySumbittedByTotalDiscMaker : " + jobStatus[ui].bySumbittedByTotalDiscMaker + "\r\n";
                        }
                    }
                    else
                    {
                        textBoxResult.Text += "PP100_GetJobStatus(" + comboBoxServerHandle.SelectedValue.ToString() + ") returns " + iRet + "\r\n";
                    }
                }
            }
            textBoxResult.Text += "\r\n";
            ScrollToLastLine();
        }
        
        private void buttonClearText_Click(object sender, EventArgs e)
        {
            textBoxResult.Text = "";
        }

        private void buttonCancelJob_Click(object sender, EventArgs e)
        {
            int iRet = (int)Define.ReturnValue.PP100API_SUCCESS;
            if (0 != comboBoxServerHandle.SelectedValue.ToString().Length)
            {
                iRet = Function.PP100_CancelJob(UInt32.Parse(comboBoxServerHandle.SelectedValue.ToString()), new StringBuilder(comboBoxJobID.Text));
                if ((int)Define.ReturnValue.PP100API_SUCCESS == iRet)
                {
                    textBoxResult.Text += "PP100_CancelJob(" + comboBoxServerHandle.SelectedValue.ToString() + ") returns PP100API_SUCCESS\r\n";
                }
                else
                {
                    textBoxResult.Text += "PP100_CancelJob(" + comboBoxServerHandle.SelectedValue.ToString() + ") returns " + iRet + "\r\n";
                }
            }
            textBoxResult.Text += "\r\n";
            ScrollToLastLine();
        }

        private void ScrollToLastLine()
        {
            this.textBoxResult.SelectionStart = this.textBoxResult.Text.Length;
            this.textBoxResult.Focus();
            this.textBoxResult.ScrollToCaret();
        }
    }
}
