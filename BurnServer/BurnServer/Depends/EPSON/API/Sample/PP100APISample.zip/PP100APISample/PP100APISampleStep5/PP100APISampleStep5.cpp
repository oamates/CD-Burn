//=============================================================================
//	Step2
//
//	FileName	:	PP100APISampleStep5.cpp
//	Contents	:	Submit JOB and cancel JOB PP-100 Series API sample application.
//	Language	:	C++
//	Copyright	:	Copyright(C) SEIKO EPSON CORPORATION 2010. All rights reserved.
//	Note		:	
//	 1.Outline
//	  Initialize, connect to PC, submit JOB, cancel JOB, get JOB status, destroy, and output it return value to the console.
//	 2.Process
//	 (1)Initialize PP-100 Series API. 
//		PP100_Initialize()
//	 (2)Connect to PC that TDBridge is running. 
//		PP100_ConnectServer()
//	 (3)Create JOB and get JOB ID.Set JOB setting.Get JOB setting.
//		PP100_CreateJob(), PP100_SetDiscType(), PP100_GetDiscType(), PP100_SetData(), PP100_GetData()
//	 (4)Submit JOB.
//		PP100_SubmitJob()
//	 (5)Cancel JOB.
//		PP100_CancelJob()
//	 (6)Get JOB status.
//		PP100_GetJobStatus()
//	 (7)Disconnect from PC that TDBridge is running. 
//		PP100_DisconnectServer()
//	 (8)Release PP-100 Series API.
//		PP100_Destroy()
//	CommandLine	:	PP100APISampleStep5
//=============================================================================

//=============================================================================
//	include files (#include)
//=============================================================================
#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include <shfolder.h>
#include "PP100API.h"

//=============================================================================
//	global variables
//=============================================================================
// The full path of PP100API.dll.
// If you changed the installation folder of EPSON TD Bridge, you need to changed the value.
TCHAR g_pPP100APIDLL[] = _T("\\EPSON\\TDBridge\\API\\PP100API.dll");
HMODULE g_hPP100APIDLL = NULL;
PP100_INITIALIZE g_pPP100_Initialize = NULL;
PP100_DESTROY g_pPP100_Destroy = NULL;
PP100_CONNECTSERVER g_pPP100_ConnectServer = NULL;
PP100_DISCONNECTSERVER g_pPP100_DisconnectServer = NULL;
PP100_ENUMPUBLISHERS g_pPP100_EnumPublishers = NULL;
PP100_GETPUBLISHERSTATUS g_pPP100_GetPublisherStatus = NULL;
PP100_GETJOBSTATUS g_pPP100_GetJobStatus = NULL;
PP100_CREATEJOB g_pPP100_CreateJob = NULL;
PP100_SETDISCTYPE g_pPP100_SetDiscType = NULL;
PP100_GETDISCTYPE g_pPP100_GetDiscType = NULL;
PP100_SETDATA g_pPP100_SetData = NULL;
PP100_GETDATA g_pPP100_GetData = NULL;
PP100_SUBMITJOB g_pPP100_SubmitJob = NULL;
PP100_CANCELJOB g_pPP100_CancelJob = NULL;

//=============================================================================
//	global functions
//=============================================================================
int LoadPP100API(); // Load PP-100 Series API and get function pointers.
void DisplayEnumPublisherInfo(PP100_ENUM_PUBLISHER_INFO pEnumPublisherInfo[] , unsigned long ulEnumPublisherInfoNum); // Display PP100_ENUM_PUBLISHER_INFO.
void DisplayPublisherStatus(PP100_PUBLISHER_STATUS publisherStatus); // Display PP100_PUBLISHER_STATUS.
void DisplayJobStatus(PP100_JOB_STATUS pJobStatus[] , unsigned long ulJobStatusNum);	// Display PP100_JOB_STATUS.

//=============================================================================
//	main
//
//	(1)Initialize PP-100 Series API. 
//		PP100_Initialize()
//	(2)Connect to PC that TDBridge is running. 
//		PP100_ConnectServer()
//	(3)Create JOB and get JOB ID.Set JOB setting.Get JOB setting.
//		PP100_CreateJob(), PP100_SetDiscType(), PP100_GetDiscType(), PP100_SetData(), PP100_GetData()
//	(4)Submit JOB.
//		PP100_SubmitJob()
//	(5)Cancel JOB.
//		PP100_CancelJob()
//	(6)Get JOB status.
//		PP100_GetJobStatus()
//	(7)Disconnect from PC that TDBridge is running. 
//		PP100_DisconnectServer()
//	(8)Release PP-100 Series API.
//		PP100_Destroy()
//	
//	IN  : argc		- Number of input parameter.
//		  argv		- Pointer to input paraemter.
//	OUT : 
//
//	Return : void
//=============================================================================
void main(int argc, char *argv[])
{
	int nRet = LoadPP100API();
	printf("LoadPP100API() returns %d\n", nRet);
	if(0 != nRet)
	{
		printf("Loading PP-100 Series API failed.\n");
		return;
	}

	//=========================================================================
	// (1)Initialize PP100 Series API.
	//=========================================================================
	nRet = g_pPP100_Initialize();
	printf("PP100_Initialize() returns %d\n", nRet);
	if(PP100API_SUCCESS != nRet)
	{
		printf("Initializing PP-100 Series API failed.\n");
		return;
	}

	//=========================================================================
	// (2)Connect to PC that TDBridge is running.
	//    This sample sets pHost : 127.0.0.1 , pOrderFolder : Orders
	//    i.e. \\127.0.0.1\Orders is full path of monitoring folder.
	//    If pHost is NULL, PP-100 Series API assume that local PC specified, and ignore pOrderFolder parameter.
	//=========================================================================
	unsigned long ulHandle = 0;
	//nRet = g_pPP100_ConnectServer(L"127.0.0.1" , L"Orders" , &ulHandle);
	nRet = g_pPP100_ConnectServer(NULL , L"Orders" , &ulHandle);
	printf("PP100_ConnectServer() returns %d\n", nRet);
	printf("ulHandle is %u\n", ulHandle);
	if(PP100API_SUCCESS != nRet)
	{
		printf("Connecting to PC that TDBridge is running failed.\n");
		return;
	}

	//=========================================================================
	// (3)Create JOB and get JOB ID.Set JOB setting.Get JOB setting.
	//=========================================================================
	wchar_t pJobID[41] = {0};
	nRet = g_pPP100_CreateJob(pJobID);
	printf("PP100_CreateJob() returns %d\n", nRet);
	wprintf(L"pJobID is %s\n", pJobID);
	if(PP100API_SUCCESS == nRet)
	{
		// Set JOB setting.If necessary, call the function(PP100_SetPublisher(),PP100_SetCopies(), and so on)
		nRet = g_pPP100_SetDiscType(pJobID , PP100API_CD);
		printf("PP100_SetDiscType() returns %d\n", nRet);
		if(PP100API_SUCCESS == nRet)
		{
			unsigned long ulDiscType = PP100API_ERROR;
			nRet = g_pPP100_GetDiscType(pJobID , &ulDiscType);
			printf("PP100_GetDiscType() returns %d\n", nRet);
			printf("ulDiscType is %d\n", ulDiscType);
		}

		PP100_WRITE_DATA writeData = {0};
		wchar_t pFileName[256] = L"\\NOTEPAD.EXE";
		wchar_t pWindowsDirectory[256] = {0};
		GetWindowsDirectoryW(pWindowsDirectory, MAX_PATH);
		wprintf(L"pWindowsDirectory=%s\n" ,pWindowsDirectory);
		_tcscat(pWindowsDirectory, pFileName);
		wprintf(L"pWindowsDirectory=%s\n" ,pWindowsDirectory);

		::wcscpy_s(writeData.pSourceData , pWindowsDirectory);
		::wcscpy_s(writeData.pDestinationData , L"SAMPLE\\NOTEPAD.EXE");

		unsigned long ulWriteDataNum = 1;
		nRet = g_pPP100_SetData(pJobID , &writeData , ulWriteDataNum);
		printf("PP100_SetData() returns %d\n", nRet);
		if(PP100API_SUCCESS == nRet)
		{
			PP100_WRITE_DATA writeData2 = {0};
			nRet = g_pPP100_GetData(pJobID , &writeData2 , &ulWriteDataNum);
			printf("PP100_GetData() returns %d\n", nRet);
			wprintf(L"writeData2.pSourceData is %s , writeData2.pDestinationData is %s\n", writeData2.pSourceData , writeData2.pDestinationData);
		}
	}
	else
	{
		printf("Creating new JOB failed.\n");
		return;
	}

	//=========================================================================
	// (4)Submit JOB.
	//=========================================================================
	if(0 != wcslen(pJobID))
	{
		nRet = g_pPP100_SubmitJob(ulHandle , pJobID , true);
		printf("PP100_SubmitJob() returns %d\n", nRet);
	}

	//=========================================================================
	// (5)Cancel JOB.
	//=========================================================================
	if(0 != wcslen(pJobID))
	{
		nRet = g_pPP100_CancelJob(ulHandle , pJobID);
		printf("PP100_CancelJob() returns %d\n", nRet);
	}

	//=========================================================================
	// (6)Get JOB Status.
	//=========================================================================
	if(0 != wcslen(pJobID))
	{
		PP100_JOB_STATUS jobStatus = {0};
		unsigned long ulJobStatusNum = 1;
		nRet = g_pPP100_GetJobStatus(ulHandle , pJobID , &jobStatus , &ulJobStatusNum);
		printf("PP100_GetJobStatus() returns %d\n", nRet);
		if(PP100API_SUCCESS == nRet)
		{
			DisplayJobStatus(&jobStatus , ulJobStatusNum);
		}
		else
		{
			printf("Getting JOB Status failed.\n");
		}
	}

	//=========================================================================
	// (7)Disconnecting from PC that TDBridge is running.
	//=========================================================================
	nRet = g_pPP100_DisconnectServer(ulHandle);
	printf("PP100_DisconnectServer() returns %d\n", nRet);
	if(PP100API_SUCCESS != nRet)
	{
		printf("Disconnecting from PC that TDBridge is running failed.\n");
		return;
	}

	//=========================================================================
	// (8)Release PP100 Series API.
	//=========================================================================
	nRet = g_pPP100_Destroy();
	printf("PP100_Destroy() returns %d\n", nRet);
	if(PP100API_SUCCESS != nRet)
	{
		printf("Destroying PP-100 Series API failed.\n");
		return;
	}

	return;
}

//=============================================================================
//	LoadPP100API
//	
//	(1)Load PP-100 Series API and get function pointers.
//
//	IN  :
//	OUT :
//
//	Return :	0	- success
//				1	- failure
//=============================================================================
int LoadPP100API()
{
	// Load PP100API.dll

	TCHAR tcDLLPath[MAX_PATH];
	HRESULT hResult;
	hResult = SHGetFolderPath(NULL, CSIDL_PROGRAM_FILES, NULL, 0, tcDLLPath);
	if(S_OK != hResult)
	{
		printf("Loading PP-100 Series API failed.\n");
		return 1;
	}

	_tcscat(tcDLLPath, g_pPP100APIDLL);

	g_hPP100APIDLL = ::LoadLibrary(tcDLLPath);
	if(NULL == g_hPP100APIDLL)
	{
		printf("Loading PP-100 Series API failed.\n");
		return 1;
	}

	// Get function pointer of PP100_Initialize() and PP100_Destroy()
	g_pPP100_Initialize = (PP100_INITIALIZE)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_INITIALIZE);
	g_pPP100_Destroy = (PP100_DESTROY)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_DESTROY);
	g_pPP100_ConnectServer = (PP100_CONNECTSERVER)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_CONNECTSERVER);
	g_pPP100_DisconnectServer = (PP100_DISCONNECTSERVER)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_DISCONNECTSERVER);
	g_pPP100_EnumPublishers = (PP100_ENUMPUBLISHERS)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_ENUMPUBLISHERS);
	g_pPP100_GetPublisherStatus = (PP100_GETPUBLISHERSTATUS)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_GETPUBLISHERSTATUS);
	g_pPP100_GetJobStatus = (PP100_GETJOBSTATUS)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_GETJOBSTATUS);
	g_pPP100_CreateJob = (PP100_CREATEJOB)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_CREATEJOB);
	g_pPP100_SetDiscType = (PP100_SETDISCTYPE)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_SETDISCTYPE);
	g_pPP100_GetDiscType = (PP100_GETDISCTYPE)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_GETDISCTYPE);
	g_pPP100_SetData = (PP100_SETDATA)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_SETDATA);
	g_pPP100_GetData = (PP100_GETDATA)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_GETDATA);
	g_pPP100_SubmitJob = (PP100_SUBMITJOB)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_SUBMITJOB);
	g_pPP100_CancelJob = (PP100_CANCELJOB)GetProcAddress(g_hPP100APIDLL , FNSTR_PP100_CANCELJOB);
	if(	NULL == g_pPP100_Initialize || 
		NULL == g_pPP100_Destroy || 
		NULL == g_pPP100_ConnectServer || 
		NULL == g_pPP100_DisconnectServer || 
		NULL == g_pPP100_EnumPublishers || 
		NULL == g_pPP100_GetPublisherStatus || 
		NULL == g_pPP100_GetJobStatus || 
		NULL == g_pPP100_CreateJob || 
		NULL == g_pPP100_SetDiscType || 
		NULL == g_pPP100_GetDiscType || 
		NULL == g_pPP100_SetData || 
		NULL == g_pPP100_GetData || 
		NULL == g_pPP100_SubmitJob || 
		NULL == g_pPP100_CancelJob)
	{
		printf("Getting function address failed.\n");
		return 1;
	}

	return 0;
}

//=============================================================================
//	DisplayEnumPublisherInfo
//	
//	(1)Display PP100_ENUM_PUBLISHER_INFO.
//
//	IN  : pEnumPublisherInfo		- Pointer to PP100_ENUM_PUBLISHER_INFO array.
//		  ulEnumPublisherInfoNum	- Number of array.
//	OUT : 
//
//	Return : void
//=============================================================================
void DisplayEnumPublisherInfo(PP100_ENUM_PUBLISHER_INFO pEnumPublisherInfo[] , unsigned long ulEnumPublisherInfoNum)
{
	for(unsigned long ul = 0;ul < ulEnumPublisherInfoNum;ul++)
	{
		wprintf(L"pEnumPublisherInfo[%u].pPublisherName is %s\n" , ul , pEnumPublisherInfo[ul].pPublisherName);
		wprintf(L"pEnumPublisherInfo[%u].ulDriveNumber is %u\n" , ul , pEnumPublisherInfo[ul].ulDriveNumber);
		wprintf(L"pEnumPublisherInfo[%u].ulConnectType is %u\n" , ul , pEnumPublisherInfo[ul].ulConnectType);
	}
}

//=============================================================================
//	DisplayPublisherStatus
//	
//	(1)Display PP100_PUBLISHER_STATUS.
//
//	IN  : publisherStatus			- PP100_PUBLISHER_STATUS structure.
//	OUT : 
//
//	Return : void
//=============================================================================
void DisplayPublisherStatus(PP100_PUBLISHER_STATUS publisherStatus)
{
	for(unsigned long ul = 0;ul < sizeof(publisherStatus.ulINFORMATIONCode) / sizeof(publisherStatus.ulINFORMATIONCode[0]);ul++)
	{
		if(0 == publisherStatus.ulINFORMATIONCode[ul])
		{
			break;
		}
		wprintf(L"publisherStatus.ulINFORMATIONCode[%u] : %u\n" , ul , publisherStatus.ulINFORMATIONCode[ul]);
	}
	wprintf(L"stPublisherStatus.ulMode : %u\n" , publisherStatus.ulMode);
	for(unsigned long ul = 0;ul < sizeof(publisherStatus.ulDriveStatus) / sizeof(publisherStatus.ulDriveStatus[0]);ul++)
	{
		wprintf(L"publisherStatus.ulDriveStatus[%u] : %u\n" , ul , publisherStatus.ulDriveStatus[ul]);
	}
	for(unsigned long ul = 0;ul < sizeof(publisherStatus.pDrivePluginName) / sizeof(publisherStatus.pDrivePluginName[0]);ul++)
	{
		wprintf(L"publisherStatus.pDrivePluginName[%u] : %s\n" , ul , publisherStatus.pDrivePluginName[ul]);
	}
	for(unsigned long ul = 0;ul < sizeof(publisherStatus.ulDriveLife) / sizeof(publisherStatus.ulDriveLife[0]);ul++)
	{
		wprintf(L"publisherStatus.ulDriveLife[%u] : %u\n" , ul , publisherStatus.ulDriveLife[ul]);
	}
	wprintf(L"publisherStatus.ulPrinterStatus : %u\n" , publisherStatus.ulPrinterStatus);
	wprintf(L"publisherStatus.stInkStatus.ulCyan : %u\n" , publisherStatus.stInkStatus.ulCyan);
	wprintf(L"publisherStatus.stInkStatus.ulMagenta : %u\n" , publisherStatus.stInkStatus.ulMagenta);
	wprintf(L"publisherStatus.stInkStatus.ulYellow : %u\n" , publisherStatus.stInkStatus.ulYellow);
	wprintf(L"publisherStatus.stInkStatus.ulLightCyan : %u\n" , publisherStatus.stInkStatus.ulLightCyan);
	wprintf(L"publisherStatus.stInkStatus.ulLightMagenta : %u\n" , publisherStatus.stInkStatus.ulLightMagenta);
	wprintf(L"publisherStatus.stInkStatus.ulBlack : %u\n" , publisherStatus.stInkStatus.ulBlack);
	for(unsigned long ul = 0;ul < sizeof(publisherStatus.ulStackerSetting) / sizeof(publisherStatus.ulStackerSetting[0]);ul++)
	{
		wprintf(L"publisherStatus.ulStackerSetting[%u] : %u\n" , ul , publisherStatus.ulStackerSetting[ul]);
	}
	for(unsigned long ul = 0;ul < sizeof(publisherStatus.ulStackerRest) / sizeof(publisherStatus.ulStackerRest[0]);ul++)
	{
		wprintf(L"publisherStatus.ulStackerRest[%u] : %u\n" , ul , publisherStatus.ulStackerRest[ul]);
	}
	wprintf(L"publisherStatus.ulPrintableCopies : %u\n" , publisherStatus.ulPrintableCopies);
	wprintf(L"publisherStatus.ulPrintedCopies : %u\n" , publisherStatus.ulPrintedCopies);
	wprintf(L"publisherStatus.ulMaintenanceBoxFreeSpace : %u\n" , publisherStatus.ulMaintenanceBoxFreeSpace);
	wprintf(L"publisherStatus.pSerialNumber : %s\n" , publisherStatus.pSerialNumber);
}

//=============================================================================
//	DisplayJobStatus
//	
//	(1)Display PP100_JOB_STATUS.
//
//	IN  : pJobStatus		- Pointer to PP100_JOB_STATUS array.
//		  ulJobStatusNum	- Number of array.
//	OUT : 
//
//	Return : void
//=============================================================================
void DisplayJobStatus(PP100_JOB_STATUS pJobStatus[] , unsigned long ulJobStatusNum)
{
	for(unsigned long ul = 0;ul < ulJobStatusNum;ul++)
	{
		wprintf(L"pJobStatus[%u].pJobID : %s\n" , ul , pJobStatus[ul].pJobID);
		wprintf(L"pJobStatus[%u].pPublisherName : %s\n" , ul , pJobStatus[ul].pPublisherName);
		wprintf(L"pJobStatus[%u].ulJobStatus : %u\n" , ul , pJobStatus[ul].ulJobStatus);
		wprintf(L"pJobStatus[%u].ulErrorCode : %u\n" , ul , pJobStatus[ul].ulErrorCode);
		wprintf(L"pJobStatus[%u].ulPublicationNumber : %u\n" , ul , pJobStatus[ul].ulPublicationNumber);
		wprintf(L"pJobStatus[%u].ulCompletionNumber : %u\n" , ul , pJobStatus[ul].ulCompletionNumber);
		wprintf(L"pJobStatus[%u].ulJobType : %u\n" , ul , pJobStatus[ul].ulJobType);
		wprintf(L"pJobStatus[%u].ulSource : %u\n" , ul , pJobStatus[ul].ulSource);
		wprintf(L"pJobStatus[%u].ulDestination : %u\n" , ul , pJobStatus[ul].ulDestination);
		wprintf(L"pJobStatus[%u].ulJobIndex : %u\n" , ul , pJobStatus[ul].ulJobIndex);
		wprintf(L"pJobStatus[%u].ulEstimateTime : %u\n" , ul , pJobStatus[ul].ulEstimateTime);
		wprintf(L"pJobStatus[%u].ulErrorNumber : %u\n" , ul , pJobStatus[ul].ulErrorNumber);
		wprintf(L"pJobStatus[%u].ulMode : %u\n" , ul , pJobStatus[ul].ulMode);
		wprintf(L"pJobStatus[%u].ucIsSubmittedByTotalDiscMaker : %u\n" , ul , pJobStatus[ul].ucIsSubmittedByTotalDiscMaker);
	}
}