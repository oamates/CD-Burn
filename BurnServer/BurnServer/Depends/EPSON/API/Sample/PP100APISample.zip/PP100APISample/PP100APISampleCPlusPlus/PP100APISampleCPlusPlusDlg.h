
// PP100APISampleCPlusPlusDlg.h : header file
//

#pragma once

#include "PP100APIManager.h"
#include "afxwin.h"


// CPP100APISampleCPlusPlusDlg dialog
class CPP100APISampleCPlusPlusDlg : public CDialog
{
// Construction
public:
	CPP100APISampleCPlusPlusDlg(CWnd* pParent = NULL);	// standard constructor
	~CPP100APISampleCPlusPlusDlg();						// standard destructor

// Dialog Data
	enum { IDD = IDD_PP100APISAMPLECPLUSPLUS_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
private:
	CButton m_buttonConnect;
	CButton m_buttonEnumeratePublishers;
	CButton m_buttonGetPublisherStatus;
	CButton m_buttonSubmitJob;	
	CButton m_buttonGetCreatedJobList;
	CButton m_buttonGetJobStatus;
	CButton m_buttonCancelJob;
	CButton m_buttonClearText;
	CComboBox m_comboboxServerHandle;
	CComboBox m_comboboxPublishers;
	CComboBox m_comboboxJobID;
	CString m_strHost;
	CString m_strOrderFolder;
	CString m_strResultText;

	CPoint m_ptMinimum;

	CPP100APIManager* m_lpPP100APIManager;

public:
	afx_msg void buttonConnect_Click();
	afx_msg void buttonEnumeratePublishers_Click();
	afx_msg void buttonGetPublisherStatus_Click();
	afx_msg void buttonSubmitJob_Click();
	afx_msg void buttonGetCreatedJobList_Click();
	afx_msg void buttonGetJobStatus_Click();
	afx_msg void buttonCancelJob_Click();
	afx_msg void buttonClearText_Click();

private:
	void ScrollToLastLine();
public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
	afx_msg void OnDestroy();
};
