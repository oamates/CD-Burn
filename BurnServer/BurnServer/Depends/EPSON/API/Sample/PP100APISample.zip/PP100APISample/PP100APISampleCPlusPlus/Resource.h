//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PP100APISampleCPlusPlus.rc
//
#define IDD_PP100APISAMPLECPLUSPLUS_DIALOG 102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON_CLEAR_TEXT           1000
#define IDC_EDIT_RESULT_TEXT            1001
#define IDC_BUTTON_CANCEL_JOB           1002
#define IDC_BUTTON_GET_JOB_STATUS       1003
#define IDC_COMBO_JOB_ID                1004
#define IDC_STATIC_JOB_ID               1005
#define IDC_COMBO_PUBLISHERS            1006
#define IDC_BUTTON_SUBMIT_JOB           1007
#define IDC_BUTTON_GET_PUBLISHER_STATUS 1008
#define IDC_STATIC_PUBLISHERS           1009
#define IDC_COMBO_SERVER_HANDLE         1010
#define IDC_STATIC_SERVER_HANDLE        1011
#define IDC_BUTTON_ENUMERATE_PUBLISHERS 1012
#define IDC_BUTTON_CONNECT              1013
#define IDC_EDIT_ORDER_FOLDER           1014
#define IDC_EDIT_HOST                   1015
#define IDC_STATIC_HOST                 1016
#define IDC_STATIC_ORDER_FOLDER         1017
#define IDC_BUTTON_GET_CREATED_JOB_LIST 1018
#define IDC_STATIC_ARROW1               1019
#define IDC_STATIC_ARROW2               1020
#define IDC_STATIC_ARROW3               1021
#define IDC_COMBOBOXEX1                 1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
