﻿namespace PP100APISample
{
    partial class FormPP100APISampleCSharp
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonSubmitJob = new System.Windows.Forms.Button();
            this.labelServerHandle = new System.Windows.Forms.Label();
            this.labelJobID = new System.Windows.Forms.Label();
            this.labelPublishers3 = new System.Windows.Forms.Label();
            this.labelArrow7 = new System.Windows.Forms.Label();
            this.labelArrow6 = new System.Windows.Forms.Label();
            this.labelArrow5 = new System.Windows.Forms.Label();
            this.labelOrderFolder2 = new System.Windows.Forms.Label();
            this.labelHost2 = new System.Windows.Forms.Label();
            this.buttonGetJobStatus = new System.Windows.Forms.Button();
            this.comboBoxServerHandle = new System.Windows.Forms.ComboBox();
            this.textBoxOrderFolder2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonConnect = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxHost2 = new System.Windows.Forms.TextBox();
            this.comboBoxJobID = new System.Windows.Forms.ComboBox();
            this.buttonEnumeratePublishers = new System.Windows.Forms.Button();
            this.buttonGetCreatedJobList = new System.Windows.Forms.Button();
            this.buttonGetPublisherStatus = new System.Windows.Forms.Button();
            this.textBoxResult = new System.Windows.Forms.TextBox();
            this.comboBoxPublishers3 = new System.Windows.Forms.ComboBox();
            this.buttonClearText = new System.Windows.Forms.Button();
            this.buttonCancenJob = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "Publisher Status";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "Publisher";
            // 
            // buttonSubmitJob
            // 
            this.buttonSubmitJob.Location = new System.Drawing.Point(456, 87);
            this.buttonSubmitJob.Name = "buttonSubmitJob";
            this.buttonSubmitJob.Size = new System.Drawing.Size(169, 23);
            this.buttonSubmitJob.TabIndex = 19;
            this.buttonSubmitJob.Text = "Submit job";
            this.buttonSubmitJob.UseVisualStyleBackColor = true;
            this.buttonSubmitJob.Click += new System.EventHandler(this.buttonSubmitJob_Click);
            // 
            // labelServerHandle
            // 
            this.labelServerHandle.AutoSize = true;
            this.labelServerHandle.Location = new System.Drawing.Point(236, 40);
            this.labelServerHandle.Name = "labelServerHandle";
            this.labelServerHandle.Size = new System.Drawing.Size(73, 12);
            this.labelServerHandle.TabIndex = 19;
            this.labelServerHandle.Text = "ServerHandle";
            // 
            // labelJobID
            // 
            this.labelJobID.AutoSize = true;
            this.labelJobID.Location = new System.Drawing.Point(459, 119);
            this.labelJobID.Name = "labelJobID";
            this.labelJobID.Size = new System.Drawing.Size(39, 12);
            this.labelJobID.TabIndex = 18;
            this.labelJobID.Text = "Job ID";
            // 
            // labelPublishers3
            // 
            this.labelPublishers3.AutoSize = true;
            this.labelPublishers3.Location = new System.Drawing.Point(459, 40);
            this.labelPublishers3.Name = "labelPublishers3";
            this.labelPublishers3.Size = new System.Drawing.Size(58, 12);
            this.labelPublishers3.TabIndex = 17;
            this.labelPublishers3.Text = "Publishers";
            // 
            // labelArrow7
            // 
            this.labelArrow7.AutoSize = true;
            this.labelArrow7.Location = new System.Drawing.Point(427, 147);
            this.labelArrow7.Name = "labelArrow7";
            this.labelArrow7.Size = new System.Drawing.Size(17, 12);
            this.labelArrow7.TabIndex = 16;
            this.labelArrow7.Text = "->";
            // 
            // labelArrow6
            // 
            this.labelArrow6.AutoSize = true;
            this.labelArrow6.Location = new System.Drawing.Point(424, 63);
            this.labelArrow6.Name = "labelArrow6";
            this.labelArrow6.Size = new System.Drawing.Size(17, 12);
            this.labelArrow6.TabIndex = 15;
            this.labelArrow6.Text = "->";
            // 
            // labelArrow5
            // 
            this.labelArrow5.AutoSize = true;
            this.labelArrow5.Location = new System.Drawing.Point(200, 63);
            this.labelArrow5.Name = "labelArrow5";
            this.labelArrow5.Size = new System.Drawing.Size(17, 12);
            this.labelArrow5.TabIndex = 14;
            this.labelArrow5.Text = "->";
            // 
            // labelOrderFolder2
            // 
            this.labelOrderFolder2.AutoSize = true;
            this.labelOrderFolder2.Location = new System.Drawing.Point(9, 40);
            this.labelOrderFolder2.Name = "labelOrderFolder2";
            this.labelOrderFolder2.Size = new System.Drawing.Size(65, 12);
            this.labelOrderFolder2.TabIndex = 13;
            this.labelOrderFolder2.Text = "OrderFolder";
            // 
            // labelHost2
            // 
            this.labelHost2.AutoSize = true;
            this.labelHost2.Location = new System.Drawing.Point(9, 15);
            this.labelHost2.Name = "labelHost2";
            this.labelHost2.Size = new System.Drawing.Size(29, 12);
            this.labelHost2.TabIndex = 10;
            this.labelHost2.Text = "Host";
            // 
            // buttonGetJobStatus
            // 
            this.buttonGetJobStatus.Location = new System.Drawing.Point(456, 142);
            this.buttonGetJobStatus.Name = "buttonGetJobStatus";
            this.buttonGetJobStatus.Size = new System.Drawing.Size(169, 23);
            this.buttonGetJobStatus.TabIndex = 9;
            this.buttonGetJobStatus.Text = "Get job status";
            this.buttonGetJobStatus.UseVisualStyleBackColor = true;
            this.buttonGetJobStatus.Click += new System.EventHandler(this.buttonGetJobStatus_Click);
            // 
            // comboBoxServerHandle
            // 
            this.comboBoxServerHandle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxServerHandle.DropDownWidth = 200;
            this.comboBoxServerHandle.FormattingEnabled = true;
            this.comboBoxServerHandle.Location = new System.Drawing.Point(315, 37);
            this.comboBoxServerHandle.Name = "comboBoxServerHandle";
            this.comboBoxServerHandle.Size = new System.Drawing.Size(89, 20);
            this.comboBoxServerHandle.TabIndex = 3;
            // 
            // textBoxOrderFolder2
            // 
            this.textBoxOrderFolder2.Location = new System.Drawing.Point(80, 37);
            this.textBoxOrderFolder2.Name = "textBoxOrderFolder2";
            this.textBoxOrderFolder2.Size = new System.Drawing.Size(103, 19);
            this.textBoxOrderFolder2.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 36);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 12);
            this.label6.TabIndex = 6;
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(11, 58);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(172, 23);
            this.buttonConnect.TabIndex = 2;
            this.buttonConnect.Text = "Connect";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 12);
            this.label5.TabIndex = 4;
            // 
            // textBoxHost2
            // 
            this.textBoxHost2.Location = new System.Drawing.Point(80, 12);
            this.textBoxHost2.Name = "textBoxHost2";
            this.textBoxHost2.Size = new System.Drawing.Size(103, 19);
            this.textBoxHost2.TabIndex = 0;
            // 
            // comboBoxJobID
            // 
            this.comboBoxJobID.DropDownWidth = 200;
            this.comboBoxJobID.FormattingEnabled = true;
            this.comboBoxJobID.Location = new System.Drawing.Point(518, 116);
            this.comboBoxJobID.Name = "comboBoxJobID";
            this.comboBoxJobID.Size = new System.Drawing.Size(107, 20);
            this.comboBoxJobID.TabIndex = 8;
            // 
            // buttonEnumeratePublishers
            // 
            this.buttonEnumeratePublishers.Location = new System.Drawing.Point(235, 58);
            this.buttonEnumeratePublishers.Name = "buttonEnumeratePublishers";
            this.buttonEnumeratePublishers.Size = new System.Drawing.Size(169, 23);
            this.buttonEnumeratePublishers.TabIndex = 4;
            this.buttonEnumeratePublishers.Text = "Enumerate publishers";
            this.buttonEnumeratePublishers.UseVisualStyleBackColor = true;
            this.buttonEnumeratePublishers.Click += new System.EventHandler(this.buttonEnumeratePublishers_Click);
            // 
            // buttonGetCreatedJobList
            // 
            this.buttonGetCreatedJobList.Location = new System.Drawing.Point(11, 142);
            this.buttonGetCreatedJobList.Name = "buttonGetCreatedJobList";
            this.buttonGetCreatedJobList.Size = new System.Drawing.Size(172, 23);
            this.buttonGetCreatedJobList.TabIndex = 7;
            this.buttonGetCreatedJobList.Text = "Get created job list";
            this.buttonGetCreatedJobList.UseVisualStyleBackColor = true;
            this.buttonGetCreatedJobList.Click += new System.EventHandler(this.buttonGetCreatedJobList_Click);
            // 
            // buttonGetPublisherStatus
            // 
            this.buttonGetPublisherStatus.Location = new System.Drawing.Point(456, 58);
            this.buttonGetPublisherStatus.Name = "buttonGetPublisherStatus";
            this.buttonGetPublisherStatus.Size = new System.Drawing.Size(169, 23);
            this.buttonGetPublisherStatus.TabIndex = 6;
            this.buttonGetPublisherStatus.Text = "Get publisher status";
            this.buttonGetPublisherStatus.UseVisualStyleBackColor = true;
            this.buttonGetPublisherStatus.Click += new System.EventHandler(this.buttonGetPublisherStatus_Click);
            // 
            // textBoxResult
            // 
            this.textBoxResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxResult.Location = new System.Drawing.Point(11, 201);
            this.textBoxResult.Multiline = true;
            this.textBoxResult.Name = "textBoxResult";
            this.textBoxResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxResult.Size = new System.Drawing.Size(614, 204);
            this.textBoxResult.TabIndex = 10;
            // 
            // comboBoxPublishers3
            // 
            this.comboBoxPublishers3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPublishers3.FormattingEnabled = true;
            this.comboBoxPublishers3.Location = new System.Drawing.Point(518, 37);
            this.comboBoxPublishers3.Name = "comboBoxPublishers3";
            this.comboBoxPublishers3.Size = new System.Drawing.Size(107, 20);
            this.comboBoxPublishers3.TabIndex = 5;
            // 
            // buttonClearText
            // 
            this.buttonClearText.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClearText.Location = new System.Drawing.Point(549, 411);
            this.buttonClearText.Name = "buttonClearText";
            this.buttonClearText.Size = new System.Drawing.Size(75, 23);
            this.buttonClearText.TabIndex = 20;
            this.buttonClearText.Text = "Clear text";
            this.buttonClearText.UseVisualStyleBackColor = true;
            this.buttonClearText.Click += new System.EventHandler(this.buttonClearText_Click);
            // 
            // buttonCancenJob
            // 
            this.buttonCancenJob.Location = new System.Drawing.Point(456, 172);
            this.buttonCancenJob.Name = "buttonCancenJob";
            this.buttonCancenJob.Size = new System.Drawing.Size(168, 23);
            this.buttonCancenJob.TabIndex = 21;
            this.buttonCancenJob.Text = "Cancel job";
            this.buttonCancenJob.UseVisualStyleBackColor = true;
            this.buttonCancenJob.Click += new System.EventHandler(this.buttonCancelJob_Click);
            // 
            // FormPP100APISampleCSharp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 446);
            this.Controls.Add(this.buttonCancenJob);
            this.Controls.Add(this.buttonClearText);
            this.Controls.Add(this.buttonSubmitJob);
            this.Controls.Add(this.textBoxResult);
            this.Controls.Add(this.textBoxHost2);
            this.Controls.Add(this.labelServerHandle);
            this.Controls.Add(this.comboBoxPublishers3);
            this.Controls.Add(this.labelJobID);
            this.Controls.Add(this.buttonGetPublisherStatus);
            this.Controls.Add(this.labelPublishers3);
            this.Controls.Add(this.buttonGetCreatedJobList);
            this.Controls.Add(this.labelArrow7);
            this.Controls.Add(this.buttonEnumeratePublishers);
            this.Controls.Add(this.labelArrow6);
            this.Controls.Add(this.comboBoxJobID);
            this.Controls.Add(this.labelArrow5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelOrderFolder2);
            this.Controls.Add(this.buttonConnect);
            this.Controls.Add(this.labelHost2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.buttonGetJobStatus);
            this.Controls.Add(this.textBoxOrderFolder2);
            this.Controls.Add(this.comboBoxServerHandle);
            this.MinimumSize = new System.Drawing.Size(640, 480);
            this.Name = "FormPP100APISampleCSharp";
            this.Text = "PP100APISampleCSharp";
            this.Load += new System.EventHandler(this.FormPP100APISampleCSharp_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormPP100APISampleCSharp_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonGetJobStatus;
        private System.Windows.Forms.ComboBox comboBoxServerHandle;
        private System.Windows.Forms.TextBox textBoxOrderFolder2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxHost2;
        private System.Windows.Forms.ComboBox comboBoxJobID;
        private System.Windows.Forms.Button buttonEnumeratePublishers;
        private System.Windows.Forms.Button buttonGetCreatedJobList;
        private System.Windows.Forms.Button buttonGetPublisherStatus;
        private System.Windows.Forms.TextBox textBoxResult;
        private System.Windows.Forms.ComboBox comboBoxPublishers3;
        private System.Windows.Forms.Label labelOrderFolder2;
        private System.Windows.Forms.Label labelHost2;
        private System.Windows.Forms.Label labelArrow6;
        private System.Windows.Forms.Label labelArrow5;
        private System.Windows.Forms.Label labelArrow7;
        private System.Windows.Forms.Label labelServerHandle;
        private System.Windows.Forms.Label labelJobID;
        private System.Windows.Forms.Label labelPublishers3;
        private System.Windows.Forms.Button buttonSubmitJob;
        private System.Windows.Forms.Button buttonClearText;
        private System.Windows.Forms.Button buttonCancenJob;
    }
}