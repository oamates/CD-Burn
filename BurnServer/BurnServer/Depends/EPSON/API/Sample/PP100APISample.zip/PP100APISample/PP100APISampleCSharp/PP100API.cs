﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace EPSON.PP100.API
{
    public static class Define
    {
        public enum ReturnValue
        {
            PP100API_INFORMATION_CODE_NOT_DEFINED = -18,
            PP100API_ERROR_CODE_NOT_DEFINED = -17,
            PP100API_JOB_NOT_RECOGNIZED = -16,
            PP100API_JOB_IS_ALREADY_FINISHED = -15,
            PP100API_JOB_IS_SUBMITTED_BY_TOTAL_DISC_MAKER = -14,
            PP100API_JOB_SUBMITTED = -13,
            PP100API_TDBRIDGE_LESS_VERSION = -12,
            PP100API_NOT_SUPPORTED = -11,
            PP100API_JOB_NOT_CREATED = -10,
            PP100API_PUBLISHER_NOT_FOUND = -8,
            PP100API_MORE_ITEMS = -7,
            PP100API_ACCESS_DENIED = -6,
            PP100API_ORDER_FOLDER_NOT_FOUND = -5,
            PP100API_HOST_NOT_FOUND = -4,
            PP100API_INVALID_PARAMETER = -3,
            PP100API_NOT_INITIALIZED = -2,
            PP100API_FAILURE = -1,
            PP100API_SUCCESS = 0,
            PP100API_JOB_SETTING_NOT_SET = 1,
        }

        public enum ErrorCode : uint
        {
            PP100API_SYS001 = 1,
            PP100API_SYS002 = 2,
            PP100API_SYS003 = 3,
            PP100API_JDF0100 = 100,
            PP100API_JDF0101 = 101,
            PP100API_JDF0102 = 102,
            PP100API_JDF0200 = 200,
            PP100API_JDF0201 = 201,
            PP100API_JDF0202 = 202,
            PP100API_JDF0203 = 203,
            PP100API_JDF0300 = 300,
            PP100API_JDF0400 = 400,
            PP100API_JDF0500 = 500,
            PP100API_JDF0501 = 501,
            PP100API_JDF0502 = 502,
            PP100API_JDF0600 = 600,
            PP100API_JDF0700 = 700,
            PP100API_JDF0800 = 800,
            PP100API_JDF0900 = 900,
            PP100API_JDF0901 = 901,
            PP100API_JDF0902 = 902,
            PP100API_JDF0903 = 903,
            PP100API_JDF0904 = 904,
            PP100API_JDF0905 = 905,
            PP100API_JDF0907 = 907,
            PP100API_JDF0908 = 908,
            PP100API_JDF0909 = 909,
            PP100API_JDF0910 = 910,
            PP100API_JDF0911 = 911,
            PP100API_JDF0912 = 912,
            PP100API_JDF0913 = 913,
            PP100API_JDF0914 = 914,
            PP100API_JDF1000 = 1000,
            PP100API_JDF1100 = 1100,
            PP100API_JDF1101 = 1101,
            PP100API_JDF1103 = 1103,
            PP100API_JDF1104 = 1104,
            PP100API_JDF1105 = 1105,
            PP100API_JDF1106 = 1106,
            PP100API_JDF1107 = 1107,
            PP100API_JDF1108 = 1108,
            PP100API_JDF1150 = 1150,
            PP100API_JDF1151 = 1151,
            PP100API_JDF1152 = 1152,
            PP100API_JDF1153 = 1153,
            PP100API_JDF1154 = 1154,
            PP100API_JDF1155 = 1155,
            PP100API_JDF1156 = 1156,
            PP100API_JDF1157 = 1157,
            PP100API_JDF1200 = 1200,
            PP100API_JDF1201 = 1201,
            PP100API_JDF1300 = 1300,
            PP100API_JDF1301 = 1301,
            PP100API_JDF1302 = 1302,
            PP100API_JDF1303 = 1303,
            PP100API_JDF1304 = 1304,
            PP100API_JDF1305 = 1305,
            PP100API_JDF1306 = 1306,
            PP100API_JDF1400 = 1400,
            PP100API_JDF1401 = 1401,
            PP100API_JDF1402 = 1402,
            PP100API_JDF1500 = 1500,
            PP100API_JDF1501 = 1501,
            PP100API_JDF1502 = 1502,
            PP100API_JDF1503 = 1503,
            PP100API_JDF1504 = 1504,
            PP100API_JDF1505 = 1505,
            PP100API_JDF1506 = 1506,
            PP100API_JDF1507 = 1507,
            PP100API_JDF1600 = 1600,
            PP100API_JDF1601 = 1601,
            PP100API_JDF1602 = 1602,
            PP100API_JDF1603 = 1603,
            PP100API_JDF1604 = 1604,
            PP100API_JDF1610 = 1610,
            PP100API_JDF1611 = 1611,
            PP100API_JDF1612 = 1612,
            PP100API_JDF1613 = 1613,
            PP100API_JDF1614 = 1614,
            PP100API_JDF1615 = 1615,
            PP100API_JDF1616 = 1616,
            PP100API_JDF1620 = 1620,
            PP100API_JDF1621 = 1621,
            PP100API_JDF1622 = 1622,
            PP100API_JDF1623 = 1623,
            PP100API_JDF1624 = 1624,
            PP100API_JDF1625 = 1625,
            PP100API_JDF1700 = 1700,
            PP100API_JDF1701 = 1701,
            PP100API_JDF1800 = 1800,
            PP100API_JDF1801 = 1801,
            PP100API_JDF1900 = 1900,
            PP100API_JDF1901 = 1901,
            PP100API_JDF1910 = 1910,
            PP100API_JDF1911 = 1911,
            PP100API_JDF1912 = 1912,
            PP100API_JDF1913 = 1913,
            PP100API_JDF1914 = 1914,
            PP100API_JDF1915 = 1915,
            PP100API_JDF1916 = 1916,
            PP100API_JDF1920 = 1920,
            PP100API_JDF1921 = 1921,
            PP100API_JDF1930 = 1930,
            PP100API_JDF1931 = 1931,
            PP100API_JDF1940 = 1940,
            PP100API_JDF1950 = 1950,
            PP100API_JDF2000 = 2000,
            PP100API_JDF2001 = 2001,
            PP100API_JDF2100 = 2100,
            PP100API_JDF2101 = 2101,
            PP100API_JDF2102 = 2102,
            PP100API_JDF2200 = 2200,
            PP100API_JDF2201 = 2201,
            PP100API_JDF2202 = 2202,
            PP100API_JDF2300 = 2300,
            PP100API_JDF2400 = 2400,
            PP100API_JDF2500 = 2500,
            PP100API_JDF2501 = 2501,
            PP100API_JDF2600 = 2600,
            PP100API_JDF2601 = 2601,
            PP100API_JDF2602 = 2602,
            PP100API_JDF2603 = 2603,
            PP100API_JDF2700 = 2700,
            PP100API_JDF2800 = 2800,
            PP100API_JDF2801 = 2801,
            PP100API_JDF2900 = 2900,
            PP100API_JDF0000 = 5000,
            PP100API_JDF0001 = 5001,
            PP100API_JDF0002 = 5002,
            PP100API_JDF0003 = 5003,
            PP100API_JDF0004 = 5004,
            PP100API_CAN000 = 10000,
            PP100API_CAN001 = 10001,
            PP100API_CAN002 = 10002,
            PP100API_CAN003 = 10003,
            PP100API_CAN004 = 10004,
            PP100API_CAN005 = 10005,
            PP100API_CAN006 = 10006,
            PP100API_CAN007 = 10007,
            PP100API_CAN008 = 10008,
            PP100API_CAN009 = 10009,
            PP100API_CAN010 = 10010,
            PP100API_CAN011 = 10011,
            PP100API_CAN012 = 10012,
            PP100API_CAN013 = 10013,
            PP100API_CAN014 = 10014,
            PP100API_CAN015 = 10015,
            PP100API_CAN016 = 10016,
            PP100API_CAN017 = 10017,
            PP100API_CAN018 = 10018,
            PP100API_CAN019 = 10019,
            PP100API_CAN020 = 10020,
            PP100API_CAN021 = 10021,
            PP100API_CAN100 = 10100,
            PP100API_CAN101 = 10101,
            PP100API_CAN102 = 10102,
            PP100API_CAN103 = 10103,
            PP100API_STP000 = 10300,
            PP100API_STP001 = 10301,
            PP100API_STP002 = 10302,
            PP100API_RTN000 = 10200,
            PP100API_RTN001 = 10201,
            PP100API_RTN002 = 10202,
            PP100API_RTN003 = 10203,
            PP100API_RTN004 = 10204,
            PP100API_RTN005 = 10205,
            PP100API_RTN006 = 10206,
            PP100API_RTN007 = 10207,
            PP100API_RTN008 = 10208,
            PP100API_RTN009 = 10209,
            PP100API_RTN010 = 10210,
            PP100API_RTN011 = 10211,
            PP100API_RTN012 = 10212,
            PP100API_RTN013 = 10213,
            PP100API_RTN014 = 10214,
            PP100API_RTN015 = 10215,
            PP100API_RTN016 = 10216,
            PP100API_RTN017 = 10217,
            PP100API_OTH000 = 10400
        }

        public enum InformationCode : uint
        {
            PP100API_HPR000 = 1,
            PP100API_HPR001 = 2,
            PP100API_HPR002 = 3,
            PP100API_HPR003 = 4,
            PP100API_HPR005 = 5,
            PP100API_HPR006 = 6,
            PP100API_HPR007 = 7,
            PP100API_HPR008 = 8,
            PP100API_HPR009 = 9,
            PP100API_HPR010 = 10,
            PP100API_HDR000 = 100,
            PP100API_HDR001 = 101,
            PP100API_HDR002 = 102,
            PP100API_HAR000 = 200,
            PP100API_HAR001 = 201,
            PP100API_HAR002 = 202,
            PP100API_HAR003 = 203,
            PP100API_HAR004 = 204,
            PP100API_HAR005 = 205,
            PP100API_HAR007 = 207,
            PP100API_HAR008 = 208,
            PP100API_HAR009 = 209,
            PP100API_HIKC000 = 300,
            PP100API_HIKC001 = 301,
            PP100API_HIKM000 = 400,
            PP100API_HIKM001 = 401,
            PP100API_HIKY000 = 500,
            PP100API_HIKY001 = 501,
            PP100API_HIKLC000 = 600,
            PP100API_HIKLC001 = 601,
            PP100API_HIKLM000 = 700,
            PP100API_HIKLM001 = 701,
            PP100API_HIKBK000 = 800,
            PP100API_HIKBK001 = 801,
            PP100API_HST1000 = 1000,
            PP100API_HST1001 = 1001,
            PP100API_HST2000 = 2000,
            PP100API_HST2001 = 2001,
            PP100API_HST3000 = 3000,
            PP100API_HST3001 = 3001,
            PP100API_HST3002 = 3002,
            PP100API_HDC000 = 4000,
            PP100API_HNW000 = 4100,
            PP100API_HNW001 = 4101
        }

        public enum Mode : uint
        {
            PP100API_NORMAL_MODE = 1,
            PP100API_OUTPUT_MODE,
            PP100API_BATCH_MODE,
            PP100API_MEASUREMENT_MODE = 6,
            PP100API_READ_BACK_MODE,
        }

        public enum StackerSetting : uint
        {
            PP100API_INPUT = 1,
            PP100API_OUTPUT,
            PP100API_NOT_USE_STACKER,
            PP100API_CD_MINUS_R = 10,
            PP100API_DVD_MINUS_R = 20,
            PP100API_DVD_PLUS_R,
            PP100API_DVD_R,
            PP100API_DVD_MINUS_R_DL = 30,
            PP100API_DVD_PLUS_R_DL,
            PP100API_DVD_R_DL,
            PP100API_BD_MINUS_R = 40,
            PP100API_BD_MINUS_R_DL = 50,

        }

        public enum PublisherStatus : uint
        {
            PP100API_WAITING = 1,
            PP100API_TRANSFERRING,
            PP100API_PAUSED,
            PP100API_PRINTING = 100,
            PP100API_DRYING,
            PP100API_CLEANING,
            PP100API_WRITING = 200,
            PP100API_VERIFYING_WRITE,
            PP100API_UNUSED,
            PP100API_PLUGIN_PROCESSING,
            PP100API_MEASURING,
        }

        public enum JobStatus : uint
        {
            PP100API_JOB_PROCESSING_TO_ACCEPT = 1,
            PP100API_JOB_WAITING,
            PP100API_JOB_RUNNING,
            PP100API_JOB_PAUSING,
            PP100API_JOB_RECOVERING,
            PP100API_JOB_CANCELING,
            PP100API_JOB_PAUSED,
            PP100API_JOB_STANDBY,
            PP100API_JOB_PUBLISHED,
            PP100API_JOB_PUBLISHED_WARNING_NO_ERROR_DISC,
            PP100API_JOB_PUBLISHED_WARNING_ERROR_DISC,
            PP100API_JOB_USER_CANCELLED,
            PP100API_JOB_ERROR_CANCELLED,
            PP100API_JOB_DENIED,
        }

        public enum StackerRest : uint
        {
            PP100API_STACKER_NOT_FULL = 200,
        }

        public enum UsbConnectionMode : uint
        {
            PP100API_USB_20 = 1,
            PP100API_USB_30,
        }

        public enum JobType : uint
        {
            PP100API_JOB_TYPE_WRITE = 1,
            PP100API_JOB_TYPE_PRINT,
            PP100API_JOB_TYPE_PUBLISH,
            PP100API_JOB_TYPE_MEASURE,
        }

        public enum Stacker : uint
        {
            PP100API_STACKER1 = 1,
            PP100API_STACKER2,
            PP100API_STACKER3,
            PP100API_STACKER4,
            PP100API_NOSETTING = 5,
            PP100API_STACKER1_OR_STACKER2 = 12,
            PP100API_STACKER2_OR_STACKER3 = 23,
            PP100API_STACKER2_OR_STACKER4 = 24,
        }

        public enum DiscType : uint
        {
            PP100API_CD = 1,
            PP100API_DVD,
            PP100API_DVD_DL,
            PP100API_BD,
            PP100API_BD_DL,
        }

        public enum Compare : uint
        {
            PP100API_COMPARE = 1,
            PP100API_DONT_COMPARE,
        }

        public enum Measure : uint
        {
            PP100API_MEASURE = 1,
            PP100API_DONT_MEASURE,
        }

        public enum ArchiveDiscOnly : uint
        {
            PP100API_ONLY_ARCHIVE_DISC = 1,
            PP100API_NOT_ONLY_ARCHIVE_DISC,
        }

        public enum DiscClose : uint
        {
            PP100API_CLOSE_DISC = 1,
            PP100API_DONT_CLOSE_DISC,
        }

        public enum Format : uint
        {
            PP100API_ISO9660L2 = 1,
            PP100API_JOLIET,
            PP100API_UDF102,
            PP100API_UDF102_BRIDGE,
            PP100API_UDF260,
            PP100API_UDF150,
        }

        public enum LabelType : uint
        {
            PP100API_CD_DVD_LABEL = 1,
            PP100API_CD_DVD_PREMIUM_LABEL,
            PP100API_EPSON_SPECIFIED_CD_DVD_LABEL,
        }

        public enum PrintMode : uint
        {
            PP100API_PRINTMODE1 = 1,
            PP100API_PRINTMODE2,
            PP100API_PRINTMODE3,
        }

        public enum Priority : uint
        {
            PP100API_NORMAL_PRIORITY = 1,
            PP100API_HIGH_PRIORITY,
        }

        public enum InvalidValue : uint
        {
            PP100API_ERROR = 0xFFFFFFFE,
            PP100API_UNKNOWN = 0xFFFFFFFF,
        }
    }

    public static class Struct
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
        public struct PP100_ENUM_PUBLISHER_INFO
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 65)]
            public string pPublisherName;
            public uint uiDriveNumber;
            public uint uiConnectType;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 512)]
            public byte[] ucReserved;
        };

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
        public struct PP100_INK_STATUS
        {
            public uint uiCyan;
            public uint uiMagenta;
            public uint uiYellow;
            public uint uiLightCyan;
            public uint uiLightMagenta;
            public uint uiBlack;
        };

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
        public struct PP100_PUBLISHER_STATUS
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
            public uint[] uiINFORMATIONCode;
            public uint uiMode;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            public uint[] uiDriveStatus;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 41)]
            public string pDrive1PluginName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 41)]
            public string pDrive2PluginName;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            public uint[] uiDriveLife;
            public uint uiPrinterStatus;
            public PP100_INK_STATUS stInkStatus;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public uint[] uiStackerSetting;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public uint[] uiStackerRest;
            public uint uiPrintableCopies;
            public uint uiPrintedCopies;
            public uint uiMaintenanceBoxFreeSpace;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 33)]
            public string pSerialNumber;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            public uint[] uiDriveProgress;
            public uint uiCompleteDiscNum;
            public uint uiUsbConnectionMode;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 496)]
            public byte[] ucReserved;
        };

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
        public struct PP100_JOB_STATUS
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 41)]
            public string pJobID;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 65)]
            public string pPublisherName;
            public uint uiJobStatus;
            public uint uiErrorCode;
            public uint uiPublicationNumber;
            public uint uiCompletionNumber;
            public uint uiJobType;
            public uint uiSource;
            public uint uiDestination;
            public uint uiJobIndex;
            public uint uiEstimateTime;
            public uint uiErrorNumber;
            public uint uiMode;
            public byte bySumbittedByTotalDiscMaker;
            public uint uiRemainingEstimateTime;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 508)]
            public byte[] ucReserved;
        };

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
        public struct PP100_WRITE_DATA
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
            public string pSourceData;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
            public string pDestinationData;
        };

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
        public struct PP100_AUDIO_TRACK
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
            public string pMusicFilePath;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 129)]
            public string pTrackTitle;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 129)]
            public string pTrackArtistName;
            public uint uiPregap;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 13)]
            public string pISRC;
        };

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
        public struct PP100_REPLACE_FIELD_TEXT
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1025)]
            public string pName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1025)]
            public string pValue;
        };

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 1)]
        public struct PP100_REPLACE_FIELD_BINARY
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1025)]
            public string pName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1025)]
            public string pPath;
        };
    }

    public static class Function
    {
        // The full path of PP100API.dll.
        // If you changed the installation folder of EPSON TD Bridge, you need to changed the value.
        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll")]
        public static extern int PP100_Initialize();

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll")]
        public static extern int PP100_Destroy();

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll")]
        public static extern int PP100_ConnectServer([MarshalAs(UnmanagedType.LPWStr)]string pHost, [MarshalAs(UnmanagedType.LPWStr)]string pOrderFolder, ref uint pHandle);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll")]
        public static extern int PP100_DisConnectServer(uint uiHandle);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll")]
        public static extern int PP100_EnumPublishers(uint uiHandle, [In, Out] Struct.PP100_ENUM_PUBLISHER_INFO[] pEnumPublisherInfo, ref uint pEnumPubilsherInfoNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll")]
        public static extern int PP100_GetPublisherStatus(uint uiHandle, [MarshalAs(UnmanagedType.LPWStr)]string pPublisherName, ref Struct.PP100_PUBLISHER_STATUS pPublisherStatus);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetJobStatus(uint uiHandle, StringBuilder pJobID, [In, Out] Struct.PP100_JOB_STATUS[] pJobStatus, ref uint pJobStatusNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_CreateJob(StringBuilder pJobID);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_CopyJob(StringBuilder pSourceJobID, StringBuilder pDestinationJobID);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_DeleteJob(StringBuilder pJobID);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetCreatedJobList([In, Out]string[] pJobID, ref uint pJobIDNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SubmitJob(uint uiHandle, StringBuilder pJobID, bool bAutoDelete);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_CancelJob(uint uiHandle, StringBuilder pJobID);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetPublisher(StringBuilder pJobID, StringBuilder pPublisher);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetPublisher(StringBuilder pJobID, StringBuilder pPublisher);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetCopies(StringBuilder pJobID, uint uiNumber);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetCopies(StringBuilder pJobID, ref uint pNumber);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetOutStacker(StringBuilder pJobID, uint uiOutStacker);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetOutStacker(StringBuilder pJobID, ref uint pOutStacker);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetInStacker(StringBuilder pJobID, uint uiInStacker);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetInStacker(StringBuilder pJobID, ref uint pInStacker);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetDiscType(StringBuilder pJobID, uint uiDiscType);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetDiscType(StringBuilder pJobID, ref uint pDiscType);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetWritingSpeed(StringBuilder pJobID, float fWritingSpeed);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetWritingSpeed(StringBuilder pJobID, ref float fWritingSpeed);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetCompare(StringBuilder pJobID, uint uiCompare);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetCompare(StringBuilder pJobID, ref uint pCompare);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetCloseDisc(StringBuilder pJobID, uint uiCloseDisc);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetCloseDisc(StringBuilder pJobID, ref uint pCloseDisc);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetFormat(StringBuilder pJobID, uint uiWritingFormat);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetFormat(StringBuilder pJobID, ref uint pWritingFormat);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetData(StringBuilder pJobID, [In]Struct.PP100_WRITE_DATA[] pWriteData, uint uiWriteDataNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_AddData(StringBuilder pJobID, [In]Struct.PP100_WRITE_DATA[] pWriteData, uint uiWriteDataNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_DeleteData(StringBuilder pJobID, [In]Struct.PP100_WRITE_DATA[] pWriteData, uint uiWriteDataNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetData(StringBuilder pJobID, [In, Out]Struct.PP100_WRITE_DATA[] pWriteData, ref uint pWriteDataNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetVolumeLabel(StringBuilder pJobID, StringBuilder pVolumeLabel);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetVolumeLabel(StringBuilder pJobID, StringBuilder pVolumeLabel);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetVideo(StringBuilder pJobID, StringBuilder pVideoPath);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetVideo(StringBuilder pJobID, StringBuilder pVideoPath);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetVideoTitle(StringBuilder pJobID, StringBuilder pVideoTitle);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetVideoTitle(StringBuilder pJobID, StringBuilder pVideoTitle);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetImage(StringBuilder pJobID, StringBuilder pImage);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetImage(StringBuilder pJobID, StringBuilder pImage);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetAudioTrack(StringBuilder pJobID, [In]Struct.PP100_AUDIO_TRACK[] pAudioTrack, uint uiAudioTrackNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_AddAudioTrack(StringBuilder pJobID, [In]Struct.PP100_AUDIO_TRACK[] pAudioTrack, uint uiAudioTrackNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_DeleteAudioTrack(StringBuilder pJobID, [In]Struct.PP100_AUDIO_TRACK[] pAudioTrack, uint uiAudioTrackNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetAudioTrack(StringBuilder pJobID, [In, Out]Struct.PP100_AUDIO_TRACK[] pAudioTrack, ref uint pAudioTrackNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetAudioTitle(StringBuilder pJobID, StringBuilder pAudioTitle);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetAudioTitle(StringBuilder pJobID, StringBuilder pAudioTitle);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetAudioCatalogCode(StringBuilder pJobID, StringBuilder pAudioCatalogCode);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetAudioCatalogCode(StringBuilder pJobID, StringBuilder pAudioCatalogCode);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetAudioPerformer(StringBuilder pJobID, StringBuilder pAudioPerformer);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetAudioPerformer(StringBuilder pJobID, StringBuilder pAudioPerformer);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetLabel(StringBuilder pJobID, StringBuilder pLabel);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetLabel(StringBuilder pJobID, StringBuilder pLabel);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetLabelType(StringBuilder pJobID, uint uiLabelType);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetLabelType(StringBuilder pJobID, ref uint pLabelType);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetReplaceFieldText(StringBuilder pJobID, [In]Struct.PP100_REPLACE_FIELD_TEXT[] pReplaceFieldText, uint uiReplaceFieldTextNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_AddReplaceFieldText(StringBuilder pJobID, [In]Struct.PP100_REPLACE_FIELD_TEXT[] pReplaceFieldText, uint uiReplaceFieldTextNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_DeleteReplaceFieldText(StringBuilder pJobID, [In]Struct.PP100_REPLACE_FIELD_TEXT[] pReplaceFieldText, uint uiReplaceFieldTextNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetReplaceFieldText(StringBuilder pJobID, [In, Out]Struct.PP100_REPLACE_FIELD_TEXT[] pReplaceFieldText, ref uint pReplaceFieldTextNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetReplaceFieldBinary(StringBuilder pJobID, [In]Struct.PP100_REPLACE_FIELD_BINARY[] pReplaceFieldText, uint uiReplaceFieldBinaryNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_AddReplaceFieldBinary(StringBuilder pJobID, [In]Struct.PP100_REPLACE_FIELD_BINARY[] pReplaceFieldText, uint uiReplaceFieldBinaryNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_DeleteReplaceFieldBinary(StringBuilder pJobID, [In]Struct.PP100_REPLACE_FIELD_BINARY[] pReplaceFieldText, uint uiReplaceFieldBinaryNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetReplaceFieldBinary(StringBuilder pJobID, [In, Out]Struct.PP100_REPLACE_FIELD_BINARY[] pReplaceFieldText, ref uint pReplaceFieldBinaryNum);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetLabelArea(StringBuilder pJobID, uint uiDiscDiamOut, uint uiDiscDiamIn);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetLabelArea(StringBuilder pJobID, ref uint pDiscDiamOut, ref uint pDiscDiamIn);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetPrintMode(StringBuilder pJobID, uint uiPrintMode);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetPrintMode(StringBuilder pJobID, ref uint pPrintMode);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetPlugInID(StringBuilder pJobID, StringBuilder pPlugInID);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetPlugInID(StringBuilder pJobID, StringBuilder pPlugInID);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetPlugInParameter(StringBuilder pJobID, StringBuilder pPlugInParameter);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetPlugInParameter(StringBuilder pJobID, StringBuilder pPlugInParameter);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetPriority(StringBuilder pJobID, uint uiPriority);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetPriority(StringBuilder pJobID, ref uint pPriority);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetMeasure(StringBuilder pJobID, uint uiMeasure);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetMeasure(StringBuilder pJobID, ref uint pMeasure);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_SetArchiveDiscOnly(StringBuilder pJobID, uint uiArchiveDiscOnly);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_GetArchiveDiscOnly(StringBuilder pJobID, ref uint pArchiveDiscOnly);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_ConvertErrorCodeToString(uint uiErrorCode, StringBuilder pErrorString);

        [DllImport("C:\\Program Files\\EPSON\\TDBridge\\API\\PP100API.dll", CharSet = CharSet.Unicode)]
        public static extern int PP100_ConvertInformationCodeToString(uint uiInformationCode, StringBuilder pInformationString);
    }
}
